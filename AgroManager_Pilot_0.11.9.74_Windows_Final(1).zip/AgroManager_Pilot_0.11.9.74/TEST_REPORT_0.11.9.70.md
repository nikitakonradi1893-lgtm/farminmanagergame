# AgroManager Pilot 0.11.9.70 — test report

## Release focus

Close the remaining actionable equipment-catalog gaps from the 0.11.9.69 re-audit: modern 80–119 hp tractors, small/mid-power implement choice, road-transport brand metadata, portable catalog audits, and domestic-used grain-cart coverage.

## Passed targeted release gates

- `catalog_gap_closure_0_11_9_70.js` — **59/59 PASS**.
- `catalog_depth_release_0_11_9_68.js` — **268/268 PASS**.
- `catalog_depth_audit_2_0_0_11_9_68.js` — **270 structural PASS**; only 10 always-on `new_brand_ladder` diagnostic rows remain.
- `catalog_semantic_consistency_0_11_9_67.js` — **2,642 PASS**.
- `catalog_zero_gap_audit.js` — **1,018 PASS**.
- `small_tractor_ecosystem_0_11_9_66.js` — **107 PASS**.
- `heavy_endgame_ecosystem_0_11_9_67.js` — **10 PASS**.
- `equipment_full_integrity_audit_0_11_8_96.js` — **13,251 PASS**; 878 physical entries.
- `road_transport_expansion_0_11_9_69.js` — **86/86 PASS**.
- `truck_roadtrain_capacity_0_11_9_23.js` — **88/88 PASS**.
- `capello_header_compatibility_0_11_9_22.js` — **1,508/1,508 PASS**.
- `engine_variants_audit.js` — **443 PASS**.
- `powertrain_variants_audit.js` — **833 PASS**.
- `technical_integrity_audit.js` — **52/52 PASS**.

## Catalog counts

- Total physical entries: **878**.
- Tractors: **160**.
- Implements: **424**.
- Combines: **61**.
- Grain carts: **10**.
- Headers: **153**.
- Trucks: **35**.
- Trailers/semi-trailers: **35**.

## Release policy

- Fresh game remains required between versions.
- This release is **2/3 after the mandatory 0.11.9.68 Drive checkpoint**; no new mandatory Drive checkpoint is required for 0.11.9.70.

## Additional cross-system regressions

- `application_straw_audit_0_11_9_30.js` — **24 PASS**; fertilizer spreader assertion made growth-safe.
- `balance_availability_audit_0_11_9_35.js` — **1,496 PASS**.
- `catalog_fuel_realism_0_11_9_19.js` — **911 PASS**.
- `popular_equipment_passport_audit_0_11_8_99.js` — **61 PASS**.
- `self_propelled_parts_audit.js` — **14 PASS**.
- `implement_interface_compatibility_audit.js` — **390 PASS**, zero orphan passive implements.
- `implement_power_ladder_balance.js` — **12 PASS**.
- `tractor_trailer_expansion_0_11_9_24.js` — **135 PASS**.
- `roadtrain_harvest_regression_0_11_9_04.js` — **27 PASS**.
- `agricultural_overload_logistics_0_11_9_38.js` — **12 PASS**.
- `large_farm_logistics_stress_0_11_8_99.js` — **1,423 PASS**.
- `field_supply_logistics_0_11_9_15.js` — **28 PASS**.
- `fuel_logistics_physical_0_11_9_56.js` — **11 PASS**.
- `first_farm_ux_economy_0_11_9_65.js` — **15 PASS**.
- `progression_bottleneck_0_11_9_55.js` — **6 PASS**.
- `outside_work_hiring_0_11_9_64.js` — **24 PASS**.
- `system_invariants_audit_0_11_8_97.js` — **25 PASS**.
- `project_continuity_rules_0_11_9_09.js` — **11/11 PASS**.

A brute-force run of every historical test file was attempted but exceeded the execution watchdog after 38 files. One stale exact-count assertion found during that run (`fertilizer spreaders === 17`) was corrected and its test now passes. No incomplete brute-force run is represented as a full-suite PASS.
