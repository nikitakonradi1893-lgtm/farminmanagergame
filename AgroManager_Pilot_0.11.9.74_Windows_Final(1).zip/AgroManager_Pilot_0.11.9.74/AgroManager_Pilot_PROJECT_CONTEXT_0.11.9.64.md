# AgroManager Pilot — PROJECT CONTEXT

- Version: **0.11.9.64**
- Fresh game per version; cross-version save migration is not a release requirement.
- Last mandatory Google Drive checkpoint: **0.11.9.62**.
- Releases counted since the last mandatory Drive checkpoint: **2/3 after 0.11.9.62 checkpoint**.
- Pending Drive upload: **none**.

## Outside labor market — 0.11.9.64

- Main menu now includes **Работа по найму**: the farm owner or an idle permanent employee can work for another farm without using the player's machinery.
- External hourly pay uses the same `gigHourlyRate(role, skill)` formula used when the player hires a one-off worker. There is no hidden premium for outgoing labor.
- The owner is universal by role subject to skill; permanent employees can only take jobs matching their own profession and required skill.
- While outside, the worker is physically unavailable for the player's operations, contracts, training, and other assignments. External shifts add fatigue and mandatory rest.
- Completed outside work gives normal work experience/skill progression.
- Owner: all external pay is farm income because the owner has no salary.
- Permanent employee: external pay is farm income, but the same hours also accrue toward the employee's monthly hourly bonus. The farm therefore earns the spread rather than receiving labor for free.
- The board changes daily and by season. Simple year-round machinery/transport work guarantees that a fresh owner with starting skill 45 has a viable January path.
- Added difficulty **Старт с нуля** with 0 RUB starting cash. Difficulty still changes only the starting condition; global game balance is unchanged.

## Zero-start audit

- Ceiling-style control: no land, no machinery, owner takes the best eligible outside job on weekdays for three years.
- End year 1: ≈ 1.98M RUB, skill ≈ 70.
- End year 2: ≈ 4.49M RUB, skill ≈ 85.
- End year 3: ≈ 7.21M RUB, skill ≈ 95, ≈ 7,026 worked hours.
- This is intentionally an intensive upper-bound work pattern, not passive income. It does not recreate the normal 10M start inside three years.

## Staff progression — existing

- Permanent employees and the owner can train; ordinary courses stop at skill 85.
- Permanent payroll is base salary + actual-hours bonus; tariffs rise automatically every 5 skill levels.
- Seasonal and one-off hires remain separate labor products.

## Spatial / operations model — existing

- Eight land clusters with physical machinery location.
- Same and adjacent clusters permit direct field-to-field relocation; distant changes route through base.
- Agro-operation plans can auto-chain work while shift time and eligibility allow.

## Mandatory development continuity rules

- **Context is mandatory in every release.** Keep `PROJECT_CONTEXT.md` and a current versioned duplicate.
- **Always ship the complete current game**, never a patch-only archive.
- **Google Drive checkpoint every three releases.** The last completed checkpoint is 0.11.9.62; 0.11.9.64 is 2/3 after it.
- **Mandatory cross-surface impact scan before implementation.** Changes to economy, staff, machinery, logistics, finance, UI, or time simulation must be checked against adjacent systems and existing regressions.
- **Impact consistency is a release gate.** Do not release while connected systems disagree about the same mechanic.
- Keep release archives clean: current context/test report plus unique still-relevant audits; remove replaced historical regression artifacts when they no longer add coverage.
