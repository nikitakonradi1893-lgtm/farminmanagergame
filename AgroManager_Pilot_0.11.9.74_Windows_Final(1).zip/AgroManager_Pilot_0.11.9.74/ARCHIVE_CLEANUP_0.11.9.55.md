# Archive cleanup — 0.11.9.55

Goal: keep each release self-contained without carrying the entire historical development archive inside every ZIP.

## Removed from the distributable
- 38 historical versioned PROJECT_CONTEXT snapshots from 0.11.9.17–0.11.9.54.
- 38 historical TEST_REPORT snapshots.
- Historical one-off audit/raw files already preserved in earlier release ZIPs / Drive checkpoints.
- Confirmed superseded legacy tests: old 0.11.9.00 progression harnesses, full-farm .52, A/B/C .50, logistics comparison .37, old manual-feedback .87, hardcoded catalog-expansion .21, superseded catalog-gap/balance audits, old technical-runtime audit, and the non-test livestock roadmap placeholder.

## Kept
- One canonical PROJECT_CONTEXT.md.
- One versioned context duplicate for the current release only.
- One current TEST_REPORT.
- Current source/runtime mirrors, launcher source, build scripts and complete game runtime.
- Active regression suite, including current full-farm, harvest, market, service, infrastructure and continuity tests.
- New progression bottleneck regression.

## Future policy
1. Historical release artifacts live in their original ZIP / Drive checkpoint, not in every future release.
2. A new release may keep only the current versioned context/report plus specifically active audits required for current work.
3. Superseded harnesses are removed when a newer persistent harness replaces them.
4. Feature regressions should avoid owning release-version state; release version/cache consistency belongs to the central continuity/technical gate.
5. Use `tools/bump_release.py` for release-marker synchronization.
