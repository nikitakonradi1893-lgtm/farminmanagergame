# AgroManager Pilot 0.11.9.72 — used/new price parity fix

## Problem

The used-market generator had a 50,000 ₽ minimum price floor. For models whose equivalent new dealer price was below that floor, a used listing could become more expensive than the same new item.

The confirmed case in 0.11.9.71 was `Полевой комплект канистр ГСМ · 200 л`: 45,000 ₽ new versus 50,000 ₽ used.

## Fix

For models still available new, the used listing is now capped against the dealer price of the **equivalent configuration** (engine, tires/tracks and body configuration), not merely the base model.

The parity cap is 94% of the equivalent new dealer price, rounded down with a price-appropriate step. This cap has priority over the legacy 50,000 ₽ used-price floor.

This preserves legitimate cases where a used machine in a richer configuration costs more than the base new model while guaranteeing it remains cheaper than the same new configuration.

## Regression

`tests/used_vs_new_price_parity_audit_0_11_9_72.js` samples all models that can simultaneously appear at a dealer and on the used market.

Current release sample:
- 451 candidate models;
- 270,600 generated used listings;
- 0 cases where used price >= equivalent new dealer price.
