# AgroManager Pilot — PROJECT CONTEXT

- Version: **0.11.9.70**.
- Fresh game per version; cross-version save migration is not a release requirement.
- Last mandatory Google Drive checkpoint: **0.11.9.68**.
- Releases counted since the last mandatory Drive checkpoint: **2/3 after 0.11.9.68 checkpoint**.
- Mandatory checkpoint for this release: **not required**.
- Pending Drive upload: **none**.

## Equipment catalog gap closure — 0.11.9.70

- Closed the remaining modern 80–119 hp brand gap with one representative current tractor for John Deere, Case IH, New Holland, Fendt, Massey Ferguson, DEUTZ-FAHR, Valtra and CLAAS.
- Added four premium 50–79 hp implement alternatives: Kverneland 150 B, LEMKEN Korund 8/300, PÖTTINGER FOX 3000 D and Gaspardo MTR 4R.
- Added used domestic small/mid-power alternatives for disk, cultivation, fertilizer spreading, grain drilling and row-crop seeding.
- Added a domestic-used PBN-16 grain-cart bridge.
- Normalized brands for the 0.11.9.69 road-transport additions (Ural, KAMAZ, Wielton, STAS, Sespel).
- Specialized truck semantics now support separate `bodyManufacturer` and `chassisBrand`; UZSA-40 on ZIL is the first explicit example.
- Fixed `catalog_depth_audit_2_0_0_11_9_68.js` portability by removing the stale absolute `/mnt/data/am68/...` path.
- New gap-closure gate verifies modern 80–119 hp coverage, small/mid implement depth, road-transport brand normalization, domestic-used grain-cart coverage and portable audit paths.
- Catalog now contains **878 physical entries**: 160 tractors, 424 implements, 61 combines, 10 grain carts, 153 headers, 35 trucks and 35 trailers.

## Existing mature systems

- Zero-start progression, outside work, first-farm planning and living used market remain unchanged.
- Equipment wear, service, repair, parts logistics, staff, land clusters, agronomy, harvesting, storage and finance remain authoritative and are covered by the existing regression suite.

## Mandatory development continuity rules

- **Context is mandatory in every release.** Keep `PROJECT_CONTEXT.md` and a current versioned duplicate.
- **Always ship the complete current game**, never a patch-only archive.
- **Google Drive checkpoint every three releases.** 0.11.9.68 is the completed mandatory checkpoint; 0.11.9.70 is release 2/3 after it.
- **Mandatory cross-surface impact scan before implementation.** Changes to economy, staff, machinery, logistics, finance, UI, or time simulation must be checked against adjacent systems and existing regressions.
- **Impact consistency is a release gate.** Do not release while connected systems disagree about the same mechanic.
- Keep release archives clean: current context/test report plus unique still-relevant audits; remove replaced historical regression artifacts when they no longer add coverage.
