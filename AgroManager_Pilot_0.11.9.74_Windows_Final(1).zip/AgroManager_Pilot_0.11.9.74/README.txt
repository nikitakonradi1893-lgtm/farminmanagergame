AgroManager Pilot 0.11.9.72 — FULL WINDOWS BUILD

Run: AgroManager Pilot.exe

This release fixes used-vs-new price parity for equivalent configurations and adds a permanent market regression test.
See PROJECT_CONTEXT.md, TEST_REPORT_0.11.9.72.md and USED_VS_NEW_PRICE_PARITY_FIX_0.11.9.72.md.
