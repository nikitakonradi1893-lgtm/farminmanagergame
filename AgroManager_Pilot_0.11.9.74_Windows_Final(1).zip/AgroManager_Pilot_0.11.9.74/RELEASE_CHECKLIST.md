# Release checklist — 0.11.9.74

- [x] Runtime/index/cache version bumped to 0.11.9.74.
- [x] User-facing «Пропашные сеялки» renamed to «Сеялки точного высева».
- [x] Internal `sow_row` preserved for compatibility.
- [x] No-Till represented as capability/filter, not a separate category.
- [x] Verified No-Till support added to Tempo V8/L24 and Early Riser 1255/2150.
- [x] Precision-planter / No-Till regression added.
- [x] Material-refill, semantic, dedup, zero-gap, technology-capacity and integrity checks passed.
- [x] web and source_web_copy synchronized.
- [x] Project context and versioned context updated.
- [x] Windows launcher rebuilt.
- [x] SHA-256 checksums regenerated.
- [x] Mandatory Drive checkpoint uploaded and verified (3/3 after 0.11.9.71).
