# TEST REPORT — AgroManager Pilot 0.11.9.66

Release focus: playable 50–80 hp tractor tier and low-power implement ladder.

## Passed

- `small_tractor_ecosystem_0_11_9_66.js`: **107/107 PASS**; 17 tractors in 50–79 hp tier.
- `catalog_zero_gap_audit.js`: **947 PASS**; catalog 807 entries.
- `technical_integrity_audit.js`: **52/52 PASS**.
- `equipment_full_integrity_audit_0_11_8_96.js`: **12,280 PASS**; all 807 physical catalog entries structurally valid.
- `progression_bottleneck_0_11_9_55.js`: **6/6 PASS**.
- `project_continuity_rules_0_11_9_09.js`: **11/11 PASS**.

## Small-class compatibility floor

- plow: 50 hp
- cultivate: 50 hp
- disk: 55 hp
- harrow: 50 hp
- grain sowing: 50 hp
- fertilizer: 40 hp
- sprayer: 35 hp

No global reduction of medium/heavy implement requirements was used; the new floor is provided by dedicated light implements, except the compact RUM-1000 spreader whose previous 80 hp requirement was corrected to 50 hp.
