# AgroManager Pilot — project context 0.11.9.74

- Version: **0.11.9.74**.
- Base: 0.11.9.73 technology-aware capacity and material-capacity release.
- Scope: precision-planter terminology normalization, verified No-Till capability coverage, and seeding-technology UI filtering. No new physical equipment records added.

## Seeding terminology and technology

User-facing `sow_row` is now **«Сеялки точного высева»**. The internal category ID remains `sow_row` for compatibility with operations, saves and regressions.

No-Till/direct drilling is a capability (`seedingModes` + `directDrill`), not a separate equipment category. Only assign it when the specific model/configuration is supported by evidence.

Verified No-Till precision planters now include Väderstad Tempo V8 / Tempo L 24 and Case IH Early Riser 1255 / 2150. The equipment UI includes a seeding-technology filter for conventional, Mini-Till, No-Till and direct drilling.

Catalog remains **868 physical records**.

## Large-farm planning rule

Large-farm capacity must respect conventional / Mini-Till / No-Till portfolios, periodic deep tillage, crop-specific windows and reuse of working units. Never assume every hectare receives every tillage operation every season.

## Regression policy

`tests/precision_planter_no_till_0_11_9_74.js` is a permanent gate for terminology, internal-ID compatibility, verified No-Till capability and UI filtering.

Existing permanent gates for physical dedup, used/new price parity, material refill, technology-portfolio capacity and catalog integrity remain in force.

## Checkpoint cadence

0.11.9.74 is release **3/3 after checkpoint 0.11.9.71**, so this build is the next mandatory Google Drive checkpoint.

## Mandatory development continuity rules

- Context is mandatory in every release: ship `PROJECT_CONTEXT.md` and a versioned context copy.
- Always ship the complete current game, never an isolated patch-only artifact.
- Google Drive checkpoint every three releases.
- Releases counted since the last mandatory Drive checkpoint: **3/3 — checkpoint 0.11.9.74**.
- Mandatory cross-surface impact scan before implementation: data, runtime logic, UI, tests, docs and packaging must be checked together.
- Impact consistency is a release gate: all affected surfaces must agree before a release is considered complete.
- Pending Drive upload: **none**.
