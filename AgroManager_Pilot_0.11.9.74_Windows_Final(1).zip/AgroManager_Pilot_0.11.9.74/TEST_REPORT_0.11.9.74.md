# AgroManager Pilot 0.11.9.74 — test report

Targeted regression results:

- precision planter + No-Till: 30/30 PASS;
- material capacity/refill: 22 PASS;
- catalog semantic consistency: 2612 PASS;
- physical dedup: 868 PASS, 0 warnings;
- zero-gap: 1007 PASS;
- technology portfolio capacity: 22/22 PASS;
- equipment full integrity: 868 physical/active records, PASS;
- small tractor ecosystem: 107 PASS;
- JavaScript syntax: app.js + equipment.js PASS.

Catalog totals remain unchanged: 868 physical equipment records.
