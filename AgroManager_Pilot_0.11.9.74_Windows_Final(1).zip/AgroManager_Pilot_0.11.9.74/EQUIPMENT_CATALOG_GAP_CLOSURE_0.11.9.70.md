# AgroManager Pilot 0.11.9.70 — equipment catalog gap closure

## Scope

This release closes the remaining actionable findings from the 0.11.9.69 catalog re-audit. It deliberately avoids another broad catalog expansion.

## Modern 80–119 hp tractors

Added one representative current model for each previously empty major-brand slot:

- John Deere 5100M — 101 hp;
- Case IH Farmall 110A — 110 hp;
- New Holland T5.110S — 110 hp;
- Fendt 310 Vario Gen5 — 113 hp with DynamicPerformance;
- Massey Ferguson 5M.105 — 105 hp;
- DEUTZ-FAHR 5100D Keyline — 102 hp;
- Valtra G105 — 110 hp boost;
- CLAAS ARION 420 — 100 hp.

Manufacturer power figures were checked against current/official product material. Game prices and fuel rates are balanced values, not dealer quotations.

## Small/mid-power implement depth

The four remaining 50–79 hp thin-choice warnings were removed with distinct premium alternatives:

- Kverneland 150 B 3-furrow — plough;
- LEMKEN Korund 8/300 — seedbed cultivator (manufacturer range starts at 65 hp);
- PÖTTINGER FOX 3000 D — compact disc combination (manufacturer minimum 75 hp);
- Gaspardo MTR 4R — four-row precision planter.

Additional used domestic alternatives were added for 80–119 hp progression: BDT-3, KPS-4, NRU-0.5, SZ-3.6 and SUPN-6.

## Transport/catalog metadata cleanup

- Ural-5557 and Ural NEXT now normalize to brand `Урал`.
- KAMAZ K5 54901 normalizes correctly despite the space in the model name.
- Wielton, STAS and Sespel semi-trailers no longer fall into `Прочие`.
- UZSA-40 seed loader now models `bodyManufacturer='УЗСА'` and `chassisBrand='ЗИЛ'`, instead of conflating chassis and upfitter brands.

## Grain-cart market

Added `ПБН-16 (ранний, Б/У)` as a domestic-used bridge. The grain-cart market now has domestic-used representation as well as existing imported used and new models.

## Regression hygiene

`catalog_depth_audit_2_0_0_11_9_68.js` no longer contains an absolute working-directory path. Historical exact-count assertions were already replaced with structural minimums, so legitimate catalog growth does not create false failures.

## Result

The depth audit now has no `thin_power_choice` or obvious brand-mismatch warnings. Its remaining `new_brand_ladder` records are intentional diagnostic matrices emitted for every tracked brand, not gap alerts.
