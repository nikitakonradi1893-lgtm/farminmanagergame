# AgroManager Pilot 0.11.9.68 — test report

## Catalog Depth 2.0 / equipment

- `catalog_depth_release_0_11_9_68.js`: **261/261 PASS**.
- `catalog_semantic_consistency_0_11_9_67.js`: **2528 PASS**.
- `catalog_zero_gap_audit.js`: **980 PASS**; catalog size **840**.
- `small_tractor_ecosystem_0_11_9_66.js`: **107 PASS**.
- `heavy_endgame_ecosystem_0_11_9_67.js`: **10 PASS**.
- `catalog_price_review_0_11_9_67.js`: **15 PASS**.
- `engine_variants_audit.js`: PASS; **443 checks**, 152 tractors, 57 variant models.
- `powertrain_variants_audit.js`: PASS; **833 checks**, 152 tractors, 126 foreign tractors.
- `equipment_full_integrity_audit_0_11_8_96.js`: **12,761 PASS**; 840 active/physical positions.
- `popular_equipment_passport_audit_0_11_8_99.js`: **61 PASS**.
- `self_propelled_parts_audit.js`: **14 PASS**; 275 powered machines.
- `implement_interface_compatibility_audit.js`: **381 PASS**.
- `implement_power_ladder_balance.js`: **12 PASS**.
- `heavy_implements_regression.js`: **66 PASS**.
- `tractor_trailer_expansion.js`: **135/135 PASS**.
- `capello_header_compatibility.js`: **1508/1508 PASS**.
- `historical_pickup_catalog_0_11_9_49.js`: PASS; 61 combines, pickup coverage **61/61**.
- `two_phase_harvest_pickup_balance.js`: PASS; pickup coverage **61/61**.
- `two_phase_harvest_matrix.js`: PASS.
- `harvest_unload_on_move.js`: **15 PASS**.
- `seasonal_truck_market.js`: **22 PASS**.
- `balance_availability_audit.js`: **1496 PASS**.

## Core progression / continuity

- `technical_integrity_audit.js`: **52/52 PASS**.
- `project_continuity_rules_0_11_9_09.js`: **11/11 PASS**.
- `first_farm_ux_economy_0_11_9_65.js`: **15 PASS**.
- `progression_bottleneck_audit.js`: **6/6 PASS**.

## Release-specific coverage

`catalog_depth_release_0_11_9_68.js` additionally guarantees:

- all 17 new mid-power tractors are present, uniquely identified and carry normalized brand/series/generation metadata;
- each of 8 target major brands has at least two current/new tractors in the 120–249 hp range;
- the 50–79 hp class has at least two choices in the core implement categories covered by the audit;
- no obvious recognizable manufacturer remains mislabeled as `Прочие` under the audit rules;
- the used grain-cart market has at least three choices;
- CLAAS EVION 450, Ростсельмаш T500, Ростсельмаш VECTOR 450 Track and John Deere X9 1100 are integrated into the combine/header graph and tank data;
- Ростсельмаш RSM 161 is stored at 400 hp.

## Build verification

- `web/` and `source_web_copy/` gameplay files are synchronized.
- Windows launcher rebuilt successfully from the final gameplay code.
- Runtime and cache markers are `0.11.9.68` / `011968`.

## Known environment limitation

`outside_work_zero_start_audit_0_11_9_64.js` did not complete within the execution time available in this environment. It is therefore recorded as **neither PASS nor FAIL**. Release 0.11.9.68 does not change outside-work income, zero-start land economics, contractor pricing, or the zero-start progression formulas covered by that harness.

A broader sequential all-affected-tests invocation also exceeded the tool execution window after a number of successful tests. This report therefore lists only checks that produced an explicit completed result; no unfinished run is represented as PASS.
