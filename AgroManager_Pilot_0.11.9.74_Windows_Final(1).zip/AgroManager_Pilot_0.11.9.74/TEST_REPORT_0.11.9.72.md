# TEST REPORT — AgroManager Pilot 0.11.9.72

## Release-specific checks

- used/new equivalent-configuration parity — **451 models / 270,600 generated listings / 0 inversions PASS**
- physical equipment dedup — **868/868 PASS, 0 warnings**
- catalog semantic consistency — **2,612 PASS**
- catalog zero-gap — **1,007 PASS**
- catalog price review — **15 PASS**
- road transport expansion — **86/86 PASS**
- truck/road-trailer capacity — **88/88 PASS**
- outside-work/hiring — **24 PASS**
- system invariants — **25 PASS**
- technical integrity — **52/52 PASS**

## Release conclusion

Used listings for currently new-available models are now always cheaper than the equivalent new dealer configuration. Richer used configurations may still exceed the price of a base new model, which is intentional.
