# AgroManager Pilot 0.11.9.68 — Catalog Depth 2.0 implementation audit

## Scope

This release implements the actionable P0/P1/P2 findings from `Catalog Depth Audit 2.0`: regression cleanup, brand semantics, current mid-power tractor families, small/mid implement choice, selected current combine generations and a used grain-cart bridge.

## Result

- Catalog: **840** physical entries.
- Tractors: **152**.
- Combines: **61**.
- Implements: **415**.
- Grain carts: **9**.
- Headers: **153**.
- Trucks: **24**.
- Trailers: **26**.

## Mid-power families added

John Deere 6M 140 / 6M 185; Case IH Vestrum 130 / Puma 200; New Holland T5.140 / T6.180 / T7.210 SWB; Fendt 314 Vario Gen5 / 620 Vario; Massey Ferguson 5S.145 / 7S.210; DEUTZ-FAHR 5125 / 6180 TTV; Valtra G135 / N175; CLAAS ARION 470 / ARION 570 CMATIC.

Power values were cross-checked against current manufacturer materials; game prices and fuel use remain balance values rather than dealer quotes.

## Combine generations added

- CLAAS EVION 450 — 258 hp, 8,000 l tank class.
- Ростсельмаш T500 — 360 hp, 10,000 l tank class.
- Ростсельмаш VECTOR 450 Track — 255 hp, 6,000 l tank class.
- John Deere X9 1100 — represented at 690 max hp.

All four are integrated into the existing two-way combine/header compatibility graph.

## Passport correction

`Ростсельмаш RSM 161` is corrected from 380 to **400 hp**, matching the current manufacturer product specification.

## Small / medium implement depth

Added: used КПС-2,8; new ПЛН-3-35М, КПС-4М, СЗ-3,6М, СУПН-4М, ПЛН-4-35М and КПС-6М. This increases choice without globally lowering power requirements of larger implements.

## Regression cleanup

Historical assertions that fixed the catalog at 118 tractors or 810 total entries were replaced with structural assertions. Stable IDs remain mandatory and duplicate IDs remain a hard failure.

## External verification sources

- John Deere tractors: https://www.deere.com/en/tractors/
- John Deere 6M 185: https://www.deere.com/en-us/products-solutions/tractors/utility-tractors/6m-185-tractor-njixmuw
- Case IH Vestrum/Puma: https://www.caseih.com/en-us/unitedstates/products/tractors
- New Holland tractors: https://agriculture.newholland.com/en-gb/europe/products/agricultural-tractors
- Fendt tractors: https://www.fendt.com/int/agricultural-machinery/tractors
- Massey Ferguson MF 5S: https://www.masseyferguson.com/en/product/tractors/mf-5s.html
- DEUTZ-FAHR tractors: https://www.deutz-fahr.com/en-eu/tractors
- Valtra tractors: https://www.valtra.com/products/
- CLAAS tractors / EVION: https://www.claas.com/
- Ростсельмаш T500 / VECTOR 450 Track: https://rostselmash.com/products/combine/

## Interpretation

0.11.9.68 deliberately improves **choice density and generation semantics** rather than maximizing raw catalog size. Heavy 500+ hp coverage was already healthy and was not expanded.
