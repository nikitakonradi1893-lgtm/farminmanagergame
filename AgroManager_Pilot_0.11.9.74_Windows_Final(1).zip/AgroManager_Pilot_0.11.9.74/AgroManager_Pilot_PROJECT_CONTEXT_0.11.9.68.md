# AgroManager Pilot — PROJECT CONTEXT

- Version: **0.11.9.68**.
- Fresh game per version; cross-version save migration is not a release requirement.
- Last mandatory Google Drive checkpoint: **0.11.9.68**.
- Releases counted since the last mandatory Drive checkpoint: **0/3 after 0.11.9.68 checkpoint**.
- Mandatory checkpoint for this release: **completed**.
- Pending Drive upload: **none**.

## Catalog Depth 2.0 implementation — 0.11.9.68

- Closed stale catalog regression gates that hard-coded 118 tractors / 810 total entries; expansion is now protected by structural uniqueness and minimum-coverage assertions.
- Brand normalization now covers late-added John Deere, Case IH, New Holland, Fendt, Massey Ferguson, DEUTZ-FAHR, Valtra, CLAAS, JCB, Ростсельмаш, ПАЛЕССЕ, AMAZONE, ТОНАР and chassis-based fuel/support vehicles.
- Added 17 current mid-power tractors focused on the 120–249 hp gap across eight major foreign brands.
- Added representative `series` / `generation` metadata for current tractor and combine families without changing stable IDs.
- Added seven small/mid-power implement alternatives, including a used 50 hp cultivator bridge and new 55–110 hp plow/cultivator/seeding choices.
- Added CLAAS EVION 450, Ростсельмаш T500, Ростсельмаш VECTOR 450 Track and John Deere X9 1100 with full header/tank integration.
- Corrected current Ростсельмаш RSM 161 engine power to 400 hp based on current manufacturer material.
- Added used Kinze 640 and 840 grain carts so the early/mid used market no longer depends on one cart listing family.
- Catalog now contains 840 physical entries: 152 tractors, 415 implements, 61 combines, 9 grain carts, 153 headers, 24 trucks and 26 trailers.

## Existing mature systems

- Zero-start progression, outside work, first-farm planning and living used market remain unchanged.
- Equipment wear, service, repair, parts logistics, staff, land clusters, agronomy, harvesting, storage and finance remain authoritative and are covered by the existing regression suite.

## Mandatory development continuity rules

- **Context is mandatory in every release.** Keep `PROJECT_CONTEXT.md` and a current versioned duplicate.
- **Always ship the complete current game**, never a patch-only archive.
- **Google Drive checkpoint every three releases.** 0.11.9.68 is the completed mandatory checkpoint after 0.11.9.65.
- **Mandatory cross-surface impact scan before implementation.** Changes to economy, staff, machinery, logistics, finance, UI, or time simulation must be checked against adjacent systems and existing regressions.
- **Impact consistency is a release gate.** Do not release while connected systems disagree about the same mechanic.
- Keep release archives clean: current context/test report plus unique still-relevant audits; remove replaced historical regression artifacts when they no longer add coverage.
