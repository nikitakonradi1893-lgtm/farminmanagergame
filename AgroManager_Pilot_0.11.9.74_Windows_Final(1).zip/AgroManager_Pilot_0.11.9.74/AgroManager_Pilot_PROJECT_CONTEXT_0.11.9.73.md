# AgroManager Pilot project context — 0.11.9.73

Release focus: technology-aware large-farm capacity correction and material-capacity metadata cleanup.

Checkpoint continuity: 0.11.9.71 is the last mandatory checkpoint. 0.11.9.73 is 2/3 after that checkpoint; no Drive checkpoint is required for this release.

Important planning rule: large-farm capacity must not assume every hectare receives every tillage operation every season. Respect field technology (conventional / Mini-till / No-till), periodic deep tillage, crop windows and fleet reuse.
