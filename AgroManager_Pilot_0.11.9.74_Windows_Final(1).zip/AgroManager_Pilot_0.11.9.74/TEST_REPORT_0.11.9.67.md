# AgroManager Pilot 0.11.9.67 — test report

## Catalog-specific gates

- catalog semantic consistency: **2437 PASS**
- heavy endgame ecosystem: **10 PASS**
- catalog price review: **15 PASS**

## Core regression

- technical integrity: **52 PASS**
- equipment full integrity: **12313 PASS**
- catalog zero-gap: **950 PASS**
- small tractor ecosystem: **107 PASS**
- progression bottleneck: **6 PASS**
- project continuity: **11/11 PASS**

## Build

Windows launcher rebuilt successfully from `launcher_source/build_windows.sh`.

## Notes

The catalog now contains 810 physical entries and 135 tractors. Heavy 500+ hp tractor count is 8. The 720 hp Salford I-2100 60 ft requirement remains intentional after manufacturer verification.
