# AgroManager Pilot — PROJECT CONTEXT

- Version: **0.11.9.66**.
- Fresh game per version; cross-version save migration is not a release requirement.
- Last mandatory Google Drive checkpoint: **0.11.9.65**.
- Releases counted since the last mandatory Drive checkpoint: **1/3 after 0.11.9.65 checkpoint**.
- Pending Drive upload: **none**.


## Small tractor ecosystem — 0.11.9.66

- Small tractors are treated as a complete gameplay tier, not decorative catalog entries.
- The 50–79 hp band now contains 17 tractors, including representative 60–76 hp models across the major brands already present in the game.
- Core small-farm operations now have a usable low-power ladder: plow 50 hp, cultivator 50 hp, disc 55 hp, harrow 50 hp, grain drilling 50 hp, fertilizer 40 hp and spraying 35 hp.
- Added narrow/light implements rather than globally lowering the requirements of larger equipment.
- The compact mounted RUM-1000 fertilizer spreader was reclassified from 80 hp to 50 hp because its previous requirement made it inconsistent with its intended small-farm role.
- A dedicated regression verifies every 50–79 hp tractor can perform plowing, cultivation, grain sowing, fertilizer spreading and spraying with catalog equipment.

## First farm experience — 0.11.9.65

- Dashboard now contains a persistent **«Первое хозяйство»** progression card.
- The card follows the real transition: first field → season budget → active work → first harvest → mechanization decision.
- It uses the current farm state instead of a scripted tutorial state and links directly to the relevant game surface.
- The season forecast is deliberately a planning estimate, not a guaranteed P&L: it uses current field area/crop, current standard contractor quotes, seed/material assumptions, current crop yield when available and conservative price/yield factors for planned crops.
- A 300k RUB liquidity reserve is shown explicitly so a new farm can see a cash gap before committing to the season.

## Machinery decision support — 0.11.9.65

- Used machinery listings now show a simple farm-specific economic context.
- Working implements and combines show the current standard contractor volume they can potentially replace on the player's owned arable area.
- The comparison intentionally labels this as contractor volume, not pure savings: fuel, labor, repair, residual value and downtime remain separate costs.
- Tractor listings show compatible owned implements and compatible used-market implements, avoiding a misleading claim that a tractor alone generates savings.

## Living used market — 0.11.9.65

- The already-dynamic used market is now visible as a market process instead of looking like a static catalog.
- The equipment page shows last replenishment, approximate next weekly replenishment, listings created within 7 days and listings expiring within 3 days.
- Individual listings can display **Новое объявление**, **Скоро снимут** and **Редкая цена** badges.
- «Редкая цена» is a transparent derived signal based on the listing price versus its ready-equivalent value plus a minimum condition threshold; it does not bypass diagnosis or repair risk.
- Existing expiry, replenishment, negotiation and diagnosis mechanics remain authoritative.

## Outside labor market — existing from 0.11.9.64

- Main menu includes **Работа по найму**: the owner or an idle permanent employee can work for another farm without using the player's machinery.
- Added difficulty **Старт с нуля** with 0 RUB starting cash; global balance remains unchanged.
- Full zero-start progression audit found no hard progression dead end.

## Spatial / operations model — existing

- Eight land clusters with physical machinery location.
- Same and adjacent clusters permit direct field-to-field relocation; distant changes route through base.
- Agro-operation plans can auto-chain work while shift time and eligibility allow.

## Mandatory development continuity rules

- **Context is mandatory in every release.** Keep `PROJECT_CONTEXT.md` and a current versioned duplicate.
- **Always ship the complete current game**, never a patch-only archive.
- **Google Drive checkpoint every three releases.** 0.11.9.65 is the completed mandatory checkpoint after 0.11.9.62.
- **Mandatory cross-surface impact scan before implementation.** Changes to economy, staff, machinery, logistics, finance, UI, or time simulation must be checked against adjacent systems and existing regressions.
- **Impact consistency is a release gate.** Do not release while connected systems disagree about the same mechanic.
- Keep release archives clean: current context/test report plus unique still-relevant audits; remove replaced historical regression artifacts when they no longer add coverage.
