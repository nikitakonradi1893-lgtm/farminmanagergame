# AgroManager Pilot 0.11.9.71 — physical equipment deduplication cleanup

## Goal

Close the duplicate-model and stale semantic-target issues found by the full 0.11.9.70 physical-model audit without reducing real gameplay coverage.

## Changes

- Removed duplicate catalog cards for БДТ-3, КПС-4 and СЗ-3,6 that were re-added in 0.11.9.70.
- Removed explicit КПС-2,8 (Б/У) and GRIMME GF 400 (Б/У) duplicate cards. Their surviving physical models remain eligible for the dynamic used market according to model age.
- Removed duplicate КСП-4 and КС-6Б used cards; kept the correct self-propelled physical records.
- Fixed the stale multi-role mapping: `cultivate/stubble` now targets КПС-4 (`imp43`) rather than LEMKEN Karat 12/600 (`imp41`).
- Consolidated 2ПТС-4 and 2ПТС-6 bale-haul variants into their real trailer cards. The trailers now carry bale capacities directly, so one physical asset can transport bulk material or bales without duplicate catalog entries.
- Updated contractor/test references from removed `hay_2pts4` to the surviving `2pts4` card.
- Updated zero-gap semantics: a sufficiently old dealer-new model can satisfy used-market coverage because the live used market creates second-hand listings from the same physical catalog model.
- Added permanent `equipment_physical_dedup_audit_0_11_9_71.js` regression coverage.

## Result

Physical catalog size: **878 → 868**.

Current counts:
- tractors: 160
- implements: 414
- combines: 61
- headers: 153
- trucks: 35
- trailers: 35
- grain carts: 10

The reduction removes duplicate cards only; no real equipment family or gameplay operation was removed.
