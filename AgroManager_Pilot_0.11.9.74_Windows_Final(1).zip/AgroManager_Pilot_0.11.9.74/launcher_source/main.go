package main

import (
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"io"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"
)

//go:embed web/*
var webFS embed.FS
var saveMu sync.Mutex

func openBrowser(url string) error {
	switch runtime.GOOS {
	case "windows":
		return exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		return exec.Command("open", url).Start()
	default:
		return exec.Command("xdg-open", url).Start()
	}
}

func saveDir() (string, error) {
	exe, err := os.Executable()
	if err != nil {
		return "", err
	}
	dir := filepath.Join(filepath.Dir(exe), "saves")
	if err := os.MkdirAll(dir, 0755); err != nil {
		return "", err
	}
	return dir, nil
}

func savePath(slot string) (string, error) {
	slot = strings.ToLower(strings.TrimSpace(slot))
	if slot != "autosave" && slot != "manual" {
		return "", fmt.Errorf("invalid save slot")
	}
	dir, err := saveDir()
	if err != nil {
		return "", err
	}
	return filepath.Join(dir, slot+".json"), nil
}

func validSaveBytes(data []byte) bool {
	trimmed := strings.TrimSpace(string(data))
	if len(data) == 0 || !strings.HasPrefix(trimmed, "{") || !strings.HasSuffix(trimmed, "}") || !json.Valid(data) {
		return false
	}
	var v map[string]any
	if err := json.Unmarshal(data, &v); err != nil {
		return false
	}
	_, hasVersion := v["version"].(string)
	_, hasGameTime := v["gameTime"].(float64)
	_, hasMoney := v["money"].(float64)
	_, hasFields := v["fields"].([]any)
	_, hasWarehouse := v["warehouse"].(map[string]any)
	return hasVersion && hasGameTime && hasMoney && hasFields && hasWarehouse
}

func rotateBackups(path string, keep int) {
	data, err := os.ReadFile(path)
	if err != nil || !validSaveBytes(data) {
		return
	}
	for i := keep; i >= 2; i-- {
		_ = os.Remove(fmt.Sprintf("%s.bak%d", path, i))
		_ = os.Rename(fmt.Sprintf("%s.bak%d", path, i-1), fmt.Sprintf("%s.bak%d", path, i))
	}
	_ = os.Remove(path + ".bak1")
	_ = os.WriteFile(path+".bak1", data, 0644)
}

func writeSaveAtomic(path string, data []byte) error {
	dir := filepath.Dir(path)
	tmpFile, err := os.CreateTemp(dir, filepath.Base(path)+".tmp-*")
	if err != nil {
		return err
	}
	tmp := tmpFile.Name()
	cleanup := func() { _ = os.Remove(tmp) }
	defer cleanup()
	if _, err = tmpFile.Write(data); err != nil {
		_ = tmpFile.Close()
		return err
	}
	if err = tmpFile.Sync(); err != nil {
		_ = tmpFile.Close()
		return err
	}
	if err = tmpFile.Close(); err != nil {
		return err
	}
	rotateBackups(path, 3)
	oldPath := path + ".replace-old"
	_ = os.Remove(oldPath)
	hadOld := false
	if _, statErr := os.Stat(path); statErr == nil {
		if err = os.Rename(path, oldPath); err != nil {
			return err
		}
		hadOld = true
	} else if !os.IsNotExist(statErr) {
		return statErr
	}
	if err = os.Rename(tmp, path); err != nil {
		if hadOld {
			_ = os.Rename(oldPath, path)
		}
		return err
	}
	if hadOld {
		_ = os.Remove(oldPath)
	}
	return nil
}
func readSaveWithRecovery(path string) ([]byte, string, os.FileInfo, error) {
	candidates := []struct{ path, source string }{{path, "primary"}, {path + ".bak1", "backup1"}, {path + ".bak2", "backup2"}, {path + ".bak3", "backup3"}}
	var lastErr error
	for _, c := range candidates {
		data, err := os.ReadFile(c.path)
		if err != nil {
			if !os.IsNotExist(err) {
				lastErr = err
			}
			continue
		}
		if !validSaveBytes(data) {
			lastErr = fmt.Errorf("invalid JSON in %s", c.source)
			continue
		}
		info, _ := os.Stat(c.path)
		return data, c.source, info, nil
	}
	if lastErr != nil {
		return nil, "", nil, lastErr
	}
	return nil, "", nil, os.ErrNotExist
}

func main() {
	sub, err := fs.Sub(webFS, "web")
	if err != nil {
		log.Fatal(err)
	}

	ln, err := net.Listen("tcp", "127.0.0.1:38471")
	if err != nil {
		// Fallback keeps the game launchable if the stable port is occupied, but the stable port is preferred so browser localStorage saves persist across launches.
		ln, err = net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			log.Fatal(err)
		}
	}
	addr := ln.Addr().String()

	mux := http.NewServeMux()
	var srv *http.Server
	var quitOnce sync.Once
	var sessionMu sync.Mutex
	activeSessions := 0
	sessionGeneration := uint64(0)
	shutdown := func(delay time.Duration) {
		quitOnce.Do(func() {
			go func() {
				time.Sleep(delay)
				ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
				defer cancel()
				if srv != nil {
					_ = srv.Shutdown(ctx)
				}
			}()
		})
	}

	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/api/save", func(w http.ResponseWriter, r *http.Request) {
		slot := r.URL.Query().Get("slot")
		path, pathErr := savePath(slot)
		if pathErr != nil {
			http.Error(w, pathErr.Error(), http.StatusBadRequest)
			return
		}
		w.Header().Set("Cache-Control", "no-store")
		saveMu.Lock()
		defer saveMu.Unlock()
		switch r.Method {
		case http.MethodGet:
			data, source, info, readErr := readSaveWithRecovery(path)
			if os.IsNotExist(readErr) {
				w.Header().Set("Content-Type", "application/json; charset=utf-8")
				w.WriteHeader(http.StatusNotFound)
				_, _ = w.Write([]byte(`{"exists":false}`))
				return
			}
			if readErr != nil {
				http.Error(w, "save read failed", http.StatusInternalServerError)
				return
			}
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
			w.Header().Set("X-Save-Source", source)
			if info != nil {
				w.Header().Set("X-Save-Modified", info.ModTime().UTC().Format(time.RFC3339))
			}
			if source != "primary" {
				w.Header().Set("X-Save-Recovered", "true")
			}
			_, _ = w.Write(data)
		case http.MethodPost:
			r.Body = http.MaxBytesReader(w, r.Body, 64<<20)
			data, readErr := io.ReadAll(r.Body)
			if readErr != nil || len(data) == 0 {
				http.Error(w, "invalid save body", http.StatusBadRequest)
				return
			}
			// Validate JSON without changing the payload written to disk.
			if !validSaveBytes(data) {
				http.Error(w, "save must be a valid JSON object", http.StatusBadRequest)
				return
			}
			if err := writeSaveAtomic(path, data); err != nil {
				http.Error(w, "save write failed", http.StatusInternalServerError)
				return
			}
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
			_, _ = w.Write([]byte(`{"ok":true}`))
		default:
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		}
	})
	mux.HandleFunc("/session", func(w http.ResponseWriter, r *http.Request) {
		sessionMu.Lock()
		activeSessions++
		sessionGeneration++
		sessionMu.Unlock()
		defer func() {
			sessionMu.Lock()
			if activeSessions > 0 {
				activeSessions--
			}
			sessionGeneration++
			closeGeneration := sessionGeneration
			lastSession := activeSessions == 0
			sessionMu.Unlock()
			if !lastSession {
				return
			}
			// A normal browser reload briefly closes the streaming request. Give a
			// replacement page enough time to reconnect before treating it as exit.
			go func(gen uint64) {
				time.Sleep(2 * time.Second)
				sessionMu.Lock()
				stillClosed := activeSessions == 0 && sessionGeneration == gen
				sessionMu.Unlock()
				if stillClosed {
					shutdown(0)
				}
			}(closeGeneration)
		}()
		w.Header().Set("Content-Type", "application/octet-stream")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		fl, _ := w.(http.Flusher)
		_, _ = w.Write([]byte{0})
		if fl != nil {
			fl.Flush()
		}
		ticker := time.NewTicker(25 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-r.Context().Done():
				return
			case <-ticker.C:
				if _, err := w.Write([]byte{0}); err != nil {
					return
				}
				if fl != nil {
					fl.Flush()
				}
			}
		}
	})
	mux.HandleFunc("/quit", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		_, _ = w.Write([]byte("bye"))
		shutdown(150 * time.Millisecond)
	})

	fileServer := http.FileServer(http.FS(sub))
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-cache")
		if r.URL.Path == "/" || r.URL.Path == "/index.html" {
			data, readErr := fs.ReadFile(sub, "index.html")
			if readErr != nil {
				http.Error(w, "index unavailable", http.StatusInternalServerError)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			_, _ = w.Write(data)
			return
		}
		fileServer.ServeHTTP(w, r)
	})

	srv = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	done := make(chan struct{})
	go func() {
		err := srv.Serve(ln)
		if err != nil && err != http.ErrServerClosed {
			log.Printf("server: %v", err)
		}
		close(done)
	}()

	url := fmt.Sprintf("http://%s/", addr)
	if err := openBrowser(url); err != nil {
		// Keep server alive even if automatic browser launch fails.
		log.Printf("open browser: %v", err)
	}
	<-done
	_ = os.Stdout.Sync()
}
