@echo off
setlocal
cd /d "%~dp0"
if exist web rmdir /s /q web
xcopy /e /i /q "..\web" "web" >nul
set GOOS=windows
set GOARCH=amd64
set CGO_ENABLED=0
go build -trimpath -ldflags="-H=windowsgui -s -w" -o "..\AgroManager Pilot.exe" .
set ERR=%ERRORLEVEL%
rmdir /s /q web
if not "%ERR%"=="0" exit /b %ERR%
echo Built: ..\AgroManager Pilot.exe
