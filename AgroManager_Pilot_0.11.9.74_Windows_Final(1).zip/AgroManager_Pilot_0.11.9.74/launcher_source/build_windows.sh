#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
rm -rf "$HERE/web"
cp -a "$ROOT/web" "$HERE/web"
trap 'rm -rf "$HERE/web"' EXIT
cd "$HERE"
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-H=windowsgui -s -w" -o "$ROOT/AgroManager Pilot.exe" .
echo "Built: $ROOT/AgroManager Pilot.exe"
