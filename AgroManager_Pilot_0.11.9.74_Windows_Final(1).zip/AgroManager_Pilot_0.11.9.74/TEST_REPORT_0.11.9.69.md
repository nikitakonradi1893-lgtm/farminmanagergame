# AgroManager Pilot 0.11.9.69 — test report

## Release focus

Road transport depth: agricultural Urals, ZIL-45065 body extension, fifth-wheel tractor units + grain semi-trailers, and a real-world modularity audit.

## Passed

- `road_transport_expansion_0_11_9_69.js` — **86/86 PASS**.
- `truck_roadtrain_capacity_0_11_9_23.js` — **88/88 PASS**.
- `technical_integrity_audit.js` — **52/52 PASS**.
- `equipment_full_integrity_audit_0_11_8_96.js` — **13,032 PASS**; 860 physical entries.
- `catalog_semantic_consistency_0_11_9_67.js` — **2,588 PASS**.
- `catalog_zero_gap_audit.js` — **1,000 PASS**.
- `roadtrain_harvest_regression_0_11_9_04.js` — **27 PASS**.
- `agricultural_overload_logistics_0_11_9_38.js` — **12 PASS**.
- `large_farm_logistics_stress_0_11_8_99.js` — **1,423 PASS**.
- `field_supply_logistics_0_11_9_15.js` — **28 PASS**.
- `fuel_logistics_physical_0_11_9_56.js` — **11 PASS**.
- `tractor_trailer_expansion_0_11_9_24.js` — **135 PASS**.

## Structural changes protected by tests

- Fifth-wheel tractor units have zero standalone crop capacity and cannot appear as standalone grain haulers.
- Grain semi-trailers are explicit road trailers with specific compatible tractor-unit IDs.
- Domestic-used, domestic-new, foreign-used and foreign-new segments all have tractor-unit and semi-trailer coverage.
- ZIL-45065 body extension changes volume from 6.0 to 12.5 m³ without changing legal payload.
- Ural-5557 / Ural NEXT have explicit compatible SЗАП road-trailer pairing.

