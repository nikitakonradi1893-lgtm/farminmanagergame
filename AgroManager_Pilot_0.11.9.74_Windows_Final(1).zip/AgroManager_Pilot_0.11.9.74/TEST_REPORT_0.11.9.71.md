# TEST REPORT — AgroManager Pilot 0.11.9.71

## Targeted release checks

- physical dedup audit — **868/868 PASS, 0 warnings**
- equipment full integrity — **13,121 PASS**, 868 physical records
- catalog semantic consistency — **2,612 PASS**
- catalog zero-gap — **1,007 PASS**
- small tractor ecosystem — **107 PASS**
- bale physical logistics — **59 PASS**
- forage chain — **33 PASS**
- root market/capacity — **28 PASS**
- technical integrity — **52/52 PASS**

## Long harness note

`full_farm_economy_harness_0_11_9_55.js` did not complete inside the execution watchdog for this environment. It is recorded as **not completed**, not PASS/FAIL. The release does not alter farm-economy formulas; only catalog identity/consolidation and references were changed.

## Release conclusion

No duplicate physical-name groups remain under the canonical dedup checker, stale `imp41` semantic targeting is removed, and affected bale/root-crop flows remain operational.

Additional cross-system checks:
- catalog depth release — **259/259 PASS**
- road transport expansion — **86/86 PASS**
- system invariants — **25 PASS**
- first-farm UX/economy — **15 PASS**
- outside-work/hiring — **24 PASS**
- project continuity — **11/11 PASS**
