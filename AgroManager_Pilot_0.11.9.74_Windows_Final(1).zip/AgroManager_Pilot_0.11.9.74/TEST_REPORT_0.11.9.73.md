# TEST REPORT — AgroManager Pilot 0.11.9.73

## Changes
- Исправлена capacity-модель крупных хозяйств: conventional / Mini-till / No-till, периодическая вспашка, диагностическое глубокорыхление, разные посевные окна и повторное использование техники.
- Новый `technology_portfolio_capacity_0_11_9_73.js`: 22/22 PASS.
- Material refill metadata дополнена для СЗ-3,6М, AMAZONE D8 25 Special, СУПН-6, СУПН-4/4М, Gaspardo MTR 4R, НРУ-0,5 и МВУ-0,5.
- `material_capacity_refill_0_11_9_14.js`: 22 checks PASS.
- Exact-count assertions fertilizer/sprayer заменены на growth-safe coverage assertions.

## Capacity reference
- 38 000 га: peak field tractors ≈ 8; plow units 4.
- 50 000 га: peak field tractors ≈ 10; plow units 5.

Это regression-сценарий, а не утверждение, что каждое реальное хозяйство обязано иметь именно такой парк.
