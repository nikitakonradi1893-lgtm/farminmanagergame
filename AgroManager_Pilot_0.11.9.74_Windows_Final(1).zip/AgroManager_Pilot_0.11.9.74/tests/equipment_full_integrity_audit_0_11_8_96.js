'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=__dirname+'/..';
const ctx={window:{},console}; vm.createContext(ctx); vm.runInContext(fs.readFileSync(root+'/web/equipment.js','utf8'),ctx);
const all=ctx.window.EQUIPMENT_CATALOG||[], active=all.filter(x=>!x.hidden), engines=ctx.window.TRACTOR_ENGINE_VARIANTS||{};
const byId=new Map(all.map(x=>[x.id,x])); let checks=0; const ok=(c,m)=>{assert.ok(c,m);checks++};
ok(active.length>=769,`active catalog unexpectedly shrank, got ${active.length}`);
ok(all.length>=769,`catalog unexpectedly shrank, got ${all.length}`);
ok(new Set(all.map(x=>x.id)).size===all.length,'equipment IDs must be unique');
const required={
 tractor:['id','name','segment','hp','price','fuelLph','years'], combine:['id','name','segment','hp','price','fuelLph','years'],
 implement:['id','name','segment','category','requiredHp','width','speed','price','years'], header:['id','name','segment','category','width','speed','price','years'],
 truck:['id','name','segment','capacityT','bodyM3','roadSpeed','price','fuelLph','years'], trailer:['id','name','segment','capacityT','bodyM3','requiredHp','roadSpeed','price','years'],
 graincart:['id','name','segment','capacityT','bodyM3','requiredHp','roadSpeed','unloadTpm','price','years']};
for(const m of active){
 ok(required[m.type],`${m.id}: unsupported type ${m.type}`);
 for(const k of required[m.type]) ok(m[k]!==undefined&&m[k]!==null&&m[k]!=='' ,`${m.id}: missing ${k}`);
 ok(Number(m.price)>0,`${m.id}: non-positive price`); ok(Array.isArray(m.years)&&m.years.length===2&&m.years[0]<=m.years[1],`${m.id}: invalid years`);
}
const tractors=active.filter(x=>x.type==='tractor'), combines=active.filter(x=>x.type==='combine'), impls=active.filter(x=>x.type==='implement'), headers=active.filter(x=>x.type==='header');
const maxHp=Math.max(...tractors.map(x=>Number(x.hp)||0));
for(const im of impls.filter(x=>!x.selfPropelled)) ok(tractors.some(t=>(Number(t.hp)||0)>=(Number(im.requiredHp)||0)),`${im.id}: no tractor can meet requiredHp ${im.requiredHp}`);
for(const h of headers){
 ok(Array.isArray(h.compatibleCombineIds)&&h.compatibleCombineIds.length>0,`${h.id}: active header has no compatible combine`);
 for(const cid of h.compatibleCombineIds){const c=byId.get(cid);ok(c&&c.type==='combine'&&!c.hidden,`${h.id}: invalid compatible combine ${cid}`);ok(c.compatibleHeaderIds.includes(h.id),`${h.id}<->${cid}: matrix not reciprocal`);}
}
for(const c of combines){ok(Array.isArray(c.compatibleHeaderIds)&&c.compatibleHeaderIds.length>0,`${c.id}: combine has no compatible header`);}
for(const t of tractors){
 const vs=engines[t.id]; if(!vs) continue;
 ok(vs.filter(v=>v.stock).length===1,`${t.id}: must have exactly one stock engine variant`);
 const st=vs.find(v=>v.stock);ok(Math.abs(Number(st.hp)-Number(t.hp))<=2,`${t.id}: model hp ${t.hp} differs from stock engine ${st.hp}`);
 ok(Math.abs(Number(st.fuelLph)-Number(t.fuelLph))<=1,`${t.id}: model fuel ${t.fuelLph} differs from stock engine ${st.fuelLph}`);
 for(const v of vs){ok(v.id&&v.name&&Number(v.hp)>0&&Number(v.fuelLph)>0,`${t.id}: malformed engine ${v.id}`);}
}
for(const m of active.filter(x=>['truck','trailer','graincart'].includes(x.type))){if(m.type==='truck'&&m.tractorUnit){ok(Number(m.capacityT)===0&&Number(m.bodyM3)===0&&m.agCargoEligible===false,`${m.id}: tractor unit must not expose standalone cargo capacity`);}else ok(Number(m.capacityT)>0&&Number(m.bodyM3)>0,`${m.id}: transport capacity/body missing`);}
for(const m of active.filter(x=>['tractor','combine','truck'].includes(x.type)||x.selfPropelled)){ok(m.driveType&&Array.isArray(m.availableDriveTypes)&&m.availableDriveTypes.length>0,`${m.id}: powered machine lacks drive type`);}
const hidden=all.filter(x=>x.hidden||x.deprecated);ok(hidden.length===0,'current catalog must not contain hidden/deprecated legacy entries');
console.log(JSON.stringify({pass:true,checks,active:active.length,physical:all.length,counts:Object.fromEntries([...new Set(active.map(x=>x.type))].map(t=>[t,active.filter(x=>x.type===t).length])),powered:active.filter(x=>['tractor','combine','truck'].includes(x.type)||x.selfPropelled).length,passiveImplements:impls.filter(x=>!x.selfPropelled).length,maxTractorHp:maxHp,k700:{modelFuelLph:byId.get('k700').fuelLph,stockFuelLph:(engines.k700||[]).find(x=>x.stock)?.fuelLph},note:'Structural/data-graph integrity. Popular verified tractors can use explicit passport overrides; the rest retain modeled PTO/hydraulic/hitch fallbacks.'},null,2));
