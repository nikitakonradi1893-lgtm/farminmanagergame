const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const C=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{};
const tractors=C.filter(x=>x.type==='tractor'&&!x.hidden), foreign=tractors.filter(x=>String(x.segment).startsWith('foreign'));
let checks=0, variable=0, foreignVariable=0, gradeVariants=0;
for(const m of tractors){
 const vs=V[m.id]||[];
 if(vs.length<2) continue;
 variable++; if(String(m.segment).startsWith('foreign')) foreignVariable++;
 assert(vs.length>=2,`${m.id}: >=2 variants`);checks++;
 assert.strictEqual(vs.filter(x=>x.stock).length,1,`${m.id}: exactly one stock`);checks++;
 assert.strictEqual(new Set(vs.map(x=>x.id)).size,vs.length,`${m.id}: unique variant ids`);checks++;
 const st=vs.find(x=>x.stock); assert.strictEqual(st.hp,m.hp,`${m.id}: stock hp matches catalog`);checks++;
 for(const v of vs){
   assert(v.hp>0&&v.fuelLph>0&&v.swapCost>0&&v.swapHours>=12,`${m.id}/${v.id}: positive figures`);checks++;
   if(v.kind==='power_grade'){gradeVariants++;assert(v.gradeName&&typeof v.gradeName==='string',`${m.id}/${v.id}: gradeName`);checks++;assert(Number.isFinite(Number(v.dealerDelta||0)),`${m.id}/${v.id}: dealerDelta numeric`);checks++;}
 }
 if(m.newAvailable){for(const v of vs){const price=m.price+(Number(v.dealerDelta)||0);assert(price>0,`${m.id}/${v.id}: dealer price positive`);checks++;}}
}
assert(tractors.length>=118,`tractor catalog may expand, got ${tractors.length}`);checks++;assert.strictEqual(new Set(tractors.map(x=>x.id)).size,tractors.length,'tractor ids unique');checks++;
assert(variable>=54,`variant models ${variable}`);checks++;
assert(foreignVariable>=43,`foreign variant models ${foreignVariable}`);checks++;
const exact={
 jd6r215:[223,244,259,281,301],
 fendt728:[223,243,262,282,303],
 fendt942:[296,326,355,385,415],
 nh_t7340:[288,313,340],
 nh_t8435:[320,351,381,409,435],
 versatile365_new:[275,315,335,365],
 df_6230ttv:[192,216,230],
 df_9340ttv:[295,313,336],
 mf_9s370:[285,310,340,370]
};
for(const [id,hps] of Object.entries(exact)){assert.deepStrictEqual(Array.from(V[id]||[],x=>x.hp),hps,`${id}: audited hp grades`);checks++;}
const k=V.k700;assert.strictEqual(k.length,13,'K-700 retrofit variants retained');checks++;
assert(k.find(x=>x.id==='yamz7511_400').fuelLph>k.find(x=>x.id==='yamz238nb_220').fuelLph,'K-700 fuel scaling retained');checks++;
console.log(JSON.stringify({pass:true,tractors:tractors.length,foreignTractors:foreign.length,variantModels:variable,foreignVariantModels:foreignVariable,fixedForeignModels:foreign.length-foreignVariable,powerGradeEntries:gradeVariants,checks},null,2));
