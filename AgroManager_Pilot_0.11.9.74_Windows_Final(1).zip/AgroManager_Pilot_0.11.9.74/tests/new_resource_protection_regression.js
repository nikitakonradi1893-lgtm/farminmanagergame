const fs=require('fs'),assert=require('assert');
const app=fs.readFileSync('web/app.js','utf8');let checks=0;
for(const s of ['NEW_IMPLEMENT_WEAR_PROTECTION_HOURS=2500','NEW_NODE_WEAR_PROTECTION_HOURS=3000','NEW_RUNNING_GEAR_WEAR_PROTECTION_HOURS=1500','function assetWearProtectionLimit(a)','componentNewWearProtected','newWearProtected:true']){assert(app.includes(s),s);checks++;}
// Boundary math mirrors production: protected hours get x0.5 wear, then normal.
const eff=(start,hours,limit)=>{const p=start<limit?Math.max(0,Math.min(hours,limit-start)):0;return Math.max(0,hours-p)+p*.5};
assert.strictEqual(eff(0,1000,2500),500);checks++;
assert.strictEqual(eff(2000,1000,2500),750);checks++;
assert.strictEqual(eff(2500,1000,2500),1000);checks++;
assert.strictEqual(eff(2500,1000,3000),750);checks++;
assert.strictEqual(eff(0,3000,3000),1500);checks++;
console.log(JSON.stringify({pass:true,checks,limits:{dealerImplementHours:2500,majorNodeAndEngineHours:3000,tiresTracksHours:1500},meaning:'new dealer implements and replacement nodes receive half wear only for a finite first resource or until capital overhaul'},null,2));
