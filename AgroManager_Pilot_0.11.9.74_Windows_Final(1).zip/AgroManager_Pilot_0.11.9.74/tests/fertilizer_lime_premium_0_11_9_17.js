const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`lime17-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__lime17={operationImplementWidth,operationImplementSpeed,operationImplementRate,implementSupports,materialRefillPlan,contractTierAvailableForCatalog,contractAttainableTier,generateContractOffer,newAsset,get state(){return state},setOperationPicker(v){operationPicker=v},getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__lime17,E=Array.from(a.getEquip()),model=id=>E.find(x=>x.id===id);let checks=0;
assert(src.includes("version:'0.11.9.74'"));checks++;
const counts=Object.fromEntries(['domestic_used','domestic_new','foreign_used','foreign_new'].map(seg=>[seg,E.filter(m=>m.type==='implement'&&m.category==='fertilizer'&&m.segment===seg).length]));
assert(counts.domestic_used>=3&&counts.domestic_new>=4&&counts.foreign_used>=3&&counts.foreign_new>=7,`fertilizer segment coverage regressed: ${JSON.stringify(counts)}`);checks++;
const mag=model('fert_magnum3000_new'),ax=model('fert_rauch_axent1001_new'),rum1=model('fert_rum1000_new'),rum8=model('fert_rum8m_new'),mvu8=model('imp81'),zats=model('amazone_zats_new');
assert(mag&&mag.hopperL===3000&&mag.width===30&&!mag.limeCapable);checks++;
assert(ax&&ax.hopperL===9400&&ax.dryKg===8400&&ax.limeCapable&&ax.limeWidth===18);checks++;
assert.strictEqual(a.implementSupports(rum1,'lime',null),false);assert.strictEqual(a.implementSupports(zats,'lime',null),false);checks+=2;
assert(a.implementSupports(rum8,'lime',null)&&a.implementSupports(mvu8,'lime',null)&&a.implementSupports(ax,'lime',null));checks++;
assert.strictEqual(a.operationImplementWidth(rum8,'nitrate'),24);assert.strictEqual(a.operationImplementWidth(rum8,'lime'),12);assert.strictEqual(a.operationImplementWidth(ax,'nitrate'),50);assert.strictEqual(a.operationImplementWidth(ax,'lime'),18);checks+=4;
assert(a.operationImplementRate(ax,'nitrate')>a.operationImplementRate(ax,'lime')*2);checks++;
// Build a real bulk-lime support chain: Belarus 1221.3 + Universal 1800 + 1.8 m3 bucket + KamAZ-65115.
const tr=a.newAsset(model('jd6r215'),'new',{year:2026}),ldr=a.newAsset(model('loader_jd_643r'),'new',{year:2026}),bucket=a.newAsset(model('tool_bucket_grain18'),'new',{year:2026}),truck=a.newAsset(model('kamaz65115'),'new',{year:2026});
tr.frontLoaderId=ldr.id;ldr.mountedTractorId=tr.id;ldr.loaderToolId=bucket.id;bucket.mountedLoaderId=ldr.id;a.state.equipment.fleet=[tr,ldr,bucket,truck];
let plan=a.materialRefillPlan({ha:500,distanceKm:10},'lime',null,ax,a.operationImplementRate(ax,'lime'),'bulk_lime',[]);
assert(plan&&plan.mode==='bulk_lime'&&plan.support.ok&&plan.supplyTrips>20&&plan.totalHours<80);checks++;
const base=a.materialRefillPlan({ha:500,distanceKm:10},'lime',null,ax,a.operationImplementRate(ax,'lime'),'base_return',[]);assert(base.totalHours>plan.totalHours*1.35);checks++;
// Stress ladder: professional lime equipment should stay heavy but operationally feasible.
const stress=[];for(const [ha,km] of [[20,5],[80,8],[200,10],[500,15],[1000,20]]){const p=a.materialRefillPlan({ha,distanceKm:km},'lime',null,ax,a.operationImplementRate(ax,'lime'),'bulk_lime',[]);stress.push({ha,km,hours:+p.totalHours.toFixed(1),trips:p.supplyTrips,refills:p.refills});assert(p.totalHours<Math.max(18,ha*.19));checks++;}

// Upper normal annual correction dose from limeRecoveryPlan (2.5 t/ha) must remain schedulable with professional logistics.
a.setOperationPicker({fieldId:-1,op:'lime',fertDose:2.5,supplyMode:'bulk_lime'});const heavy=a.materialRefillPlan({id:-1,ha:500,distanceKm:15},'lime',null,ax,a.operationImplementRate(ax,'lime'),'bulk_lime',[]);assert(heavy.amount===2500&&heavy.totalHours<120&&heavy.supplyTrips>70);checks++;a.setOperationPicker(null);
// Every generated service tier must be attainable. Fertilizer + lime must now have true Premium catalog coverage.
for(const op of ['nitrate','urea','ammophos','npk','potash','lime']){assert(a.contractTierAvailableForCatalog(op,null,'premium'),op+' missing Premium');checks++;}
for(const op of ['ridge','rake','baleHaul']){const t=a.contractAttainableTier(op,op==='ridge'?'potato':'perennial_grass','premium');assert(['economy','standard','premium'].includes(t));checks++;}
let impossible=0,total=0;const st=a.state.contracts;for(let month=0;month<12;month++){const now=new Date(2027,month,15,10).getTime();for(const band of ['small','medium','large'])for(let i=0;i<20;i++){const o=a.generateContractOffer(band,i,now);if(!o)continue;total++;if(!a.contractTierAvailableForCatalog(o.op,o.cropKey,o.tierId))impossible++;}}
assert(total>100&&impossible===0);checks++;
console.log(JSON.stringify({pass:true,checks,counts,stress,totalOffers:total,impossibleOffers:impossible,axent500:{baseH:+base.totalHours.toFixed(1),bulkH:+plan.totalHours.toFixed(1),trips:plan.supplyTrips},axent500Dose25:{hours:+heavy.totalHours.toFixed(1),trips:heavy.supplyTrips,refills:heavy.refills}},null,2));
