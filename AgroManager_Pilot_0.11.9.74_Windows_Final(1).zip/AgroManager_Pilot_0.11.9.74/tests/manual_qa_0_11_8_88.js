const fs=require('fs'),vm=require('vm'),assert=require('assert');
const app=fs.readFileSync('web/app.js','utf8'),css=fs.readFileSync('web/styles.css','utf8'),idx=fs.readFileSync('web/index.html','utf8');
let checks=0;
function fn(name){const start=app.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<app.length;i++){if(app[i]==='{'){d++;seen=true}else if(app[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return app.slice(start,end)}
// 1. Launcher owns a session-close shutdown path, but explicit /quit remains.
const go=fs.readFileSync('launcher_source/main.go','utf8');
for(const x of ['activeSessions','sessionGeneration','stillClosed','shutdown(0)','time.Sleep(2 * time.Second)','mux.HandleFunc("/quit"']){assert(go.includes(x),x);checks++;}
// 2. Release packaging rule is documented separately; source tests remain regression assets.
assert(!/app\.js\.pre70|equipment\.js\.bak59/.test(app));checks++;
// 3/4. Picker changes preserve viewport using an anchor, and contractor/hybrid controls call the preserving renderer.
for(const x of ['anchorTop','scrollBy?.(0,delta)','data-contractor-tier','data-picker-hybrid','renderPreservingViewport()']){assert(app.includes(x),x);checks++;}
// 4/6. Large time jumps are chunked; a 3h event is reached during the first 24h request.
let now=0,ended=false,calls=[];const ctx={state:{gameTime:0,criticalAlert:null},Number,Math,realtimeAdvanceDepth:0};ctx.advanceSystems=(old,target)=>{calls.push([old,target]);if(!ended&&target>=3*3600000)ended=true;return target};vm.createContext(ctx);vm.runInContext(fn('advanceGameTimeTo'),ctx);ctx.advanceGameTimeTo(24*3600000,6);assert(ended);assert.strictEqual(ctx.state.gameTime,24*3600000);assert(calls.length===4);assert(calls.every(([a,b])=>b-a<=6*3600000));checks+=4;
// 5. Fertilizer/machinery picker does not force navigation and can render globally over the current page.
const openFn=fn('openMachineryPicker');assert(!openFn.includes("page=isMeadow"));assert(app.includes('function globalMachineryPickerModal'));assert(app.includes("page==='operations'||page==='meadows'"));checks+=3;
// 7. Harvest logistics exposes three hired transport tiers and selectable counts.
for(const x of ['TRANSPORT_CONTRACTOR_TIERS','Эконом','Стандарт','Премиум','data-transport-contractor-tier','transportContractorCounts','hiredHaulTph']){assert(app.includes(x),x);checks++;}
// 8. Parts are separate used/new/warehouse surfaces and deep-filterable to future equipment model.
for(const x of ['Б/У запчасти','Новые запчасти','data-parts-machine-type','data-parts-brand','data-parts-model','Кировец К-700','partModelDeepMatch']){assert(app.includes(x),x);checks++;}
assert(!app.includes('data-parts-view="market"'));checks++;
// 9. Shared control geometry and mobile readability are centrally styled.
for(const x of ['min-height:38px','text-align:center','white-space:normal','.contractor-tier-controls .btn{width:38px','.deep-parts-filter']){assert(css.includes(x),x);checks++;}
const buttonTags=[...`${app}\n${idx}`.matchAll(/<button\b([^>]*)>/gi)];const bad=buttonTags.filter(m=>{const c=(m[1].match(/class=["']([^"']+)/i)||[])[1]||'';return !/(?:^|\s)(btn|action-btn|ghost|speed|staff-nav-btn|market-staff-btn|nav-item|field-link|link-btn|sale-point|unit-card)(?:\s|$|\$)/.test(c)});assert.deepStrictEqual(bad.map(x=>x[0].slice(0,120)),[]);checks++;
assert(idx.includes('PILOT 0.11.9.74')&&idx.includes('app.js?v=011974'));checks++;
console.log(JSON.stringify({pass:true,checks,timeChunks:calls.length,buttonTags:buttonTags.length},null,2));
