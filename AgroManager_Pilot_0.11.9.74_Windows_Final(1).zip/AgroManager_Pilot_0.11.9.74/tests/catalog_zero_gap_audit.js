'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const C=ctx.window.EQUIPMENT_CATALOG.filter(x=>!x.hidden&&!x.deprecated);
const segs=['domestic_used','domestic_new','foreign_used','foreign_new'];
let checks=0;
const ids=new Set();for(const x of C){assert(!ids.has(x.id),`duplicate id ${x.id}`);ids.add(x.id);checks++;}
for(const type of ['tractor','combine','truck','trailer','header'])for(const seg of segs){assert(C.some(x=>x.segment===seg&&x.type===type),`zero core type ${seg}/${type}`);checks++;}for(const seg of ['domestic_new','foreign_used','foreign_new']){assert(C.some(x=>x.segment===seg&&x.type==='graincart'),`zero graincart segment ${seg}`);checks++;}
const cats=[...new Set(C.filter(x=>x.type==='implement'&&!x.selfPropelled&&x.category!=='field_supply'&&!['silage_leveler','silage_compactor','grain_windrower','fuel_supply_kit','fuel_supply_container'].includes(x.category)).map(x=>x.category))];
const hasCat=(x,cat)=>x.category===cat||(x.categories||[]).includes(cat)||(x.supportedCategories||[]).includes(cat);
// 0.11.9.74: one physical model can supply both dealer-new and live used-market instances.
// A current model is eligible for the used market after two model years, so zero-gap must not require an explicit duplicate '(Б/У)' catalog card.
const suppliesSegment=(x,seg)=>{if(x.segment===seg)return true;if(seg==='domestic_used'&&x.segment==='domestic_new')return (Number(x.years?.[0])||9999)<=2024;if(seg==='foreign_used'&&x.segment==='foreign_new')return (Number(x.years?.[0])||9999)<=2024;return false;};
for(const cat of cats)for(const seg of segs){assert(C.some(x=>suppliesSegment(x,seg)&&x.type==='implement'&&!x.selfPropelled&&hasCat(x,cat)),`zero passive category ${seg}/${cat}`);checks++;}
for(const mode of ['seed_loader','fert_tender','solution_tanker']){assert(C.some(x=>x.fieldSupplyMode===mode),`missing field-supply role ${mode}`);checks++;}assert(C.some(x=>x.category==='front_loader')&&C.some(x=>x.category==='loader_tool'&&x.toolRole==='bigbag_hook'),'missing physical big-bag loader chain');checks++;
const added=['bdm_ks8m','bdm_ks12m','bdm_ks14m','bdm_pchn32m','bdm_pchn45','bdm_gkr25','bdm_gkr4','bdm_ksu6ps','bdm_ksu9ps','rsm_sh8200','rsm_sh12200','rsm_ksu1','tuman3','tonar6328','tonar_pt9','tonar_pt2','tonar_pt5','tonar_pt11','jd915_vripper_used','kelly_diamond_1200_used','einbock_aerostar1200','kleine_kr2_used','man_tgs_agro','scania_super500_grain','fliegl_asw271_used','fliegl_asw281','kinze1321'];
for(const id of added){const x=C.find(y=>y.id===id);assert(x,`missing ${id}`);assert(x.price>0,`${id} price`);checks++;}
assert(C.length>=769,`catalog size unexpectedly shrank: ${C.length}`);checks++;
console.log(`PASS catalog_zero_gap_audit ${checks} checks; catalog=${C.length}`);
