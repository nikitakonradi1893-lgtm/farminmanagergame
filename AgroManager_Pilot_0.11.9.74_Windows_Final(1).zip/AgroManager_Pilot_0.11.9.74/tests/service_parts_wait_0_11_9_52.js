const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
function storage(){return{getItem(){return null},setItem(){},removeItem(){}}}
const document={getElementById(){return{textContent:'',classList:{add(){},remove(){}},innerHTML:'',addEventListener(){},style:{}}},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){},body:{classList:{add(){},remove(){}}}};
class XHR{open(){}send(){}setRequestHeader(){}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/equipment.js'),'utf8'),ctx);
let src=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');let p=src.lastIndexOf('})();');src=src.slice(0,p)+`\nwindow.__svc={CONFIG,equipmentModel,normalizeAsset,freshState,serviceProfile,serviceQuote,serviceExecutionPlan,servicePartsLogistics};\n`+src.slice(p);vm.runInContext(src,ctx,{timeout:30000});
const h=ctx.__svc;assert.strictEqual(h.CONFIG.version,'0.11.9.74');
function asset(modelId,repairReason=''){const x=h.normalizeAsset({id:'svc-test',modelId,condition:80,hours:3000,source:'used'},0);x.repairReason=repairReason;x.repairSystem='engine';x.breakdownFieldId='field-test';return x;}
const hes=asset('hesston_8100_grain','Неисправность: Двигатель');ctx.state=h.freshState('very_hard');ctx.state.equipment.fleet=[hes];
const hp=h.serviceProfile(h.equipmentModel(hes.modelId));assert.strictEqual(hp.partsDays,6);
const hplan=h.serviceExecutionPlan(hes,'engine','partial'), hparts=h.servicePartsLogistics(hes,'engine','partial',hplan);
assert.strictEqual(hparts.source,'import_order');assert(hparts.waitH>=6*24*0.99,'old foreign breakdown must create ~6 calendar days parts wait');
const labor=h.serviceQuote(hes,'partial','engine').hours;assert.strictEqual(labor,5,'parts lead time must not be hidden inside labor hours');
assert(hparts.waitH>labor*20,'parts logistics must dominate old-import downtime');
const planned=asset('hesston_8100_grain','');ctx.state.equipment.fleet=[planned];const pp=h.servicePartsLogistics(planned,'engine','partial',h.serviceExecutionPlan(planned,'engine','partial'));assert.strictEqual(pp.waitH,0,'planned service assumes parts can be procured before downtime');
const k700=asset('k700','Неисправность: Двигатель');ctx.state.equipment.fleet=[k700];const kp=h.servicePartsLogistics(k700,'engine','partial',h.serviceExecutionPlan(k700,'engine','partial'));assert.strictEqual(kp.source,'local_stock');assert.strictEqual(kp.waitH,24,'old domestic local parts lead time is one day');
const srcText=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');assert(srcText.includes('partsWaitH:partsPlan.waitH'));assert(srcText.includes('aCalendarH=serviceCalendarH+plan.arrivalH+plan.tow.hours+partsPlan.waitH'));
console.log(JSON.stringify({pass:true,checks:12,hesston:{partsDays:hp.partsDays,waitH:hparts.waitH,laborH:labor,source:hparts.source},k700:{waitH:kp.waitH,source:kp.source},meaning:'после случайной поломки partsDays теперь создаёт реальный календарный простой; плановое ТО не ждёт детали во время простоя'},null,2));
