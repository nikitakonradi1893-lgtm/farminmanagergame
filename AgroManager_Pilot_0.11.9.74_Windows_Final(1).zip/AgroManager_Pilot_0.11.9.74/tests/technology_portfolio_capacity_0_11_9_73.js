#!/usr/bin/env node
'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=process.cwd();
const code=fs.readFileSync(path.join(root,'web','equipment.js'),'utf8');
const sb={window:{},console};vm.createContext(sb);vm.runInContext(code,sb);
const E=sb.window.EQUIPMENT_CATALOG||[];
const availability=.80;
const areas=[1000,5000,10000,25000,38000,50000];
// Planning portfolio, not a world-average claim. It exists to prevent the regression
// "100% of farm area receives every tillage operation every season".
const portfolio={
 conventional:.30,minTill:.45,noTill:.25,cropped:.92,
 plowCycleYears:4,deepRipAnnualShare:.08,
 // Share of each technology receiving secondary tillage in a typical season.
 conventionalDisk:.35,minTillDisk:.80,conventionalCultivate:1.0,minTillCultivate:.40,
 // Cropped area split into non-overlapping sowing windows. Same fleet is reused between windows.
 sowWindows:{autumnGrain:.28,earlySpringGrain:.30,lateSpringGrain:.17,rowCrops:.17},
 // Peak share needing fertilizer / crop protection inside one short treatment window.
 peakTreatmentShare:.35
};
const hours={plow:240,deepRip:180,cultivate:180,disk:180,sowGrain:200,sowRow:180,fertilizer:72,sprayer:72};
function rate(m){return Number(m.fieldCapacityHaH)||((Number(m.width)||0)*(Number(m.speed)||0)*(Number(m.eff)||.8)/10)}
function best(cat,filter=()=>true){return E.filter(m=>m.type==='implement'&&m.category===cat&&filter(m)&&rate(m)>0).sort((a,b)=>rate(b)-rate(a))[0]||null}
function modes(m){return Array.isArray(m.seedingModes)?m.seedingModes:['conventional']}
function cap(area,m,h){return Math.ceil(area/Math.max(.001,rate(m)*h*availability))}
const M={
 plow:best('plow'),deepRip:best('deepRip'),cultivate:best('cultivate'),disk:best('disk'),
 sowConv:best('sow_grain',m=>modes(m).includes('conventional')),
 sowReduced:best('sow_grain',m=>modes(m).includes('minTill')&&modes(m).includes('noTill')),
 sowRow:best('sow_row'),fertilizer:best('fertilizer'),sprayer:best('sprayer')
};
for(const [k,m] of Object.entries(M))assert(m,`missing capacity machine: ${k}`);
let checks=0;
function ok(x,msg){assert(x,msg);checks++;}
const rows=[];
for(const area of areas){
 const cropped=area*portfolio.cropped;
 const annual={
  plow:area*portfolio.conventional/portfolio.plowCycleYears,
  deepRip:area*portfolio.deepRipAnnualShare,
  cultivate:area*(portfolio.conventional*portfolio.conventionalCultivate+portfolio.minTill*portfolio.minTillCultivate),
  disk:area*(portfolio.conventional*portfolio.conventionalDisk+portfolio.minTill*portfolio.minTillDisk),
  fertilizer:cropped*portfolio.peakTreatmentShare,
  sprayer:cropped*portfolio.peakTreatmentShare
 };
 // Cultivation and disk work are split between autumn/spring windows; same fleet is reused.
 const U={
  plow:cap(annual.plow,M.plow,hours.plow),
  deepRip:cap(annual.deepRip,M.deepRip,hours.deepRip),
  cultivate:cap(annual.cultivate*.55,M.cultivate,hours.cultivate),
  disk:cap(annual.disk*.60,M.disk,hours.disk),
  fertilizer:cap(annual.fertilizer,M.fertilizer,hours.fertilizer),
  sprayer:cap(annual.sprayer,M.sprayer,hours.sprayer)
 };
 let maxGrainSeeders=0;
 for(const [window,share] of Object.entries(portfolio.sowWindows)){
  if(window==='rowCrops')continue;
  const a=cropped*share,conv=a*portfolio.conventional,reduced=a*(portfolio.minTill+portfolio.noTill);
  const n=cap(conv,M.sowConv,hours.sowGrain)+cap(reduced,M.sowReduced,hours.sowGrain);
  maxGrainSeeders=Math.max(maxGrainSeeders,n);
 }
 U.sowGrain=maxGrainSeeders;
 U.sowRow=cap(cropped*portfolio.sowWindows.rowCrops,M.sowRow,hours.sowRow);
 // Tractor demand is a peak, not the sum of implements used at different times of year.
 U.peakTillageTractors=Math.max(U.plow+U.deepRip,U.cultivate+U.disk);
 U.peakSeedingTractors=U.sowGrain+U.sowRow;
 U.peakFieldTractors=Math.max(U.peakTillageTractors,U.peakSeedingTractors,U.fertilizer,U.sprayer);
 rows.push({area,annualArea:Object.fromEntries(Object.entries(annual).map(([k,v])=>[k,Math.round(v)])),units:U});
 ok(annual.plow<area*.15,`${area}: annual plow area should be a minority, got ${annual.plow}`);
 ok(annual.deepRip<=area*.10,`${area}: deep rip should remain diagnostic/periodic`);
 ok(U.peakFieldTractors<Math.max(8,Math.ceil(area/1500)),`${area}: fleet scaling exploded: ${U.peakFieldTractors}`);
}
const r38=rows.find(x=>x.area===38000),r50=rows.find(x=>x.area===50000);
ok(r38.units.plow<=4,`38k ha plow fleet too large: ${r38.units.plow}`);
ok(r50.units.plow<=5,`50k ha plow fleet too large: ${r50.units.plow}`);
ok(r38.units.peakFieldTractors<=18,`38k peak field tractors too large: ${r38.units.peakFieldTractors}`);
ok(r50.units.peakFieldTractors<=22,`50k peak field tractors too large: ${r50.units.peakFieldTractors}`);
console.log(JSON.stringify({portfolio,machines:Object.fromEntries(Object.entries(M).map(([k,m])=>[k,{id:m.id,name:m.name,rate:+rate(m).toFixed(2)}])),rows,checks},null,2));
console.log(`technology portfolio capacity: ${checks}/${checks} PASS`);
