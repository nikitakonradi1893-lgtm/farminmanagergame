const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`cl61-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__cl61={LAND_CLUSTERS,travelPlan,assignLandCluster,landClusterLabel,sameClusterDistanceKm,setAssetFieldLocation,assetLocationLabel,freshState,setState(x){state=x},getState(){return state},equipmentRoadSpeed,machineRoadFuelLph,getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__cl61;
let checks=0;
assert.strictEqual(a.LAND_CLUSTERS.length,8);checks++;
assert.deepStrictEqual(Array.from(a.LAND_CLUSTERS,x=>x.id),['N','NE','E','SE','S','SW','W','NW']);checks++;
assert.deepStrictEqual(Array.from(a.LAND_CLUSTERS,x=>x.label),['Север','Северо-Восток','Восток','Юго-Восток','Юг','Юго-Запад','Запад','Северо-Запад']);checks++;
const st=a.freshState('medium');a.setState(st);
const samples=Array.from({length:64},(_,i)=>({id:1000+i,code:`F-${1000+i}`,distanceKm:10+(i%20),ha:20,owned:true}));
for(const f of samples)a.assignLandCluster(f,12345);
const ids=new Set(samples.map(x=>x.clusterId));assert.strictEqual(ids.size,8);checks++;
const snapshot=samples.map(x=>[x.id,x.clusterId,x.clusterPosition]);for(const f of samples){delete f.clusterId;delete f.clusterPosition;a.assignLandCluster(f,12345)}assert.deepStrictEqual(samples.map(x=>[x.id,x.clusterId,x.clusterPosition]),snapshot);checks++;
const a1={id:1,code:'F-0001',distanceKm:25,clusterId:'N',clusterPosition:.1},a2={id:2,code:'F-0002',distanceKm:28,clusterId:'N',clusterPosition:.2},b1={id:3,code:'F-0003',distanceKm:22,clusterId:'S',clusterPosition:.2};
assert(a.sameClusterDistanceKm(a1,a2)<a1.distanceKm+a2.distanceKm);checks++;
assert.strictEqual(a.sameClusterDistanceKm(a1,b1),a1.distanceKm+b1.distanceKm);checks++;
st.fields=[a1,a2,b1];const asset={id:'T1',modelId:'mtz82',farmId:'T-001',locationType:'base',locationFieldId:null};a.setAssetFieldLocation(asset,a1);assert.strictEqual(asset.locationType,'field');assert.strictEqual(asset.locationFieldId,1);assert.strictEqual(asset.locationClusterId,'N');checks+=3;
assert(a.assetLocationLabel(asset).includes('F-0001')&&a.assetLocationLabel(asset).includes('Север'));checks++;
const q=a.travelPlan(a2,[asset]);assert(q.distanceKm<10,'same-cluster relocation should be short');checks++;
a.setAssetFieldLocation(asset,b1);assert(asset.locationClusterId==='S');checks++;
const meadow={id:9001,code:'H-9001',distanceKm:17,ha:12,isMeadow:true};a.assignLandCluster(meadow,12345);assert(ids.has(meadow.clusterId));checks++;
console.log(JSON.stringify({pass:true,checks,clusters:Array.from(ids).sort(),sampleSameClusterKm:+a.sameClusterDistanceKm(a1,a2).toFixed(2),sampleCrossClusterKm:+a.sameClusterDistanceKm(a1,b1).toFixed(2)},null,2));
