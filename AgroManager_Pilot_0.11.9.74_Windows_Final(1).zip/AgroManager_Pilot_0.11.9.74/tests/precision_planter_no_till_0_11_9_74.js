#!/usr/bin/env node
'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=process.cwd();
const eq=fs.readFileSync(path.join(root,'web','equipment.js'),'utf8');
const app=fs.readFileSync(path.join(root,'web','app.js'),'utf8');
const s={window:{},console};vm.createContext(s);vm.runInContext(eq,s);
const C=s.window.EQUIPMENT_CATALOG||[];
let pass=0,fail=0;const ok=(x,m)=>{if(x)pass++;else{fail++;console.log('FAIL',m)}};
const row=C.filter(x=>x.type==='implement'&&x.category==='sow_row');
ok(row.length>=20,`precision-planter depth ${row.length} >= 20`);
ok(row.every(x=>x.precisionPlanter===true),'every sow_row record marked precisionPlanter');
for(const id of ['imp77','vaderstad_tempo_l24','brand_case_er1255','brand_case_er2150']){
 const m=C.find(x=>x.id===id); ok(!!m,`${id} exists`); if(!m)continue;
 ok(m.category==='sow_row',`${id} remains sow_row internally`);
 ok(Array.isArray(m.seedingModes)&&m.seedingModes.includes('noTill'),`${id} supports noTill`);
 ok(m.directDrill===true,`${id} directDrill=true`);
}
const nt=row.filter(x=>x.directDrill&&Array.isArray(x.seedingModes)&&x.seedingModes.includes('noTill'));
ok(nt.length>=4,`No-Till precision planters >=4, got ${nt.length}`);
ok(nt.some(x=>x.segment.includes('used')),'No-Till precision planters include used-market class');
ok(nt.some(x=>x.segment.includes('new')),'No-Till precision planters include new-market class');
ok(Math.min(...nt.map(x=>x.requiredHp||9999))<=180,'No-Till precision planter available <=180 hp');
ok(Math.max(...nt.map(x=>x.width||0))>=12,'No-Till precision planter available >=12 m');
ok(app.includes("sow_row:'Сеялки точного высева'"),'user-facing category renamed');
ok(!app.includes("sow_row:'Пропашные сеялки'"),'old category label removed');
ok(app.includes("data-ef=\"seedingTech\""),'seeding technology filter exists');
ok(app.includes("value=\"noTill\""),'No-Till filter option exists');
ok(app.includes("value=\"directDrill\""),'direct-drill filter option exists');
ok(app.includes("if(f.seedingTech==='directDrill')"),'technology filter wired to model matching');
ok(app.includes("ops.push('Точный посев')"),'operation summary uses precision-seeding wording');
console.log(`PRECISION_PLANTER_NO_TILL pass=${pass} fail=${fail} row=${row.length} noTillRow=${nt.length}`);
console.log(nt.map(x=>`${x.id} | ${x.name} | ${x.segment} | ${x.requiredHp} hp | ${x.width} m`).join('\n'));
process.exitCode=fail?1:0;
