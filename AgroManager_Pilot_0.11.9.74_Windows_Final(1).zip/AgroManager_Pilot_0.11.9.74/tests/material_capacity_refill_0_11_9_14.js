const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`cap14-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__cap14={materialRefillPlan,applyMaterialRefillToUnit,operationMaterialDemandPerHa,getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__cap14,equip=Array.from(a.getEquip());let checks=0;
assert(src.includes("version:'0.11.9.74'"));checks++;
for(const cat of ['sow_grain','sow_row']){const xs=equip.filter(m=>m.type==='implement'&&m.category===cat);assert(xs.length>0);assert.strictEqual(xs.filter(m=>!(Number(m.seedHopperL)>0||Number(m.seedHopperKg)>0)).length,0,cat+' missing seed hopper');checks+=2;}for(const [cat,key] of [['fertilizer','dryKg'],['sprayer','tankL']]){const xs=equip.filter(m=>m.type==='implement'&&m.category===cat);assert(xs.length>0);assert.strictEqual(xs.filter(m=>!(Number(m[key])>0)).length,0,cat+' missing capacity');checks+=2;}
const counts=cat=>Object.fromEntries(['domestic_used','domestic_new','foreign_used','foreign_new'].map(k=>[k,equip.filter(m=>m.type==='implement'&&m.category===cat&&m.segment===k).length]));
{const c=counts('fertilizer');assert(c.domestic_used>=3&&c.domestic_new>=4&&c.foreign_used>=3&&c.foreign_new>=7,`fertilizer coverage regressed: ${JSON.stringify(c)}`);checks++;}
{const c=counts('sprayer');assert(c.domestic_used>=3&&c.domestic_new>=4&&c.foreign_used>=6&&c.foreign_new>=10,`sprayer coverage regressed: ${JSON.stringify(c)}`);checks++;}
const rum=equip.find(m=>m.id==='fert_rum1000_new'),lime=equip.find(m=>m.id==='fert_rum8m_new'),on=equip.find(m=>m.id==='spr_on60012_new'),jm=equip.find(m=>m.id==='spr_jarmet_p1282_new');
assert(rum&&rum.dryKg===1000&&rum.width===12);assert(on&&on.tankL===600&&on.width===12);assert(jm&&jm.tankL===400&&jm.width===10);checks+=3;
const sz=equip.find(m=>m.name==='СЗ-3,6');let p=a.materialRefillPlan({ha:200,distanceKm:5},'sow','peas',sz,2.2);assert(p&&p.refills>50&&p.refillHours>0&&p.effectiveRate<2.2);checks++;
assert(lime&&lime.limeCapable&&lime.limeWidth===12);checks++;p=a.materialRefillPlan({ha:100,distanceKm:5},'lime',null,lime,8);assert(p&&Math.abs(p.perFillHa-8)<1e-9&&p.refills===12);checks++;
p=a.materialRefillPlan({ha:100,distanceKm:5},'herbicide','spring_wheat',jm,8);assert(p&&Math.abs(p.perFillHa-2)<1e-9&&p.refills===49);checks++;
const adjusted=a.applyMaterialRefillToUnit({rate:8,fuelLph:20},{ha:100,distanceKm:5},'herbicide','spring_wheat',jm);assert(adjusted.rate<8&&adjusted.fuelLph<20&&adjusted.materialLogistics.fuelFactor>0);checks++;
assert(src.includes("out.push(applyMaterialRefillToUnit({key:`ri:${ta.id}:${im.id}`"));checks++;
assert(src.includes('конструктивно семена + удобрения'));checks++;
assert(src.includes('DEFAULT_SPRAY_SOLUTION_L_HA=200'));checks++;
console.log(JSON.stringify({pass:true,checks,counts:{fertilizer:counts('fertilizer'),sprayer:counts('sprayer')}},null,2));
