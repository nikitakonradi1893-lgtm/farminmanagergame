const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`),end=src.indexOf(`\n${next}`,start);assert(start>=0&&end>start,`${name}/${next}`);return src.slice(start,end)+';'}
const ctx={Math,Number,Date};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(n,d=1)=>Number(n).toFixed(d);ctx.state={gameTime:new Date(2031,7,20).getTime()};vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);
for(const n of ['targetYieldRange','yieldTargetFor','targetNutrientNeeds','factorFromNutrientAmounts','yieldFactorGroup','yieldFactorMode','yieldWaterfall','yieldGroupSummary'])vm.runInContext(fn(n),ctx);
ctx.cropDef=f=>ctx.CROPS[f.crop];ctx.soilFactors=()=>({seedbed:1,compaction:1,weeds:1,residue:1});ctx.effectiveSowTimingFactor=()=>1;ctx.rotationFactorFor=()=>1;ctx.cropWeedFactor=()=>1;ctx.protectionFactor=()=>1;ctx.pHFactor=()=>1;ctx.harvestTimingFactor=()=>1;ctx.maturityAt=()=>0;ctx.nitrogenExcessRisk=()=>0;ctx.nitrogenExcessFactor=()=>1;ctx.fieldSpatialZones=()=>[{id:'A',share:1,fertility:1}];
ctx.nutrientSupply=()=>({N:82,P:58,K:54});
vm.runInContext(fn('nutrientFactor'),ctx);
ctx.spatialNutritionAdjustment=()=>1;
vm.runInContext(fn('yieldBreakdown'),ctx);
function field(target){return{crop:'spring_wheat',plantedAt:new Date(2031,3,10).getTime(),seasonYieldTarget:target,soil:{},establishmentFactors:{seedbed:1,compaction:1,weeds:1,residue:1},weatherFactor:1,trafficFactor:1,rotationFactor:1,seedQualityFactor:1,sowingEquipmentFactor:1,cropProtection:{diseasePressure:0,pestPressure:0}}}
let checks=0;
const low=ctx.yieldBreakdown(field(2.5)),high=ctx.yieldBreakdown(field(4.0));
assert(low&&high);checks++;
assert(low.factors[0].key==='targetIntensity'&&high.factors[0].key==='targetIntensity');checks++;
assert(Math.abs(low.factors[0].afterYield-2.5)<1e-9);checks++;
assert(Math.abs(high.factors[0].afterYield-4.0)<1e-9);checks++;
assert(high.factors.find(x=>x.key==='nutrition').value<low.factors.find(x=>x.key==='nutrition').value);checks++;
assert(high.yieldPerHa>low.yieldPerHa);checks++;
assert(src.includes('Целевая интенсивность технологии'));checks++;
assert(src.includes('потребности выбранной цели урожайности'));checks++;
assert(src.includes("version:'0.11.9.74'"));checks++;
console.log(JSON.stringify({pass:true,checks,low:{target:low.targetYield,yield:low.yieldPerHa,nutrition:low.factors.find(x=>x.key==='nutrition').value},high:{target:high.targetYield,yield:high.yieldPerHa,nutrition:high.factors.find(x=>x.key==='nutrition').value}},null,2));
