const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG.filter(x=>!x.hidden);
const rate=m=>m.width*m.speed*(m.eff||.78)/10;
const cats=['disk','deepRip','cultivate','stubble','sow_grain','sow_row']; const tiers=[300,350,400,450,500,560,600,720];
const best=(hp,c)=>E.filter(m=>m.type==='implement'&&m.category===c&&(m.requiredHp||0)<=hp).sort((a,b)=>rate(b)-rate(a))[0];
const out={};let checks=0;for(const hp of tiers){let h=0,cost=0;const picks={};for(const c of cats){const m=best(hp,c);assert(m,`no ${c} at ${hp}`);h+=1000/rate(m);cost+=m.price;picks[c]={name:m.name,hp:m.requiredHp,rate:+rate(m).toFixed(2)};}out[hp]={hours:+h.toFixed(1),capexM:+(cost/1e6).toFixed(1),picks};}
for(let i=1;i<tiers.length;i++){assert(out[tiers[i]].hours<=out[tiers[i-1]].hours+0.01,'higher tier slower');checks++;}
assert(out[450].hours<out[400].hours*.999,'400->450 has no useful step');checks++;
assert(out[500].hours<out[450].hours*.90,'450->500 has no useful step');checks++;
assert(out[600].hours<out[500].hours*.88,'500->600 should remain material');checks++;
assert(out[720].hours<out[600].hours,'720 should add a narrower gain');checks++;
assert(out[600].capexM>out[400].capexM*1.25,'high power package too cheap');checks++;
console.log(JSON.stringify({pass:true,checks,areaHaPerOperation:1000,powerLadder:out},null,2));
