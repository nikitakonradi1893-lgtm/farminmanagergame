const fs=require('fs'),vm=require('vm');
const box={window:{},console};vm.createContext(box);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),box);
const E=box.window.EQUIPMENT_CATALOG, tractors=E.filter(x=>x.type==='tractor');let pass=0;
function ok(v,msg){if(!v)throw new Error(msg);pass++;}
for(const [id,hp] of [['jd_9rx640_new',691],['nh_t9700_new',699],['fendt_1167mt_new',680]]){const m=E.find(x=>x.id===id);ok(m&&m.hp===hp&&m.newAvailable,`${id} missing/wrong hp`);}
const heavy=tractors.filter(x=>x.hp>=500);ok(heavy.length>=8,'heavy tractor ladder too narrow');
for(const id of ['salford_i2100_50','case_ecolotiger875_26','horsch_panther460','jd_2730_26']){const m=E.find(x=>x.id===id);const n=tractors.filter(t=>t.hp>=m.requiredHp).length;ok(n>=2,`${id}: fewer than 2 capable tractors`);}
const sal=E.find(x=>x.id==='salford_i2100_60');ok(sal.requiredHp===720,'Salford 60ft must preserve verified 720 hp requirement');ok(tractors.some(t=>t.hp>=720),'no tractor can pull Salford 60ft');
console.log(`heavy_endgame_ecosystem_0_11_9_67: ${pass} PASS`);
