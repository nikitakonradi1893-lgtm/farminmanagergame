const fs=require('fs'),vm=require('vm'),assert=require('assert');let checks=0;const ok=(v,m)=>{assert(v,m);checks++};
const ctx={window:{},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG,M=id=>E.find(x=>x.id===id);
const app=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');ok(app.includes("version:'0.11.9.74'"),'runtime version');ok(idx.includes('PILOT 0.11.9.74')&&idx.includes('011974'),'index/cache');
const ids=['2pts9','2pts11','3pts12','pronar_t653_2','pronar_t680','joskin_transcap_5500_15','krampe_bigbody650','joskin_transspace_9200','krampe_bigbody900'];
for(const id of ids){const m=M(id);ok(!!m,id);ok(m.type==='trailer'&&!m.truckTrailer,id+' tractor trailer');ok(Number(m.capacityT)>0&&Number(m.bodyM3)>0,id+' capacity');ok(Number(m.requiredHp)>0,id+' hp');}
ok(M('2pts11').capacityT===11,'2PTS-11 payload');ok(M('2pts11').segment==='domestic_used','2PTS-11 historical class');
const stockExpected={
 '2pts4':[4,5.0,16.5],'2pts6':[6,4.6,10.8],'pst9':[9,10.5,17.5],'pst12':[12,12.5,19.5],'pst18':[18,15.5,31.0],
 'pronar_t653_2':[6,4.1,8.2],'pronar_t680':[13.1,9.8,17.2],'joskin_transcap_5500_15':[14,15.5,27.7],
 'krampe_bigbody650':[15.5,21.9,36.2],'joskin_transspace_9200':[26,30.8,36.2],'krampe_bigbody900':[25.7,30.3,50.1]
};
for(const [id,[payload,base,max]] of Object.entries(stockExpected)){const m=M(id);ok(Math.abs(m.capacityT-payload)<1e-9,id+' payload');ok(Math.abs(m.bodyM3-base)<1e-9,id+' base body');ok(Array.isArray(m.bodyConfigs)&&m.bodyConfigs.length>=2,id+' body configs');const s=m.bodyConfigs.find(x=>x.stock);ok(s&&Math.abs(s.bodyM3-base)<1e-9,id+' stock body');ok(Math.abs(Math.max(...m.bodyConfigs.map(x=>x.bodyM3))-max)<1e-9,id+' max body');for(const b of m.bodyConfigs)ok(m.capacityT===payload,id+' sideboards do not alter payload');}
ok(M('krampe_bigbody900').bodyConfigs.some(x=>x.bodyM3===42.2),'BigBody 900 42.2 m3 option');ok(M('krampe_bigbody900').requiredHp===190,'BigBody 900 190 hp');ok(M('krampe_bigbody650').requiredHp===140,'BigBody 650 140 hp');ok(M('pronar_t680').requiredHp===110,'T680 power');
const tractorTrailers=E.filter(x=>x.type==='trailer'&&!x.truckTrailer);ok(tractorTrailers.length>=19,'expanded tractor trailer count');
console.log(`Tractor trailer expansion 0.11.9.24: ${checks}/${checks} PASS`);
