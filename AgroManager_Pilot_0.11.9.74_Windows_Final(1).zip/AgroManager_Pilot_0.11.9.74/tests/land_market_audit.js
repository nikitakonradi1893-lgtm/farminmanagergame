const fs=require('fs'),vm=require('vm');
const path=require('path'); const root=path.resolve(__dirname,'..');
let eq=fs.readFileSync(root+'/web/equipment.js','utf8');
let app=fs.readFileSync(root+'/web/app.js','utf8');
const cut=app.indexOf("document.getElementById('nav').addEventListener");
if(cut<0) throw new Error('cut marker not found');
app=app.slice(0,cut)+`\nglobalThis.__T={freshState,normalize,refreshLandListings,processMarketLandDynamics,landHoldingFields,landHoldingArea,landHoldingPrice,landPrice,leaseInitialCost,generateLandMarket,ensureLandHoldings,activateLandFieldListing,rngFactory,buyField,leaseField,CONFIG,DAY,setState:(x)=>state=x,getState:()=>state};\n})();`;
const sandbox={console,window:{},crypto:require('crypto').webcrypto,Intl,Date,Math,setTimeout,clearTimeout,XMLHttpRequest:function(){},localStorage:{getItem(){return null},setItem(){}},fetch:async()=>({ok:true}),document:{getElementById(){return {textContent:'',classList:{add(){},remove(){}}}}}};
sandbox.globalThis=sandbox;
vm.createContext(sandbox);vm.runInContext(eq,sandbox,{filename:'equipment.js'});vm.runInContext(app,sandbox,{filename:'app.js'});
const T=sandbox.__T;
function makeState(seed){const s=T.freshState();s.landSeed=seed;s.fields=T.generateLandMarket(seed);s.landHoldings=T.ensureLandHoldings(seed,s.fields,[]);for(const f of s.fields){f.landProfile.marketListed=false;f.landProfile.marketListedAt=null;f.landProfile.marketExpiresAt=null;}for(const h of s.landHoldings){h.status='off_market';h.listedAt=null;h.expiresAt=null;}const r=T.rngFactory((seed^0x51A7D)>>>0),pool=s.fields.filter(f=>!f.owned&&!f.landProfile?.holdingId);for(let i=pool.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[pool[i],pool[j]]=[pool[j],pool[i]];}const target=Math.min(42,Math.max(30,Math.round(pool.length*.038)));for(let i=0;i<target&&pool.length;i++)T.activateLandFieldListing(pool.pop(),s.gameTime,r);for(const h of s.landHoldings.slice(0,1)){h.status='listed';h.listedAt=s.gameTime;h.expiresAt=s.gameTime+(120+Math.floor(r()*181))*T.DAY;}s.landMarketRefreshDay=null;return s;}
function assert(x,m){if(!x)throw new Error(m)}
function stats(a){if(!a.length)return{n:0,mean:0,min:0,max:0};return{n:a.length,mean:a.reduce((x,y)=>x+y,0)/a.length,min:Math.min(...a),max:Math.max(...a)}}
let invariantChecks=0, expiryChecks=0, modeCounts={both:0,lease_only:0,buy_only:0}, dist=[];
let yearly=[];
for(let seed=1;seed<=10;seed++){
  const base=makeState(seed); T.setState(base);
  for(const f of base.fields) if(!f.owned) dist.push(f.distanceKm||0);
  for(let day=0;day<365*2;day++){
    const now=new Date(2026,0,1+day,8).getTime(); base.gameTime=now; T.refreshLandListings(now,true);
    if(day%30===0){
      const held=new Set(); for(const h of base.landHoldings||[]) for(const id of h.fieldIds||[]) {assert(!held.has(id),'field duplicated across holdings');held.add(id); invariantChecks++;}
      for(const f of base.fields){if(f.landProfile?.marketListed){assert(!f.landProfile.holdingId,'field both individual and holding');assert(!f.owned,'owned field listed');modeCounts[f.landProfile.marketMode]=(modeCounts[f.landProfile.marketMode]||0)+1; invariantChecks++; if(Number(f.landProfile.marketExpiresAt)<=now) throw new Error('expired listing active');}}
      for(const h of base.landHoldings||[]){if(h.status==='listed'){const fs2=T.landHoldingFields(h);assert(fs2.length===(h.fieldIds||[]).length,'holding missing member');assert(fs2.every(f=>!f.owned&&!f.landProfile?.marketListed),'holding member conflict');invariantChecks++;}}
    }
    if(day%365===0){const listed=base.fields.filter(f=>f.landProfile?.marketListed);yearly.push({seed,year:2026+Math.floor(day/365),count:listed.length,ha:listed.reduce((a,f)=>a+f.ha,0),avgDist:stats(listed.map(f=>f.distanceKm)).mean,holdings:(base.landHoldings||[]).filter(h=>h.status==='listed').length});}
  }
}
// explicit expiry test
{const s=makeState(999);T.setState(s);T.refreshLandListings(s.gameTime,true);const f=s.fields.find(f=>f.landProfile?.marketListed);assert(f,'need listing');const exp=f.landProfile.marketExpiresAt;T.refreshLandListings(exp+T.DAY,true);assert(!f.landProfile.marketListed,'expired field stayed listed');expiryChecks++;}
// Opportunity acquisition simulation: at each monthly market snapshot, acquire listed fields nearest-first until target.
function acquisition(seed,target){let s=makeState(seed);T.setState(s);let ha=0,bought=[],waitDays=0,cost=0;for(let day=0;day<365*20&&ha<target;day++){const now=new Date(2026,0,1+day,8).getTime();s.gameTime=now;T.refreshLandListings(now,true);let offers=s.fields.filter(f=>!f.owned&&f.landProfile?.marketListed&&!f.landProfile?.holdingId).sort((a,b)=>(a.distanceKm-b.distanceKm)||(T.landPrice(a)-T.landPrice(b)));let took=0;for(const f of offers){if(ha>=target)break;f.owned=true;f.tenure=f.landProfile.marketMode==='buy_only'?'owned':'leased';f.landProfile.marketListed=false;ha+=f.ha;bought.push(f);cost+=f.tenure==='leased'?T.leaseInitialCost(f):T.landPrice(f);took++;}if(!took&&ha<target)waitDays++;}
return{seed,target,ha,years:(s.gameTime-new Date(2026,0,1,8).getTime())/(365.25*T.DAY),avgDist:stats(bought.map(f=>f.distanceKm)).mean,maxDist:stats(bought.map(f=>f.distanceKm)).max,cost,fields:bought.length,waitDays};}
let acq=[];for(const target of [500,1000,2000,3000,5000])for(let seed=1;seed<=20;seed++)acq.push(acquisition(seed,target));
const summarize=(target)=>{const a=acq.filter(x=>x.target===target);const avg=k=>a.reduce((s,x)=>s+x[k],0)/a.length;return{target,runs:a.length,meanYears:+avg('years').toFixed(2),meanAvgDistanceKm:+avg('avgDist').toFixed(2),meanMaxDistanceKm:+avg('maxDist').toFixed(2),meanFields:+avg('fields').toFixed(1),meanWaitDays:+avg('waitDays').toFixed(1),meanEntryCostM:+(avg('cost')/1e6).toFixed(2),minHa:Math.min(...a.map(x=>x.ha))};};

// Small-farm start availability: 2m cash, affordable rent/both fields.
let smallStart=[];for(let seed=1;seed<=100;seed++){const s=makeState(seed);T.setState(s);const listed=s.fields.filter(f=>f.landProfile?.marketListed&&!f.landProfile?.holdingId);const rentable=listed.filter(f=>f.landProfile.marketMode!=='buy_only'&&T.leaseInitialCost(f)<=2_000_000);smallStart.push({seed,listed:listed.length,rentable:rentable.length,nearest:rentable.length?Math.min(...rentable.map(f=>f.distanceKm)):null});}
// Direct restriction checks from actual buy/lease functions; only denied paths are invoked (no render side effects).
let dealRestrictionChecks=0;{const s=makeState(777);T.setState(s);s.money=1e12;const a=s.fields.find(f=>f.landProfile?.marketListed);assert(a,'listing');a.landProfile.marketMode='lease_only';const before=a.owned;T.buyField(a.id);assert(a.owned===before,'lease_only was buyable');dealRestrictionChecks++;a.landProfile.marketMode='buy_only';T.leaseField(a.id);assert(a.owned===before,'buy_only was leasable');dealRestrictionChecks++;const member=s.fields.find(f=>f.landProfile?.holdingId);assert(member,'holding member');member.landProfile.marketListed=true;T.buyField(member.id);assert(!member.owned,'holding member buyable separately');dealRestrictionChecks++;}
const output={version:T.CONFIG.version,invariantChecks,expiryChecks,modeCounts,distanceAll:stats(dist),yearlyListing:{count:stats(yearly.map(x=>x.count)),ha:stats(yearly.map(x=>x.ha)),avgDist:stats(yearly.map(x=>x.avgDist)),holdings:stats(yearly.map(x=>x.holdings))},smallStart:{runs:smallStart.length,minListed:Math.min(...smallStart.map(x=>x.listed)),minAffordableRentable:Math.min(...smallStart.map(x=>x.rentable)),meanAffordableRentable:+(smallStart.reduce((a,x)=>a+x.rentable,0)/smallStart.length).toFixed(1),maxNearestAffordableKm:+Math.max(...smallStart.filter(x=>x.nearest!=null).map(x=>x.nearest)).toFixed(1)},dealRestrictionChecks,acquisition:[500,1000,2000,3000,5000].map(summarize)};
console.log(JSON.stringify(output,null,2));
