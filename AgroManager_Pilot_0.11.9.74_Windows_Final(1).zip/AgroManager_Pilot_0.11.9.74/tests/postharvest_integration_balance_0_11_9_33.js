const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`p-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__t={CONFIG,CLEANING_CONTRACT_RATE_PER_TON,INFRA_LEVELS,cleaningQuote,grainBlendSaleAnalysis,salePointPriceForLots,buyerAcceptsLots,salePointsForSeed,harvestLogisticsPlan,processTransportDeliveries,renderWarehouse,makeQuality,EQUIP_BY_ID,get state(){return state},set state(v){state=v},freshState};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__t;a.state=a.freshState('normal');a.state.gameTime=new Date(2026,8,20,12).getTime();
let checks=0;const ok=(x,m)=>{assert(x,m);checks++};
ok(a.CONFIG.version==='0.11.9.74','version 0.11.9.47');
ok(a.CLEANING_CONTRACT_RATE_PER_TON===120,'contract cleaning reduced to 120 RUB/t');
const point={id:'far',priceMult:1.015,distanceKm:87.5,name:'Контрольный дальний покупатель'};
function lot({q=70,dock=4,damage=2,tons=100,crop='spring_wheat'}={}){return{id:'x',crop,tons,moisture:14,dockagePct:dock,grainDamagePct:damage,quality:a.makeQuality(crop,q,'test'),sectionId:'S1'}}
const dirty=lot({q:70,dock:4,damage:2}),cq=a.cleaningQuote(dirty),cleaned={...dirty,tons:cq.outT,dockagePct:cq.targetDockage,quality:a.makeQuality(dirty.crop,70+Math.min(5,dirty.dockagePct*.55),'cleaned')};
const dirtyA=a.grainBlendSaleAnalysis([dirty]),cleanA=a.grainBlendSaleAnalysis([cleaned]);
ok(dirtyA.commercialScore<70&&dirtyA.priceFactor<1,'dockage and damage lower commercial grade and price');
ok(cleanA.commercialScore>dirtyA.commercialScore&&cleanA.priceFactor>dirtyA.priceFactor,'cleaning improves commercial sale analysis');
function bestAcceptedValue(l){
  const pts=a.salePointsForSeed(l.crop).filter(p=>a.buyerAcceptsLots([l],p));
  if(!pts.length)return 0;
  return Math.max(...pts.map(p=>l.tons*a.salePointPriceForLots(l.crop,p,[l])));
}
let cleanProfitable=0,cleanUnprofitable=0;
for(const crop of ['spring_wheat','sunflower','rapeseed'])for(const q of [44,45,58,59,65,70])for(const dock of [1.2,2,4,6,8]){
  const raw=lot({crop,q,dock,damage:1.5}),rq=a.cleaningQuote(raw),out={...raw,tons:rq.outT,dockagePct:rq.targetDockage,quality:a.makeQuality(crop,q+Math.min(5,dock*.55),'cleaned')};
  const before=bestAcceptedValue(raw),after=bestAcceptedValue(out)-rq.cost;
  if(after>before+1)cleanProfitable++; else if(after<before-1)cleanUnprofitable++;
}
ok(cleanProfitable>0&&cleanUnprofitable>0,'cleaning economics remain situational after buyer-market rebalance');
const nearlyClean=lot({q:78,dock:1.2,damage:1}),nq=a.cleaningQuote(nearlyClean),nearlyAfter={...nearlyClean,tons:nq.outT,dockagePct:nq.targetDockage,quality:a.makeQuality(nearlyClean.crop,78+Math.min(5,nearlyClean.dockagePct*.55),'cleaned')};
const nBefore=bestAcceptedValue(nearlyClean),nAfter=bestAcceptedValue(nearlyAfter)-nq.cost;
ok(nAfter<nBefore,'cleaning is not an automatic profit button for almost-clean grain');
const damaged=lot({q:78,dock:.8,damage:5});ok(a.grainBlendSaleAnalysis([damaged]).priceFactor<1,'grain damage independently discounts price');
const borderline=lot({q:62,dock:5,damage:3});ok(!a.buyerAcceptsLots([borderline],point),'dirty/damaged borderline lot can fail demanding buyer despite nominal quality');
const cleanBorder=lot({q:62,dock:.8,damage:1});ok(a.buyerAcceptsLots([cleanBorder],point),'clean borderline lot can pass demanding buyer');
// Intake must feed back into truck return time and therefore harvest duration.
const field={id:933,ha:600,distanceKm:1,crop:'spring_wheat',plantedAt:new Date(2026,4,1,12).getTime(),seasonYieldTarget:7,yieldTargets:{spring_wheat:7},lastCrop:'peas',rotationHistory:[],soil:{type:'Суглинок',ph:6.5,N:80,P:70,K:80,organicMatter:3,structure:75,infiltration:75,plowPan:15},soilTest:{status:'done',completedAt:a.state.gameTime},moisture:55,protection:100,weeds:8,disease:8,pest:8,seedQualityFactor:1,sowingEquipmentFactor:1,trafficFactor:1,tillageQuality:1,fertilizerApplications:[]};
const combine=a.EQUIP_BY_ID.acros595||Object.values(a.EQUIP_BY_ID).find(x=>x.type==='combine'),hq={rate:250,hours:field.ha/250,models:[combine]};
a.state.infrastructure.grainLevel=0;a.state.warehouse.intakeAvailableAt=a.state.gameTime;const slow=a.harvestLogisticsPlan(field,hq,'spring_wheat',[],60,{premium:8});
a.state.infrastructure.grainLevel=4;a.state.warehouse.intakeAvailableAt=a.state.gameTime;const fast=a.harvestLogisticsPlan(field,hq,'spring_wheat',[],60,{premium:8});
ok(slow.baseIntakeTph===35&&fast.baseIntakeTph===280,'test spans 35 vs 280 tph intake');
ok(slow.harvestHours>fast.harvestHours*2,'slow receiving line materially extends physical harvest logistics');
ok(slow.maxIntakeWaitH>fast.maxIntakeWaitH,'slow receiving line creates larger truck queue waits');
ok(slow.tripEvents.some(e=>e.intakeWaitH>0&&e.returnH>e.intakeEndH),'trip events carry intake wait/service into return time');
a.state.infrastructure.grainLevel=0;a.state.warehouse.intakeAvailableAt=a.state.gameTime+4*3600000;const backlog=a.harvestLogisticsPlan(field,hq,'spring_wheat',[],60,{premium:8});ok(backlog.harvestHours>slow.harvestHours,'existing base queue delays a new harvest fleet');
// Runtime intake queue and UI must expose physical states.
a.state=a.freshState('normal');a.state.gameTime=new Date(2026,8,20,12).getTime();a.state.warehouse.transit=[{id:'t1',crop:'spring_wheat',tons:20,moisture:14,quality:{score:80},readyAt:a.state.gameTime,label:'Зерновоз 1',fieldId:1,harvestTrip:true},{id:'t2',crop:'spring_wheat',tons:20,moisture:14,quality:{score:80},readyAt:a.state.gameTime,label:'Зерновоз 2',fieldId:1,harvestTrip:true}];a.state.warehouse.intakeAvailableAt=a.state.gameTime;a.processTransportDeliveries();
const waits=a.state.warehouse.transit.map(x=>x.intakeWaitH);ok(waits[1]>waits[0],'runtime receiving queue serializes trucks with explicit wait');
const wh=a.renderWarehouse();for(const text of ['Где сейчас зерно','Ждёт приёмку','На приёмке'])ok(wh.includes(text),`warehouse UI exposes ${text}`);
const app=fs.readFileSync('web/app.js','utf8');for(const text of ['товарный балл','повреждение','СТАТУС / ГОТОВО','максимальное ожидание рейса','Реальная модель оборота уже учитывает очередь базы'])ok(app.includes(text),`player-facing explanation: ${text}`);
console.log(JSON.stringify({pass:true,checks,cleaning:{rate:a.CLEANING_CONTRACT_RATE_PER_TON,profitableScenarios:cleanProfitable,unprofitableScenarios:cleanUnprofitable,nearlyCleanGrossBefore:Math.round(nBefore),nearlyCleanNetAfter:Math.round(nAfter)},intake:{slowTph:slow.baseIntakeTph,slowHarvestH:+slow.harvestHours.toFixed(2),slowMaxWaitH:+slow.maxIntakeWaitH.toFixed(2),fastTph:fast.baseIntakeTph,fastHarvestH:+fast.harvestHours.toFixed(2),fastMaxWaitH:+fast.maxIntakeWaitH.toFixed(2),backlogHarvestH:+backlog.harvestHours.toFixed(2)}},null,2));
