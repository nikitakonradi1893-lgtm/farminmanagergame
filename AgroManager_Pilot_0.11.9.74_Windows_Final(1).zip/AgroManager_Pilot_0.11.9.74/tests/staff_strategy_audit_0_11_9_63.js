'use strict';
const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
assert(src.includes("version:'0.11.9.74'"));
assert(src.includes('function staffPayTerms(worker)'));
assert(src.includes('function trainingOffer(worker)'));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function pay(skill,role='operator'){const tier=clamp(Math.floor(skill/5)*5,40,95),step=(tier-75)/5,base75=role==='driver'?37000:role==='mechanic'?42000:40000,bonus75=role==='driver'?350:role==='mechanic'?420:400;return{tier,base:Math.max(30000,Math.round((base75+step*1500)/500)*500),bonus:Math.max(250,Math.round((bonus75+step*20)/10)*10)}}
function training(skill){skill=Math.floor(skill);if(skill>=85)return null;if(skill<55)return{gain:Math.min(5,85-skill),days:5,cost:25000};if(skill<70)return{gain:Math.min(5,85-skill),days:7,cost:45000};if(skill<80)return{gain:Math.min(5,85-skill),days:10,cost:70000};return{gain:Math.min(5,85-skill),days:14,cost:110000}}
function xpRate(skill){return skill<=40?2.5:skill<=60?1.6:skill<=80?.8:.4}
function addWork(skill,xp,h){let left=h;while(left>1e-6&&skill<100){const rate=xpRate(skill),need=100-xp,hh=need/rate;if(left>=hh){left-=hh;skill++;xp=0}else{xp+=left*rate;left=0}}return{skill,xp}}
function annualPay(skill,hours){const t=pay(skill),months=[.04,.04,.08,.10,.15,.18,.18,.12,.07,.02,.01,.01].map(x=>hours*x);let total=0;for(const h of months)total+=t.base+Math.min(h,168)*t.bonus+Math.max(0,h-168)*t.bonus*2;return total}
function sim({ha,years,core,demand,ownerHours},strategy){let people=[],trainingCost=0,gigCost=0,payroll=0,qualifiedShortH=0,modernAccessYear=null;
 if(strategy==='ready')people=Array.from({length:core},()=>({skill:82,xp:0}));
 if(strategy==='grow')people=Array.from({length:core},()=>({skill:50,xp:0}));
 if(strategy==='hybrid')people=Array.from({length:Math.max(1,core-1)},()=>({skill:70,xp:0}));
 for(let y=1;y<=years;y++){
  if(strategy!=='ready')for(const p of people){if(p.skill<80){const q=training(p.skill);if(q){p.skill+=q.gain;p.xp=0;trainingCost+=q.cost}}}
  const modernShare=y<3?0:y<5?.3:.6, totalEmployeeH=Math.max(0,demand-ownerHours), per=people.length?totalEmployeeH/people.length:0;
  let qualified=people.filter(p=>p.skill>=80).length, modernNeed=totalEmployeeH*modernShare, qualifiedCapacity=qualified*900, modernShort=Math.max(0,modernNeed-qualifiedCapacity), totalCapacity=people.length*900, capacityShort=Math.max(0,totalEmployeeH-totalCapacity), short=Math.max(modernShort,capacityShort);qualifiedShortH+=modernShort;gigCost+=short*900;
  const regularHours=Math.max(0,totalEmployeeH-short);for(const p of people){const h=Math.min(900,regularHours/Math.max(1,people.length));payroll+=annualPay(p.skill,h);const g=addWork(p.skill,p.xp,h);p.skill=g.skill;p.xp=g.xp}
  if(modernAccessYear===null&&people.some(p=>p.skill>=80))modernAccessYear=y;
 }
 return{strategy,ha,years,headcount:people.length,payroll:Math.round(payroll),trainingCost:Math.round(trainingCost),gigCost:Math.round(gigCost),total:Math.round(payroll+trainingCost+gigCost),qualifiedShortH:Math.round(qualifiedShortH),modernAccessYear,endSkills:people.map(p=>p.skill)}
}
const scenarios=[{ha:500,years:10,core:1,demand:900,ownerHours:350},{ha:1500,years:15,core:3,demand:2600,ownerHours:300},{ha:3000,years:15,core:6,demand:5000,ownerHours:250}];
const rows=[];for(const sc of scenarios)for(const strategy of ['ready','grow','hybrid'])rows.push(sim(sc,strategy));
for(const ha of [500,1500,3000]){const x=rows.filter(r=>r.ha===ha);assert(x.every(r=>r.total>0));assert(x.find(r=>r.strategy==='ready').modernAccessYear===1);assert(x.find(r=>r.strategy==='grow').trainingCost>0);}
console.log(JSON.stringify({pass:true,checks:12,rows},null,2));
