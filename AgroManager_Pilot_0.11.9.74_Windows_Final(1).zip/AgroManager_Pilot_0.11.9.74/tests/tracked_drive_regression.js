const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const E=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{};let checks=0;
const by=id=>E.find(x=>x.id===id);
for(const id of ['t150track','dt75','agromash_ruslan']){const m=by(id);assert(m,`${id} exists`);assert.strictEqual(m.type,'tractor');assert.strictEqual(m.driveType,'tracked');checks+=3;}
assert.strictEqual(by('t150track').segment,'domestic_used');assert.strictEqual(by('dt75').segment,'domestic_used');assert.strictEqual(by('agromash_ruslan').segment,'domestic_new');assert(by('agromash_ruslan').newAvailable);checks+=4;
assert.deepStrictEqual(Array.from(V.t150track,x=>x.hp),[150,180]);checks++;
assert.deepStrictEqual(Array.from(V.dt75,x=>x.hp),[75,90,95,95,100]);checks++;
assert.strictEqual((V.agromash_ruslan||[])[0].hp,340);checks++;
for(const id of ['nh_t8410','nh_t8435']){const m=by(id);assert.strictEqual(m.driveType,'wheeled');assert.deepStrictEqual(Array.from(m.availableDriveTypes),['wheeled','halftrack']);checks+=2;}
for(const id of ['case_quadtrac715','versatile570dt_new','challenger_mt765b','challenger_mt865e']){assert.strictEqual(by(id).driveType,'tracked');checks++;}
const app=fs.readFileSync('web/app.js','utf8');
for(const needle of ["function trackVariantsForModel(m)","SmartTrax 16″","SmartTrax 30″","material:'steel'","material:'rubber'","function trackSwapQuote(a,targetId)","partsCategoryOptionsHtml","data-dealer-track","data-buy-used-track","data-buy-new-track","Ход: ${driveTypeLabel(assetDriveType(a))}"]){assert(app.includes(needle),needle);checks++;}
// Trade-off sanity mirrored from production specs.
const smart16={soil:.75,traction:1.12,road:.92,trample:.65},smart30={soil:.50,traction:1.23,road:.84,trample:.92};
assert(smart30.soil<smart16.soil&&smart30.traction>smart16.traction&&smart30.road<smart16.road);checks++;
const steel={wear:1.12,road:.72,traction:1.13},rubber={wear:.82,road:.90,traction:1.10};
assert(steel.wear>rubber.wear&&steel.road<rubber.road);checks++;
console.log(JSON.stringify({pass:true,checks,tractors:E.filter(x=>x.type==='tractor'&&!x.hidden).length,newTracked:['ХТЗ Т-150 гусеничный','ДТ-75','АГРОМАШ Руслан'],convertibleHalftrack:['New Holland T8.410','New Holland T8.435'],meaning:'тип хода явно задан; гусеничные/полугусеничные комплекты имеют материал/ширину, отдельный рынок и смену ходовой'},null,2));
