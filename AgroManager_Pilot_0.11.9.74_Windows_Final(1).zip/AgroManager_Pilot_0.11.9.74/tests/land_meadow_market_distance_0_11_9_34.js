const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}}); class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__t={CONFIG,DAY,generateLandMarket,generateMeadowMarket,landDistanceBandStats,refreshMeadowListings,activateMeadowListing,landMarketModeFor,meadowListingDaysLeft,buyMeadow,leaseMeadow,cleaningQuote,postHarvestEconomicEffect,grainBlendSaleAnalysis,freshState,get state(){return state},set state(v){state=v}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__t;
let checks=0;const ok=(x,m)=>{assert(x,m);checks++};
ok(a.CONFIG.version==='0.11.9.74','version');
function share(st,k){return st.totalHa?st[k]/st.totalHa:0}
for(let seed=1;seed<=30;seed++){
 const ar=a.generateLandMarket(seed),me=a.generateMeadowMarket(seed),as=a.landDistanceBandStats(ar),ms=a.landDistanceBandStats(me);
 ok(as.totalHa===50000,'arable total 50k'); ok(ms.totalHa===50000,'meadow total 50k');
 for(const [st,name] of [[as,'arable'],[ms,'meadow']]){ok(Math.abs(share(st,'nearHa')-.50)<.012,`${name} near 50%`);ok(Math.abs(share(st,'midHa')-.30)<.012,`${name} mid 30%`);ok(Math.abs(share(st,'farHa')-.20)<.012,`${name} far 20%`);}
 ok(ar.every(f=>f.distanceKm>=2&&f.distanceKm<=60),'arable distance 2-60'); ok(me.every(f=>f.distanceKm>=2&&f.distanceKm<=60),'meadow distance 2-60');
}
a.state=a.freshState('easy');let listed=a.state.meadows.filter(m=>m.landProfile?.marketListed);ok(listed.length>=18&&listed.length<=32,'limited meadow listings');ok(listed.length<a.state.meadows.length/5,'whole meadow fund not exposed');ok(listed.every(m=>['both','buy_only','lease_only'].includes(m.landProfile.marketMode)),'deal modes');
const modes=new Set(listed.map(m=>m.landProfile.marketMode));ok(modes.size>=2,'multiple meadow deal modes visible');
const exp=listed[0];exp.landProfile.marketExpiresAt=a.state.gameTime-a.DAY;a.state.meadowMarketRefreshDay=null;a.refreshMeadowListings(a.state.gameTime,true);ok(!exp.landProfile.marketListed,'expired meadow listing removed');
const buyOnly=a.state.meadows.find(m=>m.landProfile?.marketListed);buyOnly.landProfile.marketMode='lease_only';const own0=buyOnly.owned;a.buyMeadow(buyOnly.id);ok(buyOnly.owned===own0,'lease-only meadow cannot be bought');
buyOnly.landProfile.marketMode='buy_only';a.leaseMeadow(buyOnly.id);ok(buyOnly.owned===own0,'buy-only meadow cannot be leased');
const lot={id:'e1',crop:'spring_wheat',tons:100,moisture:14,dockagePct:5,grainDamagePct:1,quality:{score:70}};const q=a.cleaningQuote(lot),econ=a.postHarvestEconomicEffect(lot,'clean',false);ok(q.cost===12000,'cleaning remains 120 rub/t');ok(econ&&Number.isFinite(econ.effect),'cleaning economics visible/calculable');
const app=fs.readFileSync('web/app.js','utf8');ok(app.includes('Экономический эффект')&&app.includes('50% до 10 км'),'UI exposes economic effect and distance policy');
console.log(JSON.stringify({pass:true,checks,initialMeadowListings:listed.length,modes:[...modes],arable:a.landDistanceBandStats(a.generateLandMarket(123)),meadows:a.landDistanceBandStats(a.generateMeadowMarket(123)),cleaning:{cost:q.cost,effect:econ.effect}},null,2));
