'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__f40={CONFIG,CROPS,EQUIP,QUALITY_POINT_RULES,salePointsForSeed,salePointPriceForLots,saleStandardDeliveryNetPerTon,buyerAcceptsLots,makeQuality,contractAssetEconomicRate,contractEconomicReserve,normalizeAsset,landLeaseBreakEvenYears,landRecoveryWarning,makeMarketField,makeMeadow,landPrice,meadowPrice,get state(){return state},set state(v){state=v},freshState};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__f40;
let checks=0;function ok(x,m){assert(x,m);checks++;}
ok(a.CONFIG.version==='0.11.9.74','version');
// Grain market: standard-delivery net should no longer have a universal far-buyer winner.
const cropKeys=Object.entries(a.CROPS).filter(([k,c])=>c.fieldCrop!==false&&!['sugar_beet','potato','perennial_grass','alfalfa','clover'].includes(k)).map(([k])=>k);
const winner={near:0,mid:0,far:0};let decisions=0;
for(const seed of [12345,987654321,42424242]){
  a.state=a.freshState('easy');a.state.landSeed=seed;
  for(const year of [2026,2027,2028,2029,2030,2031]){
    a.state.gameTime=new Date(year,8,20).getTime();const points=a.salePointsForSeed(seed).filter(p=>['near','mid','far'].includes(p.id));
    for(const crop of cropKeys){const lot={id:'L',crop,tons:100,quality:a.makeQuality(crop,70,'audit'),dockagePct:1,grainDamagePct:1,moisture:12};const valid=points.filter(p=>a.buyerAcceptsLots([lot],p)).map(p=>({p,n:a.saleStandardDeliveryNetPerTon(crop,p,[lot],100).netPerTon})).sort((x,y)=>y.n-x.n);if(valid.length){winner[valid[0].p.id]++;decisions++;}}
  }
}
ok(decisions>100,'market sample size');ok(Object.values(winner).filter(x=>x>0).length>=2,'at least two buyer tiers win net after delivery');ok(winner.far/decisions<.78,'far buyer not universal net winner');ok(winner.mid+winner.near>0,'near/mid can beat far');
// Quality premium remains meaningful but compressed.
ok(a.QUALITY_POINT_RULES.far.high-a.QUALITY_POINT_RULES.mid.high<=.04,'far quality premium compressed');
// Contract machinery reserve: expensive/high-tech equipment must carry a much larger economic reserve.
const cheap=a.normalizeAsset({id:'A1',modelId:'mtz82',condition:82,hours:3500,busyUntil:0,repairUntil:0},0),expModel=a.EQUIP.find(x=>(x.type==='sprayer'||x.selfPropelled)&&x.price>=20000000)||a.EQUIP.find(x=>x.price>=20000000),exp=a.normalizeAsset({id:'A2',modelId:expModel.id,condition:90,hours:1200,busyUntil:0,repairUntil:0},1);
const rCheap=a.contractAssetEconomicRate(cheap),rExp=a.contractAssetEconomicRate(exp);ok(rCheap>0&&rExp>0,'economic reserve rates positive');ok(rExp>rCheap*3,'expensive machinery reserve materially higher');const q={hours:10,travel:{roundTripH:2},assets:[cheap,exp]};ok(a.contractEconomicReserve({},q)>0,'contract economic reserve calculated');
// Land lease UI math: typical purchase-equivalence should be roughly 9 years at current 10% entry + annual tariff.
a.state=a.freshState('easy');const rf=(()=>{const r=()=>.5;return a.makeMarketField(100,0,r)})();rf.landProfile.pricePerHa=50000;const by=a.landLeaseBreakEvenYears(rf);ok(by>8.5&&by<9.5,'arable lease purchase-equivalence around 9 years');rf.landProfile.status='abandoned';ok(a.landRecoveryWarning(rf).length>0,'leased degraded soil warning exists');const rm=(()=>{const r=()=>.5;return a.makeMeadow(50,0,r)})();rm.landProfile.pricePerHa=20000;const my=a.landLeaseBreakEvenYears(rm);ok(my>8.5&&my<9.5,'meadow lease purchase-equivalence around 9 years');
// UI strings / cross-surface hooks.
ok(src.includes('После стандартной доставки')&&src.includes('Резерв ресурса техники')&&src.includes('накопленная аренда сравняется'),'UI exposes all three audit fixes');
console.log('Market winners after standard delivery:',winner,'decisions',decisions);
console.log('Contract reserve rub/h:',{cheap:Math.round(rCheap),expensive:Math.round(rExp),model:expModel.name});
console.log(`Pre-silage economy fix 0.11.9.47: ${checks}/${checks} PASS`);
