'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
function storage(){const m=new Map();return{getItem:k=>m.get(k)||null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)}}
function el(inContent=false){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(sel){return inContent&&sel==='#content'?{}:null},getBoundingClientRect(){return{top:0,bottom:20}},blur(){}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelector(){return null},querySelectorAll(){return[]},addEventListener(){},removeEventListener(){},documentElement:{style:{}}};
function XHR(){}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,
 document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`ow-${++i}`})()},
 fetch:async()=>({ok:true,status:200,headers:{get(){return null}},json:async()=>({})}),confirm:()=>true,alert(){},setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},requestAnimationFrame:()=>1,cancelAnimationFrame(){},window:null};ctx.window=ctx;
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');
src=src.slice(0,pos)+`\nwindow.__ow64={CONFIG,DIFFICULTIES,freshState,normalizeOutsideWork,refreshOutsideWork,outsideWorkerEligible,outsideWorkRate,gigHourlyRate,startOutsideWork,processOutsideWork,workerById,staffPayTerms,setState(x){state=x},getState(){return state}};\n`+src.slice(pos);
vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__ow64;let checks=0;
assert.strictEqual(a.CONFIG.version,'0.11.9.74');checks++;
assert.strictEqual(a.DIFFICULTIES.zero.money,0);checks++;
let st=a.freshState('zero');a.setState(st);assert.strictEqual(st.money,0);checks++;assert(st.outsideWork&&Array.isArray(st.outsideWork.offers));checks++;
a.refreshOutsideWork(true);st=a.getState();assert(st.outsideWork.offers.length>=5);checks++;
const owner=st.staff.owner,offer=st.outsideWork.offers.find(o=>a.outsideWorkerEligible(owner,o));assert(offer,'January must have owner-accessible outside work');checks++;
const r=a.outsideWorkRate(owner,offer);assert.strictEqual(r,a.gigHourlyRate(offer.role,owner.skill));checks++;
const startSkill=owner.skill,startHours=owner.hoursWorked||0;a.startOutsideWork(offer.id,'OWNER');st=a.getState();assert(st.outsideWork.active.length===1);checks++;const j=st.outsideWork.active[0];assert.strictEqual(owner.busyUntil,j.end);checks++;assert(j.reward===j.rate*j.hours);checks++;
st.gameTime=j.end;a.processOutsideWork();assert.strictEqual(st.outsideWork.active.length,0);checks++;assert.strictEqual(st.money,j.reward);checks++;assert((owner.hoursWorked||0)>=startHours+j.hours-1e-6);checks++;assert(owner.skill>=startSkill);checks++;assert(st.outsideWork.totalIncome===j.reward&&st.outsideWork.completed===1);checks++;
// Permanent operator earns outside revenue but the hours also accrue toward payroll bonus.
const emp={id:'E1',name:'Тестовый оператор',role:'operator',skill:75,skillXp:0,contract:'permanent',busyUntil:0,restUntil:0,fatigue:0,hoursWorked:0,monthlyHours:{},workHistory:[]};st.staff.employees.push(emp);st.gameTime+=24*3600000;owner.busyUntil=0;owner.restUntil=0;a.refreshOutsideWork(true);const eo={id:'JOB-EMP',label:'Механизатор · хозяйственные работы',role:'operator',requiredSkill:50,hours:8,availableUntil:st.gameTime+86400000,customer:'КФХ Тест'};st.outsideWork.offers.push(eo);assert(eo);checks++;const er=a.outsideWorkRate(emp,eo);assert.strictEqual(er,a.gigHourlyRate('operator',75));checks++;const bonus=a.staffPayTerms(emp).bonus;assert(er>bonus,'external market rate should exceed employee internal bonus rate');checks++;a.startOutsideWork(eo.id,'E1');const ej=st.outsideWork.active.find(x=>x.workerId==='E1');st.gameTime=ej.end;a.processOutsideWork();const mh=Object.values(emp.monthlyHours).reduce((x,y)=>x+y,0);assert(mh>=ej.hours-1e-6);checks++;assert(st.outsideWork.history.some(x=>x.workerId==='E1'));checks++;
for(const text of ['Работа по найму','data-page="outsideWork"','Владелец не получает зарплату','Старт с нуля']){const hay=fs.readFileSync('web/index.html','utf8')+'\n'+src;assert(hay.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,ownerJob:{role:offer.role,hours:j.hours,rate:j.rate,reward:j.reward},employeeJob:{hours:ej.hours,rate:ej.rate,bonusPerHour:bonus}},null,2));
