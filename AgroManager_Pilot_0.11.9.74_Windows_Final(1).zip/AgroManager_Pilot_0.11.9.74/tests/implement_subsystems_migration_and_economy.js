const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG;
const app=fs.readFileSync('web/app.js','utf8');let checks=0;
const passive=E.filter(m=>m.type==='implement'&&!m.selfPropelled);
const keys=m=>{const c=m.category;if(['stubble','disk','plow','deepRip','cultivate','harrow','ridge'].includes(c))return['working','frame','hydraulics','running'];if(['sow_grain','sow_row','sow_potato','fertilizer','sprayer'].includes(c))return['working','metering','hydraulics','running'];if(['mower','tedder','rake','baler'].includes(c))return['working','drive','hydraulics','running'];if(['harvest_potato','harvest_beet'].includes(c))return['working','drive','hydraulics','running'];if(c==='bale_transport')return['frame','hydraulics','running'];return['working','frame','hydraulics','running'];};
const shares={working:.24,metering:.18,drive:.20,frame:.22,hydraulics:.12,running:.16};
const install={working:14,metering:16,drive:22,frame:28,hydraulics:14,running:18};
function migrate(m,old,base=72){const wanted=keys(m),vals=Object.values(old||{}).filter(Number.isFinite),fallback=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:base,out={};for(const k of wanted){out[k]=Number.isFinite(old?.[k])?old[k]:fallback;}return out;}
for(const m of passive.slice(0,120)){
 const old={hydraulics:71,running:66};const x=migrate(m,old,70);for(const k of keys(m)){assert(Number.isFinite(x[k]),`${m.id}:${k}`);checks++;}if(keys(m).includes('hydraulics')){assert.strictEqual(x.hydraulics,71);checks++;}if(keys(m).includes('running')){assert.strictEqual(x.running,66);checks++;}
}
// New part purchase has no instant resale arbitrage; used emergency replacement remains cheaper but not new.
for(const m of passive.filter(x=>x.price>0).slice(0,180))for(const k of keys(m)){
 const base=Math.max(30000,Math.round((m.price||300000)*shares[k]/5000)*5000);
 const dealer=Math.round(base*1.06/10000)*10000;
 const resale=Math.max(20000,Math.round(base*(.22+.0068*100)*1*.84/10000)*10000);
 assert(resale<dealer,`${m.id}:${k} dealer ${dealer} resale ${resale}`);checks++;
 const urgentUsed=Math.round(base*.55/10000)*10000+Math.max(50000,Math.round(install[k]*4200/10000)*10000);
 const fresh=Math.round(base*1.08/10000)*10000+Math.max(50000,Math.round(install[k]*4200/10000)*10000);
 assert(urgentUsed<fresh,`${m.id}:${k}`);checks++;
}
for(const str of ['function normalizedSystemsForAsset','m?.type===\'implement\'&&!m.selfPropelled','criticalWarehouseItem(a,k)','criticalReplacementBase(a,k)','NEW_IMPLEMENT_WEAR_PROTECTION_HOURS','nodeNewWearProtected']){assert(app.includes(str),str);checks++;}
console.log(JSON.stringify({pass:true,passiveImplements:passive.length,checks,meaning:'старые сохранения получают новые системы агрегатов без потери сохранённых гидравлики/ходовой; новые запчасти нельзя мгновенно перепродать с прибылью; срочная Б/У замена дешевле новой, но несёт Б/У ресурс'},null,2));
