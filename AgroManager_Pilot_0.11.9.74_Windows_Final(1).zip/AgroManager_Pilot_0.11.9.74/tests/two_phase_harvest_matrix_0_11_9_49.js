const fs=require('fs'),vm=require('vm'),assert=require('assert');
function storage(){return{getItem(){return null},setItem(){},removeItem(){}}}
const document={getElementById(){return{textContent:'',classList:{add(){},remove(){}},innerHTML:'',addEventListener(){},style:{}}},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){},body:{classList:{add(){},remove(){}}}};
class XHR{open(){}send(){}setRequestHeader(){}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__m={CONFIG,equipmentModel,grainPickupHours,grainPickupRate,windrowLengthKmForArea,freshState,get state(){return state},set state(v){state=v}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__m;
assert.equal(a.CONFIG.version,'0.11.9.74');a.state=a.freshState('very_hard');a.state.gameTime=new Date(2026,7,15,10).getTime();
const cm=a.equipmentModel('acros550'), modern=a.equipmentModel('swa_pick340'), old=a.equipmentModel('pp34_legacy');
const yields=[2,4,7], moistures=[13,18,24], rows=[];
for(const y of yields)for(const m of moistures){const f={ha:100,crop:'spring_wheat',grainWindrow:{stage:'grain_windrow',crop:'spring_wheat',mownAt:a.state.gameTime,updatedAt:a.state.gameTime,moisture:m,quality:90,lossPct:0,yieldPerHaAtCut:y,windrowGatherWidthM:9,windrowLengthKm:a.windrowLengthKmForArea(100,9)}};rows.push({yield:y,moisture:m,swaHours:a.grainPickupHours(f,modern,cm),oldHours:a.grainPickupHours(f,old,cm),swaRate:a.grainPickupRate(f,cm,modern),oldRate:a.grainPickupRate(f,cm,old)});}
for(const y of yields){const rr=rows.filter(r=>r.yield===y);assert(rr[2].swaHours>=rr[1].swaHours&&rr[1].swaHours>=rr[0].swaHours,`wet pickup should not be faster at ${y} t/ha`);}
assert(rows.find(r=>r.yield===7&&r.moisture===24).swaHours>rows.find(r=>r.yield===7&&r.moisture===13).swaHours*1.08,'wet heavy windrow should materially increase combine-flow hours');
assert(rows.find(r=>r.yield===2&&r.moisture===13).oldHours>rows.find(r=>r.yield===2&&r.moisture===13).swaHours,'legacy PP-3.4 should preserve speed tradeoff vs SWA');
console.log(JSON.stringify({pass:true,release:'0.11.9.74',matrix:rows},null,2));
