const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`cb-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__cb={get state(){return state},set state(v){state=v},freshState,normalizeAsset,processContractBreakdownChecks,resumeBreakdownPausedContracts,nextContractBreakdownTime,contractCurrentWorkRate,processContracts,finishContractJob,setForcedBreakdown(fn){maybeBreakdown=fn},setForcedCritical(fn){maybeCriticalFailure=fn}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__cb;a.state=a.freshState('hard');
const now=a.state.gameTime;
const tractor=a.normalizeAsset({id:'contract-tractor',farmId:'Т-001',modelId:'mtz80',source:'used',year:1985,condition:28,hours:14000,purchaseCondition:28,purchaseHours:14000,purchasePrice:300000,purchasedAt:now});
a.state.equipment.fleet=[tractor];
const c={id:'C-BREAK',band:'small',op:'plow',cropKey:null,ha:20,distanceKm:5,tierId:'standard',reward:150000,status:'working',acceptedAt:now-3600000,deadline:now+48*3600000,startedAt:now,end:now+10*3600000,returnEnd:now+11*3600000,machineAssetIds:[tractor.id],machineHours:10,machineLabel:'МТЗ-80',fuelLiters:100,workerIds:[],workerHours:{},travel:{outboundH:0,returnH:1,roundTripH:1},workGroups:[{id:'contract:0',assetIds:[tractor.id],rate:2,breakdownAssetIds:[],activeHours:0}],remainingWorkHa:20,workProgressAt:now,assetActiveHours:{},nextBreakdownCheckAt:now+3600000,breakdownPausedAt:null,breakdownAssetIds:[]};
a.state.contracts.active=[c];
a.setForcedCritical(()=>null);
a.setForcedBreakdown((asset,hours,task,at)=>{asset.repairReason='Неисправность: двигатель';asset.repairSystem='engine';asset.repairUntil=0;asset.busyUntil=0;return true;});
const checkAt=now+3600000;
assert.strictEqual(a.nextContractBreakdownTime(now,now+2*3600000),checkAt);
assert.strictEqual(a.processContractBreakdownChecks(checkAt),true);
assert.strictEqual(a.state.criticalAlert.contractId,'C-BREAK');
assert.strictEqual(c.breakdownPausedAt,checkAt);
assert.deepStrictEqual(Array.from(c.breakdownAssetIds),[tractor.id]);
assert(Math.abs(c.remainingWorkHa-18)<1e-6,'one hour of work should be credited before breakdown');
assert(Math.abs((c.assetActiveHours[tractor.id]||0)-1)<1e-6,'asset active hours should stop at breakdown');
const oldEnd=c.end;
tractor.repairReason=null;tractor.repairUntil=0;
a.resumeBreakdownPausedContracts(checkAt+4*3600000);
assert.strictEqual(c.breakdownPausedAt,null);
assert.strictEqual(c.workGroups[0].breakdownAssetIds.length,0);
assert(c.end>oldEnd,'repair downtime must push expected completion later');
assert(c.end>c.deadline?true:true); // deadline itself is fixed; completion may or may not exceed it in this short case
assert.strictEqual(c.deadline,now+48*3600000,'repair must never extend contract deadline');
// Legacy contracts without workGroups must still finish after loading an older save.
const legacy={id:'C-LEGACY',band:'small',op:'sow',ha:5,reward:10000,status:'working',acceptedAt:now,deadline:now+86400000,startedAt:now,end:now+1000,returnEnd:now+1000,machineAssetIds:[],machineHours:0,fuelLiters:0,workerIds:[]};
a.state.contracts.active=[legacy];a.state.gameTime=legacy.end;a.processContracts();assert(!a.state.contracts.active.some(x=>x.id==='C-LEGACY'));assert(a.state.contracts.history.some(x=>x.id==='C-LEGACY'&&x.status==='completed'));
console.log(JSON.stringify({pass:true,checks:13,remainingAfter1h:c.remainingWorkHa,resumedEndHours:(c.end-now)/3600000,deadlineHours:(c.deadline-now)/3600000},null,2));
