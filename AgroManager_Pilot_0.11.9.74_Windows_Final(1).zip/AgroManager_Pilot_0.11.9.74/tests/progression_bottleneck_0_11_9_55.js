const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{},console};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const E=ctx.EQUIPMENT_CATALOG||[];const M=id=>{const x=E.find(v=>v.id===id);assert(x,`model ${id}`);return x};
const rate=m=>Math.max(.1,Number(m.fieldCapacityHaH)||Number(m.width||0)*Number(m.speed||0)*Number(m.eff||.78)/10);
const fleet={
 tillage:{tractor:M('k700'),tool:M('imp26'),workableDays:90,weather:.75,hoursDay:12,passes:1},
 sow:{tractor:M('mtz82'),tool:M('imp60'),workableDays:0,weather:.80,hoursDay:12,passes:1},
 spray:{tractor:M('mtz82'),tool:M('imp87'),workableDays:55,weather:.70,hoursDay:12,passes:2},
 harvest:{machine:M('don1500b'),tool:M('don_zhu7'),workableDays:0,weather:.68,hoursDay:12,passes:1},
 haul:{trucks:[M('kamaz55102'),M('kamaz55102')],distanceKm:30}
};
const crops={
 winter_wheat:{share:1/6,sow:[[9,5],[9,25]],harvest:[[7,10],[8,20]]},
 peas:{share:1/6,sow:[[3,20],[4,20]],harvest:[[7,1],[8,20]]},
 rapeseed:{share:1/6,sow:[[4,10],[5,5]],harvest:[[8,1],[9,10]]},
 soybean:{share:1/6,sow:[[5,10],[5,30]],harvest:[[9,1],[10,5]]},
 barley:{share:1/6,sow:[[3,25],[4,25]],harvest:[[7,1],[8,20]]},
 oil_flax:{share:1/6,sow:[[4,10],[4,30]],harvest:[[8,1],[9,5]]}
};
function doy(md){return Math.round((Date.UTC(2026,md[0]-1,md[1])-Date.UTC(2026,0,1))/86400000)}
function calendarMiss(area,kind,r,weather,hoursDay,machines=1){const tasks=Object.entries(crops).map(([k,c])=>({k,start:doy(c[kind][0]),end:doy(c[kind][1]),left:area*c.share}));for(let d=0;d<365;d++){let cap=r*weather*hoursDay*machines;const active=tasks.filter(t=>t.start<=d&&d<=t.end&&t.left>.001).sort((a,b)=>a.end-b.end);for(const t of active){const q=Math.min(cap,t.left);t.left-=q;cap-=q;if(cap<=.001)break;}}return tasks.reduce((s,t)=>s+t.left,0)}
function fixedCapacity(spec,machines=1){return rate(spec.tool)*spec.hoursDay*spec.weather*spec.workableDays*machines/spec.passes}
function haulTph(trucks,distance){return trucks.reduce((s,t)=>{const cap=Number(t.capacityT)||4,speed=Number(t.roadSpeed)||50,cycle=distance*2/speed+.30;return s+cap/cycle},0)}
const tillRate=rate(fleet.tillage.tool), sowRate=rate(fleet.sow.tool), sprayRate=rate(fleet.spray.tool), harvRate=rate(fleet.harvest.tool);
const tillCap=fixedCapacity(fleet.tillage), sprayCap=fixedCapacity(fleet.spray), haul=haulTph(fleet.haul.trucks,30);
const avgYield=(4.2+2.8+2.4+2.4+3.5+1.8)/6*.88, combineFlow=harvRate*avgYield;
const areas=[750,1000,1250,1500,2000],rows=[];
for(const area of areas){const sowMiss=calendarMiss(area,'sow',sowRate,.80,12),harvMiss=calendarMiss(area,'harvest',harvRate,.68,12),tillageMiss=Math.max(0,area-tillCap),sprayMiss=Math.max(0,area-sprayCap);const transportFactor=Math.min(1,haul/Math.max(.1,combineFlow));const issues=[];if(tillageMiss>.5)issues.push('tillage');if(sowMiss>.5)issues.push('sow');if(sprayMiss>.5)issues.push('spray');if(harvMiss>.5)issues.push('harvest');if(transportFactor<.99)issues.push('transport');rows.push({area,tillageMiss:+tillageMiss.toFixed(1),sowMiss:+sowMiss.toFixed(1),sprayMiss:+sprayMiss.toFixed(1),harvestMiss:+harvMiss.toFixed(1),transportFactor:+transportFactor.toFixed(3),issues});}
const k700plow=M('k700').price+M('imp26').price,donHeader=M('don1500b').price+M('don_zhu7').price,twoTrucks=2*M('kamaz55102').price;
const upgrades={secondTillageSet:k700plow,secondHarvestSet:donHeader,secondTruckPair:twoTrucks};
assert(rows.find(x=>x.area===1000).tillageMiss<1,'1000ha old tillage should fit');
assert(rows.find(x=>x.area===1500).tillageMiss>50,'1500ha exposes tillage bottleneck');
assert(rows.find(x=>x.area===1500).harvestMiss<1,'1500ha harvest still fits one DON in diversified calendar');
assert(rows.find(x=>x.area===2000).harvestMiss>100,'2000ha exposes harvest bottleneck');
assert(haul>combineFlow,'two old trucks should support one DON at 30km');
assert(k700plow<3_000_000,'first incremental bottleneck upgrade remains affordable');
console.log(JSON.stringify({pass:true,checks:6,representativeFleet:{tillage:`${fleet.tillage.tractor.name} + ${fleet.tillage.tool.name}`,sow:`${fleet.sow.tractor.name} + ${fleet.sow.tool.name}`,spray:`${fleet.spray.tractor.name} + ${fleet.spray.tool.name}`,harvest:`${fleet.harvest.machine.name} + ${fleet.harvest.tool.name}`,haul:`2 × ${M('kamaz55102').name}`},rates:{tillageHaH:+tillRate.toFixed(2),sowHaH:+sowRate.toFixed(2),sprayHaH:+sprayRate.toFixed(2),harvestHaH:+harvRate.toFixed(2),haulTph:+haul.toFixed(1),combineAvgCropTph:+combineFlow.toFixed(1)},annualCapacity:{tillageHa:+tillCap.toFixed(0),sprayHa:+sprayCap.toFixed(0)},upgrades,rows},null,2));
