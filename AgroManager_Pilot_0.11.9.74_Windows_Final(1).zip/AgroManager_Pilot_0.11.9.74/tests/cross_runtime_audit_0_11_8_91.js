const fs=require('fs'),vm=require('vm'),assert=require('assert');
const app=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');
let checks=0;
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){},contains(){return false}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}},scrollIntoView(){}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const listeners={};
const document={activeElement:{tagName:'BODY',dataset:{},isContentEditable:false},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(ev,fn){listeners[ev]=fn}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`audit-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,scrollX:0,scrollY:0,scrollTo(){},scrollBy(){},window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=app,pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__x={get state(){return state},set state(v){state=v},freshState,navigatePage,uiInteractionActive,contractProgressPct,renderEquipment,renderFields,renderStaff,renderOperations,renderContracts,renderMarket,renderWarehouse,renderFinancing,renderAgronomy,renderMaterials,renderInfrastructure,openMachineryPicker,refreshContracts,get contractPicker(){return contractPicker},set contractPicker(v){contractPicker=v},get salePicker(){return salePicker},set salePicker(v){salePicker=v},get operationPicker(){return operationPicker},set operationPicker(v){operationPicker=v},get page(){return page},setVar(k,v){eval(k+'=v')},setUiUntil(v){uiInteractionUntil=v}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const x=ctx.__x;x.state=x.freshState('normal');
// Hidden local pickers must not freeze unrelated pages after navigation.
x.contractPicker={contractId:'C1'};x.salePicker={cropKey:'spring_wheat'};x.navigatePage('dashboard');assert.strictEqual(x.contractPicker,null);assert.strictEqual(x.salePicker,null);checks+=2;
x.contractPicker={contractId:'C2'};x.navigatePage('contracts');assert(x.contractPicker);x.navigatePage('fields');assert.strictEqual(x.contractPicker,null);checks+=2;
x.salePicker={cropKey:'barley'};x.navigatePage('market');assert(x.salePicker);x.navigatePage('finance');assert.strictEqual(x.salePicker,null);checks+=2;
// Operation picker is global by design and remains visible across pages.
x.operationPicker={fieldId:1,op:'sow'};x.navigatePage('agronomy');assert(x.operationPicker);x.operationPicker=null;checks++;
// Focused SELECT protects an open native dropdown from live rerender; change/blur releases it.
x.setUiUntil(0);document.activeElement={tagName:'SELECT',dataset:{},isContentEditable:false,closest(sel){return sel==='#content'?{}:null}};assert.strictEqual(x.uiInteractionActive(),true);checks++;
document.activeElement={tagName:'INPUT',dataset:{},isContentEditable:false,closest(sel){return sel==='#content'?{}:null}};assert.strictEqual(x.uiInteractionActive(),true);checks++;
document.activeElement={tagName:'BODY',dataset:{},isContentEditable:false};
// Contract progress must freeze for the current weather-pause day.
const base=Date.UTC(2026,3,1,6,0,0), c={startedAt:base,end:base+54*3600000,weatherPausedHours:24,weatherPauseUntil:base+30*3600000};
const p0=x.contractProgressPct(c,base+6*3600000),p1=x.contractProgressPct(c,base+12*3600000),p2=x.contractProgressPct(c,base+29*3600000),p3=x.contractProgressPct(c,base+36*3600000);
assert(Math.abs(p0-.2)<1e-9);assert(Math.abs(p1-p0)<1e-9);assert(Math.abs(p2-p0)<1e-9);assert(p3>p2);checks+=4;
// In-place filters/options that used to reset scroll now preserve the viewport.
for(const needle of [
 "staffTab=b.dataset.staffTab;renderPreservingViewport()",
 "staffMarketTab=b.dataset.staffMarket;renderPreservingViewport()",
 "equipmentTab=b.dataset.equipTab;renderPreservingViewport()",
 "dealerEngineDraft[sel.dataset.dealerEngine]=sel.value;renderPreservingViewport()",
 "dealerTireDraft[sel.dataset.dealerTire]=sel.value;renderPreservingViewport()",
 "dealerTrackDraft[sel.dataset.dealerTrack]=sel.value;renderPreservingViewport()",
 "equipmentFilters[el.dataset.ef]=el.value;renderPreservingViewport()",
 "refreshContracts(true);save();renderPreservingViewport()",
 "refreshDeliveryContracts(true);renderPreservingViewport()"
]){assert(app.includes(needle),needle);checks++;}
// Deep render matrix: exercise nested equipment/parts/land/staff states that old smoke tests did not cover.
function renderOk(label,fn){const out=fn();assert.strictEqual(typeof out,'string',label);assert(out.length>50,label);checks++;}
for(const tab of ['fleet','used','new'])for(const cat of ['tractor','combine','implement','header','truck','trailer','graincart']){x.setVar('equipmentTab',JSON.stringify(tab));x.setVar('equipmentCategory',JSON.stringify(cat));renderOk(`equipment ${tab}/${cat}`,()=>x.renderEquipment())}
for(const pv of ['used','new','stock'])for(const pc of ['engine','transmission','running','hydraulics','working','frame','metering','drive','tires','tracks']){x.setVar('equipmentTab',JSON.stringify('parts'));x.setVar('partsView',JSON.stringify(pv));x.setVar('partsCategory',JSON.stringify(pc));renderOk(`parts ${pv}/${pc}`,()=>x.renderEquipment())}
for(const lv of ['owned','market'])for(const lt of ['arable','meadow']){x.setVar('landView',JSON.stringify(lv));x.setVar('landTypeView',JSON.stringify(lt));renderOk(`land ${lv}/${lt}`,()=>x.renderFields())}
for(const st of ['team','market'])for(const mt of ['permanent','seasonal']){x.setVar('staffTab',JSON.stringify(st));x.setVar('staffMarketTab',JSON.stringify(mt));renderOk(`staff ${st}/${mt}`,()=>x.renderStaff())}
assert(idx.includes('PILOT 0.11.9.74')&&idx.includes('app.js?v=011974'));checks++;
console.log(JSON.stringify({pass:true,checks,deepRenderCases:59},null,2));
