const fs=require('fs'),assert=require('assert');
const s=fs.readFileSync('web/app.js','utf8');
let checks=0;
assert(s.includes("engineMissing=!!meta.engineMissing,eng=engineMissing?null:engineSpecById(model,meta.engineId)"));checks++;
assert(s.includes("engineId:eng?.id||null,purchaseEngineId:eng?.id||null"));checks++;
assert(s.includes("if(asset.engineMissing&&isPoweredSelfPropelled(model))asset.systems.engine=null"));checks++;
assert(s.includes("if(out.engineMissing&&isPoweredSelfPropelled(m)&&out.systems)out.systems.engine=null"));checks++;
assert(s.includes("physicalCapable=isPoweredSelfPropelled(model)&&engineVariantsForModel(model).some(engineIsPhysical)"));checks++;
console.log(JSON.stringify({pass:true,checks,meaning:'покупка любой поддерживаемой самоходной машины без двигателя не создаёт бесплатный штатный двигатель'},null,2));
