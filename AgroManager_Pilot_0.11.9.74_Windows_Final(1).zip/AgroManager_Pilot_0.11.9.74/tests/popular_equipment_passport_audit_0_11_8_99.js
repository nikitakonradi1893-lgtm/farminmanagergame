const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}};
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__t={EQUIP_BY_ID,TRACTOR_PASSPORT_OVERRIDES,tractorCapabilitySpec,implementRequirementSpec};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__t;let checks=0;const ok=(x,m)=>{assert(x,m);checks++};
const expected={
 bel821:{mass:4,hyd:45,pto:['540','1000'],hitch:2},
 bel12213:{mass:5.73,hyd:51,pto:['540','1000'],hitch:3},
 k7m420:{mass:16.73,hyd:180,pto:['1000'],hitch:4},
 jd6r215:{hyd:155,pto:['540','540E','1000','1000E'],hitch:3},
 jd7r330:{mass:10,hyd:162,pto:['1000'],hitch:3},
 jd8r410:{hyd:227,pto:['1000'],hitch:4},
 fendt942:{hyd:165,pto:['540E','1000'],hitch:4},
 claasaxion960:{mass:13,hyd:220,pto:['1000','1000E'],hitch:4},
 nh_t8435:{mass:11.88,hyd:224,pto:['1000'],hitch:4},
 casemagnum400:{hitch:4}
};
for(const [id,e] of Object.entries(expected)){const m=a.EQUIP_BY_ID[id];ok(m&&m.type==='tractor',`catalog tractor ${id}`);const asset={id:'a-'+id,farmId:'T',modelId:id,condition:100,systems:{engine:100,transmission:100,running:100,hydraulics:100},ballastMode:'none',engineId:m.stockEngineId||null};const c=a.tractorCapabilitySpec(asset);ok(c&&c.passportSource,`passport path ${id}`);if(e.mass!=null)ok(Math.abs(c.baseMassT-e.mass)<.001,`mass ${id}`);if(e.hyd!=null)ok(c.hydraulicLpm===e.hyd,`hyd ${id}`);if(e.pto)ok(JSON.stringify(c.pto)===JSON.stringify(e.pto),`pto ${id}`);if(e.hitch!=null)ok(c.hitchClass===e.hitch,`hitch ${id}`);}
// Manufacturer-backed combine/truck values that affect physical logistics.
ok(a.EQUIP_BY_ID.acros595.grainTankM3===9&&a.EQUIP_BY_ID.acros595.unloadLps===90,'ACROS 595 tank/unload');
ok(a.EQUIP_BY_ID.rsm161.grainTankM3===10.5&&a.EQUIP_BY_ID.rsm161.unloadLps===115,'RSM 161 tank/unload');
ok(a.EQUIP_BY_ID.torum785.grainTankM3===12&&a.EQUIP_BY_ID.torum785.unloadLps===120,'TORUM 785 tank/unload corrected');
ok(a.EQUIP_BY_ID.kamaz65115.capacityT===15,'KAMAZ-65115 payload');
// Passport data must alter the old heuristic in meaningful cases, proving it is actually consumed.
const k=a.tractorCapabilitySpec({id:'k',farmId:'K',modelId:'k7m420',condition:100,systems:{},ballastMode:'none',engineId:'tmz8481_420'});ok(k.hydraulicLpm===180,'K-7M explicit hydraulic flow consumed');ok(!k.pto.includes('540E'),'K-7M no invented 540E PTO');
const b=a.tractorCapabilitySpec({id:'b',farmId:'B',modelId:'bel821',condition:100,systems:{},ballastMode:'none',engineId:'bel821_d243_1442'});ok(b.pto.includes('1000'),'BELARUS 82.1 explicit 1000 PTO consumed');
console.log(JSON.stringify({pass:true,checks,verifiedTractors:Object.keys(expected).length,verifiedOther:['acros595','rsm161','torum785','kamaz65115'],corrected:{torum785UnloadLps:120,k7m420Pto:k.pto,k7m420HydraulicLpm:k.hydraulicLpm},boundary:'Only listed models use explicit passport overrides; all other tractors retain the existing heuristic fallback.'},null,2));
