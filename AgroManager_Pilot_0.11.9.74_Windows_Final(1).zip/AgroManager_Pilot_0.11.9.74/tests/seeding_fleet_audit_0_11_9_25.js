const fs=require('fs'),vm=require('vm'),assert=require('assert');let checks=0;const ok=(v,m)=>{assert(v,m);checks++};
const ctx={window:{},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG,M=id=>E.find(x=>x.id===id);
const app=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');ok(app.includes("version:'0.11.9.74'"),'runtime version');ok(idx.includes('PILOT 0.11.9.74')&&idx.includes('011974'),'index/cache');
const ids=['seed_amazone_primera_dmc_old','seed_vaderstad_rapid400c_old','seed_jd750_15ft_old','seed_gp_3sf30_old','seed_gp_1000nt_old','seed_kuhn_venta_al402_old','seed_simba_freeflow4_old','seed_monosem_ngplus8_old','seed_accord_optima8_old'];
for(const id of ids){const m=M(id);ok(!!m,id);ok(m.type==='implement',id+' implement');ok(['sow_grain','sow_row'].includes(m.category),id+' category');ok(m.segment==='foreign_used',id+' historical foreign');ok(m.years[0]>=1987&&m.years[1]<=2005,id+' historical years');ok(Array.isArray(m.seedingModes)&&m.seedingModes.length,id+' sow modes');}
const seeders=E.filter(x=>x.type==='implement'&&['sow_grain','sow_row','sow_potato'].includes(x.category));ok(seeders.length===67,'67 seeding machines after duplicate removal and expansion');
ok(!seeders.some(x=>x.years?.[0]===1980&&x.years?.[1]===2018),'no 1980-2018 placeholder years');
ok(seeders.filter(x=>/СН-4Б картофелесажалка/.test(x.name)&&!/СН-4БМ/.test(x.name)).length===1,'single historical SN-4B');
ok(M('seed_jd750_15ft_old').directDrill===true&&M('seed_jd750_15ft_old').seedingModes.includes('noTill'),'JD750 no-till');
ok(M('seed_amazone_primera_dmc_old').directDrill===true&&M('seed_amazone_primera_dmc_old').combinedFertilizer===true,'Primera direct/combi');
ok(M('seed_vaderstad_rapid400c_old').seedbedPrep===true&&M('seed_vaderstad_rapid400c_old').combinedFertilizer===true,'Rapid one-pass/combi');
ok(M('seed_monosem_ngplus8_old').category==='sow_row'&&M('seed_monosem_ngplus8_old').crops.includes('corn'),'Monosem row crops');
for(const id of ['imp72','imp74','imp75','imp76','imp77','imp78','imp100','imp101'])ok(M(id).segment.endsWith('_new')&&M(id).newAvailable===false,id+' modern used classification');
for(const text of ['function seederFieldCompatibility','Для No-Till требуется сеялка прямого посева','подготовка ложа за один проход','конструктивно семена + удобрения'])ok(app.includes(text),text);
console.log(`Seeding fleet audit 0.11.9.47: ${checks}/${checks} PASS`);
