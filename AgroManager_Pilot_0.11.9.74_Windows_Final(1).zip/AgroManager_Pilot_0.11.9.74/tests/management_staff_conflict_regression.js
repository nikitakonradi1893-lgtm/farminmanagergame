const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const H=3600000,DAY=24*H,start=new Date(2028,4,18,8).getTime();
const ctx={Math,Number,Date,DAY};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(v,d=0)=>Number(v).toFixed(d);ctx.rub=v=>`${Math.round(v)} ₽`;ctx.STAFF_ROLE_LABEL={operator:'Механизатор'};
ctx.state={gameTime:start,money:2_000_000,staff:{owner:{id:'OWNER',role:'owner',name:'Владелец',skill:40,busyUntil:0,restUntil:0},employees:[],market:[],gigBusyUntil:{},gigRestUntil:{}}};
ctx.roleForUnit=()=> 'operator';ctx.unitSkillRequirement=()=>({threshold:60});ctx.activeEmployee=e=>e&&(!e.contractEnd||e.contractEnd>ctx.state.gameTime);ctx.ownerWorker=()=>ctx.state.staff.owner;ctx.gigCandidateFree=(c,at)=>Number(ctx.state.staff.gigBusyUntil[c.id]||0)<=at&&Number(ctx.state.staff.gigRestUntil[c.id]||0)<=at;ctx.seasonalContractCost=(c,days)=>Math.round(c.salaryMonthly*(days/30)*1.25);
vm.createContext(ctx);for(const n of ['managementWorkerQualified','managementWorkerAvailableHours','managementStaffScenarios','managementPortfolioStaffAllocation'])vm.runInContext(fn(n),ctx);
let checks=0;const uA={key:'a',assets:[]},uB={key:'b',assets:[]};
ctx.state.staff.employees=[{id:'P1',role:'operator',name:'Иван',skill:75,contract:'permanent',salaryMonthly:80000,busyUntil:0,restUntil:0}];
let a=ctx.managementPortfolioStaffAllocation([
 {id:'urgent',label:'Поле 1 · посев',units:[uA],endAt:start+48*H,workHours:16,priority:3},
 {id:'later',label:'Поле 2 · опрыскивание',units:[uB],endAt:start+48*H,workHours:16,priority:2}
],start);
assert.strictEqual(a.urgent.allocatedHours,16);checks++;
assert.strictEqual(a.later.allocatedHours,0);checks++;
assert.strictEqual(a.later.conflictHours,16);checks++;
assert(a.later.reservedFor.some(x=>x.includes('Поле 1')));checks++;
// Add a second permanent operator: both operations can now be staffed without double-booking.
ctx.state.staff.employees.push({id:'P2',role:'operator',name:'Пётр',skill:70,contract:'permanent',salaryMonthly:76000,busyUntil:0,restUntil:0});
a=ctx.managementPortfolioStaffAllocation([
 {id:'urgent',label:'Поле 1 · посев',units:[uA],endAt:start+48*H,workHours:16,priority:3},
 {id:'later',label:'Поле 2 · опрыскивание',units:[uB],endAt:start+48*H,workHours:16,priority:2}
],start);
assert.strictEqual(a.urgent.allocatedHours,16);checks++;
assert.strictEqual(a.later.allocatedHours,16);checks++;
assert.strictEqual(a.later.conflictHours,0);checks++;
// Qualification remains a hard gate even when a worker is otherwise free.
ctx.state.staff.employees[1].skill=55;
a=ctx.managementPortfolioStaffAllocation([{id:'x',label:'Тяжёлая работа',units:[uA],endAt:start+24*H,workHours:16,priority:3}],start);
assert.strictEqual(a.x.allocatedHours,8);checks++;
for(const text of ['Конфликт персонала забирает','Центр не бронирует одного работника на две срочные работы одновременно','Подрядчик «Стандарт» на дефицит','Экономически минимальный вариант завершить 100%','Сезонный договор дешевле эквивалентных разовых смен',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,scenario:'две одновременные срочные операции, один дефицитный квалифицированный механизатор',singleWorker:{urgentH:16,laterH:0,conflictH:16},twoWorkers:{urgentH:16,laterH:16,conflictH:0},startMoney:ctx.state.money},null,2));
