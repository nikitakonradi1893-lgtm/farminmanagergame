const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');
let checks=0;
function ok(v,m){assert(v,m);checks++;}
ok(idx.includes('data-page="tutorial"')&&idx.includes('Обучение'),'tutorial nav');
ok(src.includes('function renderTutorial()'),'tutorial renderer');
ok(src.includes("tutorial:renderTutorial"),'tutorial route');
ok(src.includes('Первый производственный цикл')&&src.includes('18 шагов'),'quickstart cycle');
ok(src.includes('Кнопки и действия')&&src.includes('Основы игры')&&src.includes('Все разделы'),'tutorial tabs');
ok(src.includes('data-tutorial-search'),'tutorial search');
const pages=['Обзор','Центр управления','Агрокалендарь','Погода','Поля','Агрономия','Агрооперации','Процессы','Материалы','Склад','Инфраструктура','Техника','Сотрудники','Контракты','Контракты поставки','Рынок','Финансирование','Финансы'];
for(const p of pages)ok(src.includes(`title:'${p}'`)||src.includes(`title:\"${p}\"`),`missing tutorial page ${p}`);
for(const phrase of ['Новая игра','Выйти из приложения','+5/+10 дней','Назначить свою технику','Частичный подрядчик','Б/У запчасти','Погасить просрочку','перегрузчик','автопоезд','критический'])ok(src.toLowerCase().includes(phrase.toLowerCase()),`missing action ${phrase}`);
ok(src.includes('Начать обучение'),'dashboard tutorial entry');
console.log(`Tutorial coverage regression: ${checks} checks PASS`);
