const assert=require('assert');
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const variants={
 wheel:{name:'T8 колёса',soil:1,traction:1,fuel:1,road:1,crop:1},
 s16:{name:'SmartTrax 16',soil:.75,traction:1.12,fuel:.98,road:.92,crop:.65},
 s24:{name:'SmartTrax 24',soil:.58,traction:1.20,fuel:.965,road:.88,crop:.82},
 s30:{name:'SmartTrax 30',soil:.50,traction:1.23,fuel:.96,road:.84,crop:.92}
};
function fieldRate(base,v){return base*clamp(1+(v.traction-1)*.45,.96,1.07)}
function scenario(v){const heavyHa=1000,lightHa=1000,roadKm=1200,baseHeavy=4.0,baseLight=7.0,roadSpeed=40,baseFuelLph=55;
 const hHeavy=heavyHa/fieldRate(baseHeavy,v),hLight=lightHa/fieldRate(baseLight,v),roadH=roadKm/(roadSpeed*v.road),fieldH=hHeavy+hLight;
 const fuel=fieldH*baseFuelLph*v.fuel+roadH*22;
 const pressure=(heavyHa+lightHa)*v.soil, cropImpact=lightHa*v.crop;
 return{fieldH,roadH,totalH:fieldH+roadH,fuel,pressure,cropImpact};}
const out=Object.fromEntries(Object.entries(variants).map(([k,v])=>[k,scenario(v)]));
assert(out.s24.fieldH<out.wheel.fieldH);assert(out.s24.pressure<out.wheel.pressure);assert(out.s24.roadH>out.wheel.roadH);assert(out.s16.cropImpact<out.s30.cropImpact);assert(out.s30.pressure<out.s16.pressure);
// Maximum field-speed benefit intentionally capped at 7% so tracks are not a universal speed meta.
assert(fieldRate(4,variants.s30)<=4*1.07+1e-9);
console.log(JSON.stringify({pass:true,checks:6,scenario:'T8, 1000 га тяжёлой + 1000 га лёгкой полевой работы, 1200 км дорожных перегонов',results:Object.fromEntries(Object.entries(out).map(([k,x])=>[k,{fieldHours:+x.fieldH.toFixed(1),roadHours:+x.roadH.toFixed(1),totalHours:+x.totalH.toFixed(1),fuelL:+x.fuel.toFixed(0),soilIndex:+x.pressure.toFixed(0),cropImpact:+x.cropImpact.toFixed(0)}])),conclusion:'широкий SmartTrax выигрывает в тяге/уплотнении, но платит дорожной скоростью; узкий SmartTrax лучше для рядков; прирост полевой скорости ограничен'},null,2));
