const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').resolve(__dirname,'..');
const ctx={window:{},console}; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(root+'/web/equipment.js','utf8'),ctx);
const C=ctx.window.EQUIPMENT_CATALOG;
const small=C.filter(x=>x.type==='tractor'&&x.hp>=50&&x.hp<80);
const core=['plow','cultivate','disk','harrow','sow_grain','fertilizer','sprayer'];
const minHp={}; for(const cat of core){const arr=C.filter(x=>x.type==='implement'&&x.category===cat&&!x.selfPropelled);minHp[cat]=Math.min(...arr.map(x=>x.requiredHp));}
let checks=0; function ok(cond,msg){checks++;assert.ok(cond,msg)}
ok(small.length>=15,`expected >=15 tractors 50-79 hp, got ${small.length}`);
for(const cat of core) ok(minHp[cat]<=60,`${cat} starts at ${minHp[cat]} hp`);
const brands=['John Deere','Case IH','New Holland','CLAAS','Fendt','Massey Ferguson','Valtra','DEUTZ-FAHR','STEYR','McCormick','Landini','LOVOL','YTO','Беларус'];
for(const b of brands) ok(small.some(x=>x.name.startsWith(b)),`no small tractor for ${b}`);
for(const t of small){
 const usable=C.filter(x=>x.type==='implement'&&!x.selfPropelled&&Number(x.requiredHp||0)<=t.hp);
 for(const cat of ['plow','cultivate','sow_grain','fertilizer','sprayer']) ok(usable.some(x=>x.category===cat),`${t.name}: no ${cat}`);
}
console.log(`SMALL TRACTOR ECOSYSTEM PASS: ${checks} checks; tractors=${small.length}; minHp=${JSON.stringify(minHp)}`);
