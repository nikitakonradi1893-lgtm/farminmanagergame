const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start);assert(end>start,next);return src.slice(start,end)+';'}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(n,d=1)=>Number(n).toFixed(d);ctx.state={gameTime:new Date(2029,2,20).getTime()};ctx.cropStage=()=>({progress:.25});ctx.soilKnown=()=>true;ctx.roundDose=(v,step)=>Math.max(step,Math.ceil(v/step)*step);ctx.materialAvgCost=id=>({fert_nitrate:42,fert_urea:48,fert_ammophos:66,fert_npk:58,fert_potash:46,fert_lime:6500}[id]||1);ctx.fertilizerCost=(f,op,dose)=>f.ha*dose*ctx.materialAvgCost(ctx.FERTS[op].materialId);vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);
vm.runInContext(constBlock('FERTS','const SOIL_TEST_COST')+'this.FERTS=FERTS;',ctx);
for(const n of ['soilBufferFactor','nutrientAvailability','seasonalNitrogenCredit','nutrientSupply','fertilizerUseEfficiency','limePhGainPerTon','targetYieldRange','yieldTargetFor','targetNutrientNeeds','nitrogenExcessRisk','nitrogenExcessFactor','limeRecoveryPlan','targetNutrientPlan'])vm.runInContext(fn(n),ctx);
let checks=0;
const f={ha:100,crop:null,yieldTargets:{spring_wheat:3.8},soil:{type:'Суглинок',ph:5.45,N:38,P:35,K:42,organicMatter:2.2,strawNPool:0},lastCrop:'corn',moisture:55};
const base=ctx.CROPS.spring_wheat.baseYield,low=ctx.targetNutrientNeeds('spring_wheat',2.5),high=ctx.targetNutrientNeeds('spring_wheat',4.0);
assert(high.N>low.N&&high.P>low.P&&high.K>low.K);checks++;assert(high.N-low.N>20&&high.P-low.P>10&&high.K-low.K>10);checks++;
assert.strictEqual(ctx.yieldTargetFor(f,'spring_wheat'),3.8);checks++;
f.crop='spring_wheat';f.seasonYieldTarget=3.5;assert.strictEqual(ctx.yieldTargetFor(f,'spring_wheat'),3.5);checks++;f.crop=null;f.seasonYieldTarget=null;
const plan=ctx.targetNutrientPlan(f,'spring_wheat');assert(plan.steps.length>=2);checks++;assert(plan.future.some(x=>x.op==='nitrate'));checks++;assert(plan.lime.needed&&plan.lime.years>=1&&plan.lime.years<=3);checks++;
const rich={...f,yieldTargets:{spring_wheat:2.6},soil:{...f.soil,N:120,ph:6.4,P:80,K:80,organicMatter:3}};assert(ctx.nitrogenExcessRisk(rich,'spring_wheat')>0);checks++;assert(ctx.nitrogenExcessFactor(rich,'spring_wheat')<1);checks++;
for(const text of ['Технологическая карта · цель урожайности','ЦЕЛЕВАЯ УРОЖАЙНОСТЬ','ТЕХНОЛОГИЧЕСКАЯ ЦЕПОЧКА ПОЛЯ','ЭТАПЫ ПИТАНИЯ','Риск перекорма азотом','data-target-yield',"version:'0.11.9.74'",'seasonYieldTarget']){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,target:ctx.yieldTargetFor(f,'spring_wheat'),planSteps:plan.steps.map(x=>({stage:x.stage,op:x.op,dose:x.dose})),future:plan.future,lime:plan.lime},null,2));
