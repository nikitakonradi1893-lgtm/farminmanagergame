const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG;
const rate=m=>m.width*m.speed*(m.eff||.78)/10;
const cats=['disk','deepRip','cultivate','sow_grain'];
const tiers=[400,500,600,720];
const best=(hp,cat)=>E.filter(m=>m.type==='implement'&&m.category===cat&&(m.requiredHp||0)<=hp).sort((a,b)=>rate(b)-rate(a))[0];
const areas=[1000,3000,5000]; let checks=0; const out={};
for(const A of areas){out[A]={};for(const hp of tiers){let hours=0,capex=0;const picks={};for(const c of cats){const m=best(hp,c);hours+=A/rate(m);capex+=m.price;picks[c]=m.name;}out[A][hp]={hours:+hours.toFixed(1),implementCapexM:+(capex/1e6).toFixed(1),picks};}
assert(out[A][600].hours<out[A][400].hours*.70);checks++;
assert(out[A][720].hours<out[A][600].hours);checks++;
}
// Capital intensity: high-power package must remain materially more expensive than the 400-hp package.
assert(out[3000][600].implementCapexM>out[3000][400].implementCapexM*1.5);checks++;
assert(out[3000][720].implementCapexM>=out[3000][600].implementCapexM);checks++;
console.log(JSON.stringify({pass:true,checks,scenarios:out,interpretation:'600+ hp materially reduces seasonal hours, but requires much larger implement capital; 720 hp adds another narrower gain rather than replacing every lower tier'},null,2));
