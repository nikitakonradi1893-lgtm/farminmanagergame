const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const H=3600000,DAY=24*H,start=new Date(2028,4,18,8).getTime(),end=start+48*H;
const ctx={Math,Number,Date,DAY};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(v,d=0)=>Number(v).toFixed(d);ctx.rub=v=>`${Math.round(v)} ₽`;
ctx.state={gameTime:start,staff:{owner:{id:'OWNER',role:'owner',name:'Владелец',skill:40,busyUntil:0,restUntil:0},employees:[],market:[],gigBusyUntil:{},gigRestUntil:{}}};
ctx.roleForUnit=()=> 'operator';ctx.unitSkillRequirement=()=>({threshold:50});ctx.activeEmployee=e=>e&&(!e.contractEnd||e.contractEnd>ctx.state.gameTime);ctx.ownerWorker=()=>ctx.state.staff.owner;ctx.gigCandidateFree=(c,at)=>Number(ctx.state.staff.gigBusyUntil[c.id]||0)<=at&&Number(ctx.state.staff.gigRestUntil[c.id]||0)<=at;ctx.seasonalContractCost=(c,days)=>Math.round(c.salaryMonthly*(days/30)*1.25);
vm.createContext(ctx);for(const n of ['managementWorkerQualified','managementWorkerAvailableHours','managementStaffScenarios','managementStaffRecommendation'])vm.runInContext(fn(n),ctx);
let checks=0;const unit={key:'u1',assets:[]};
ctx.state.staff.employees=[
 {id:'P1',role:'operator',name:'Штатный',skill:70,contract:'permanent',salaryMonthly:80000,busyUntil:0,restUntil:0},
 {id:'S1',role:'operator',name:'Сезонный действующий',skill:68,contract:'seasonal',contractEnd:start+20*DAY,busyUntil:0,restUntil:0},
 {id:'BAD',role:'operator',name:'Без допуска',skill:45,contract:'permanent',salaryMonthly:60000,busyUntil:0,restUntil:0}
];
ctx.state.staff.market=[
 {id:'LAB-S',role:'operator',name:'Кандидат сезонный',skill:72,marketType:'seasonal',salaryMonthly:90000,hourlyRate:900},
 {id:'LAB-G',role:'operator',name:'Разовый дешёвый',skill:66,marketType:'permanent',salaryMonthly:75000,hourlyRate:700}
];
let s=ctx.managementStaffScenarios([unit],start,end,44);assert(s);checks++;
assert.strictEqual(s.permanentHours,16);checks++; // owner has no qualification; one permanent = 8h/day
assert.strictEqual(s.currentHours,32);checks++;   // + one active seasonal
assert.strictEqual(s.seasonalHours,48);checks++; // seasonal candidate adds another daily shift, capped by calendar horizon
assert.strictEqual(s.gigHours,44);checks++;      // gig-only scenario: current staff + one 12h shift
assert.strictEqual(s.comboHours,48);checks++;    // seasonal + gig can fill the calendar horizon
assert(s.seasonalCost>0);checks++;
// Busy/rest availability must reduce hours.
ctx.state.staff.employees[0].busyUntil=start+24*H;s=ctx.managementStaffScenarios([unit],start,end,60);assert.strictEqual(s.permanentHours,8);checks++;assert.strictEqual(s.currentHours,24);checks++;
// Remove seasonal market candidate: one gig adds at most 12h, never becomes infinite replacement.
ctx.state.staff.market=ctx.state.staff.market.filter(x=>x.id!=='LAB-S');s=ctx.managementStaffScenarios([unit],start,end,60);assert.strictEqual(s.seasonalHours,24);checks++;assert.strictEqual(s.gigHours,36);checks++;assert.strictEqual(s.gigAdd,12);checks++;assert.strictEqual(s.gigCost,8400);checks++;
// Qualification gate.
ctx.state.staff.employees=[{id:'LOW',role:'operator',name:'low',skill:49,contract:'permanent',salaryMonthly:50000,busyUntil:0,restUntil:0}];ctx.state.staff.owner.skill=40;ctx.state.staff.market=[];s=ctx.managementStaffScenarios([unit],start,end,20);assert.strictEqual(s.currentHours,0);checks++;
// Active task: 8h/day really provides only 16 work-hours in 48 calendar hours.
ctx.taskBreakdownStartAt=()=>start;ctx.taskShiftCoverage=t=>t.shiftCoverageHours;vm.runInContext(fn('managementTaskShiftHoursUntil'),ctx);assert.strictEqual(ctx.managementTaskShiftHoursUntil({shiftCoverageHours:8,gigRequirements:[]},end,start),16);checks++;assert.strictEqual(ctx.managementTaskShiftHoursUntil({shiftCoverageHours:24,gigRequirements:[]},end,start),48);checks++;
const gigTask={shiftCoverageHours:24,gigRequirements:[{}],nextGigStaffingAt:start+12*H};assert.strictEqual(ctx.managementTaskShiftHoursUntil(gigTask,end,start),12);checks++;
for(const text of ['Реальная кадровая ёмкость','Разовый работник считается только на одну смену до 12 ч','managementStaffScenarios','managementTaskShiftHoursUntil',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,example:{calendarHours:48,permanentHours:8,currentHours:24,gigOneShiftMaxH:12}},null,2));
