const assert=require('assert');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function risk100({h,cond,ov=0,svc=0,stress=1,reliability=.9,tires=false}){let pct=.025;pct+=Math.min(.36,Math.max(0,h-2500)/1000*.026);pct+=Math.max(0,70-cond)*.010;pct+=ov*.095;pct+=Math.min(.14,svc*.009);pct+=Math.max(0,stress-1)*.55;if(tires)pct*=.38;return clamp(pct/Math.max(.72,reliability),.01,2.5)}
const stages=[
 {name:'новый/малый ресурс',h:1000,cond:92,ov:0,svc:0},
 {name:'средняя наработка',h:5000,cond:85,ov:0,svc:3},
 {name:'возрастной узел',h:10000,cond:75,ov:1,svc:8},
 {name:'старый многократно ремонтированный',h:20000,cond:55,ov:3,svc:20}
].map(x=>({...x,pct:+risk100(x).toFixed(3)}));
for(let i=1;i<stages.length;i++)assert(stages[i].pct>stages[i-1].pct,'critical risk must grow with age/services/overhauls');
assert(risk100({h:10000,cond:70,ov:2,svc:8})>risk100({h:10000,cond:70,ov:1,svc:8}));
assert(risk100({h:10000,cond:70,ov:1,svc:9})>risk100({h:10000,cond:70,ov:1,svc:8}));
assert(risk100({h:10000,cond:70,ov:1,svc:8,stress:1.25})>risk100({h:10000,cond:70,ov:1,svc:8,stress:1}));
function operationRisk(pct100,h){return 1-Math.pow(1-pct100/100,h/100)}
const pOld=risk100(stages[3]);
const sixHalf=operationRisk(pOld,6.5);
assert(sixHalf>0&&sixHalf<.02);
const installH=36, used={deliveryH:6,totalH:42}, fresh={deliveryH:72,totalH:108}, warehouse={deliveryH:0,totalH:36};
assert(warehouse.totalH<used.totalH&&used.totalH<fresh.totalH);
function rescue(rem,opCost=4200,tier=1.12,mobil=10500){return Math.round(opCost*rem*tier)+mobil}
assert(rescue(40)<rescue(100));
console.log(JSON.stringify({pass:true,checks:10,riskStages:stages,oldNodeRiskDuring6_5hPct:+(sixHalf*100).toFixed(3),replacementHours:{warehouse:36,used:42,new:108},contractorRemaining40haRub:rescue(40),contractorFull100haRub:rescue(100),meaning:'критический отказ проверяется внутри операции; риск растёт с наработкой, ТО/капремонтами, плохим состоянием и перегрузкой; подрядчик оплачивается только за остаток'},null,2));
