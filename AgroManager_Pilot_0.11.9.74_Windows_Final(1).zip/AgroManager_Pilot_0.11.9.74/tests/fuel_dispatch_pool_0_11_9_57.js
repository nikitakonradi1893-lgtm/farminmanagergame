const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`fd57-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__fd57={buildFuelLogisticsPlan,rebuildFuelDispatchPool,processFuelDispatchEvents,fuelDispatchState,fuelPoolSupplyUnits,freshState,setState(x){state=x},getState(){return state},getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__fd57,e=Array.from(a.getEquip());let checks=0;
assert(src.includes("version:'0.11.9.74'"));checks++;
const mk=(id,modelId)=>({id,modelId,farmId:id,busyUntil:0,condition:100,systems:{engine:100,transmission:100,running:100,hydraulics:100}});
const k1=mk('K1','k700'),k2=mk('K2','k700'),don=mk('D1','don1500b'),gaz=mk('G1','fuel_gazelle3302'),ibc=mk('IBC1','fuel_ibc1000');
const st=a.freshState('medium');st.infrastructure.fuelLiters=5000;st.infrastructure.fuelAvgCost=70;st.equipment.fleet=[k1,k2,don,gaz,ibc];st.fields=[{id:1,code:'F-1',ha:100,distanceKm:20,crop:'spring_wheat'},{id:2,code:'F-2',ha:100,distanceKm:25,crop:'spring_wheat'},{id:3,code:'F-3',ha:100,distanceKm:30,crop:'spring_wheat'}];a.setState(st);
const now=st.gameTime;
// One shared IBC must serve three simultaneous operations rather than being locked to one field.
st.tasks=[
 {id:'T1',fieldId:1,op:'cultivate',end:now+10*3600000,returnEnd:now+10*3600000,machineAssetIds:['K1'],workerIds:[],fuelLogistics:{mode:'ibc',baseEnd:now+10*3600000,baseReturnEnd:now+10*3600000,demands:[{id:'Q1',assetId:'K1',fieldId:1,amountL:400,absoluteAt:now+2*3600000,processed:false}],events:[],machineEndFuel:{K1:120},mainConsumedL:500,unitCost:70}},
 {id:'T2',fieldId:2,op:'plow',end:now+10*3600000,returnEnd:now+10*3600000,machineAssetIds:['K2'],workerIds:[],fuelLogistics:{mode:'ibc',baseEnd:now+10*3600000,baseReturnEnd:now+10*3600000,demands:[{id:'Q2',assetId:'K2',fieldId:2,amountL:400,absoluteAt:now+5*3600000,processed:false}],events:[],machineEndFuel:{K2:120},mainConsumedL:500,unitCost:70}},
 {id:'T3',fieldId:3,op:'harvest',end:now+10*3600000,returnEnd:now+10*3600000,machineAssetIds:['D1'],workerIds:[],fuelLogistics:{mode:'ibc',baseEnd:now+10*3600000,baseReturnEnd:now+10*3600000,demands:[{id:'Q3',assetId:'D1',fieldId:3,amountL:400,absoluteAt:now+8*3600000,processed:false}],events:[],machineEndFuel:{D1:150},mainConsumedL:500,unitCost:70}}
];
let fd=a.rebuildFuelDispatchPool(now);const service=fd.events.filter(x=>x.kind==='pool_service'),reloads=fd.events.filter(x=>x.kind==='pool_reload');
assert.strictEqual(service.length,3);checks++;
assert(service.every(x=>x.unitKey==='ibc:G1:IBC1'));checks++;
assert.strictEqual(reloads.length,2);checks++;
assert(Math.abs(reloads[0].loadL-1000)<1e-6);checks++;
assert(Math.abs(reloads[1].loadL-200)<1e-6);checks++;
assert.strictEqual(Math.round(reloads.reduce((s,x)=>s+x.loadL,0)),1200);checks++;
assert(st.tasks.every(t=>(t.fuelLogistics.poolWaitH||0)<0.01));checks++;
assert.strictEqual(gaz.busyUntil,0);assert.strictEqual(ibc.busyUntil,0);checks+=2;
// Batch accounting: first route removes 1000 L, later only the missing 200 L.
st.gameTime=reloads[0].at+1;a.processFuelDispatchEvents();assert.strictEqual(Math.round(st.infrastructure.fuelLiters),4000);checks++;
for(const ev of a.fuelDispatchState().events.filter(x=>!x.processed&&x.kind==='pool_service'&&x.at<=reloads[1].at)){st.gameTime=ev.at+1;a.processFuelDispatchEvents();}
const second=a.fuelDispatchState().events.find(x=>!x.processed&&x.kind==='pool_reload');assert(second&&Math.round(second.loadL)===200);checks++;
st.gameTime=second.at+1;a.processFuelDispatchEvents();assert(st.infrastructure.fuelLiters<=3800&&st.infrastructure.fuelLiters>3750);checks++;
// Tight simultaneous deadlines: one IBC creates measurable wait instead of impossible double-booking.
const st2=a.freshState('medium');st2.infrastructure.fuelLiters=5000;st2.equipment.fleet=[mk('K1','k700'),mk('K2','k700'),mk('G1','fuel_gazelle3302'),mk('IBC1','fuel_ibc1000')];st2.fields=[{id:1,code:'F-1',ha:100,distanceKm:20},{id:2,code:'F-2',ha:100,distanceKm:45}];const n2=st2.gameTime;st2.tasks=[{id:'A',fieldId:1,op:'cultivate',end:n2+8*3600000,returnEnd:n2+8*3600000,machineAssetIds:['K1'],workerIds:[],fuelLogistics:{mode:'ibc',baseEnd:n2+8*3600000,baseReturnEnd:n2+8*3600000,demands:[{id:'A1',assetId:'K1',fieldId:1,amountL:700,absoluteAt:n2+1*3600000,processed:false}],events:[]}},{id:'B',fieldId:2,op:'cultivate',end:n2+8*3600000,returnEnd:n2+8*3600000,machineAssetIds:['K2'],workerIds:[],fuelLogistics:{mode:'ibc',baseEnd:n2+8*3600000,baseReturnEnd:n2+8*3600000,demands:[{id:'B1',assetId:'K2',fieldId:2,amountL:700,absoluteAt:n2+1.1*3600000,processed:false}],events:[]}}];a.setState(st2);a.rebuildFuelDispatchPool(n2);assert(st2.tasks.some(t=>(t.fuelLogistics.poolWaitH||0)>0.1));checks++;
console.log(JSON.stringify({pass:true,checks,sharedPool:{services:service.length,reloads:reloads.map(x=>x.loadL),baseAfterSecond:Math.round(st.infrastructure.fuelLiters)},tightDeadlines:{waits:st2.tasks.map(t=>t.fuelLogistics.poolWaitH||0)}},null,2));
