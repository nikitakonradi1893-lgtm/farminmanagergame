const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
let saved=0,rendered=0,toasts=[];
const DAY=86400000,start=new Date(2028,3,10,9,30).getTime();
const ctx={Math,Number,Date,DAY,realtimeAdvanceDepth:0,state:{gameTime:start,criticalAlert:null},lastReal:0,realtimeMinuteRemainderMs:0,advanceRealtimeClock:()=>0,advanceSystems:(old,target)=>target,save:()=>saved++,render:()=>rendered++,toast:x=>toasts.push(x),setGameSpeed:()=>{},dateFmt:x=>String(x)};
vm.createContext(ctx);vm.runInContext(fn('advanceGameTimeTo')+'\n'+fn('skipDays'),ctx);
ctx.skipDays(5);assert.strictEqual(ctx.state.gameTime,start+5*DAY);assert.strictEqual(saved,1);assert.strictEqual(rendered,1);assert(toasts.at(-1).includes('5'));
ctx.state.gameTime=start;ctx.skipDays(10);assert.strictEqual(ctx.state.gameTime,start+10*DAY);assert.strictEqual(saved,2);assert.strictEqual(rendered,2);assert(toasts.at(-1).includes('10'));
ctx.advanceSystems=(old,target)=>old+30*60000;ctx.state.gameTime=start;ctx.skipDays(5);assert.strictEqual(ctx.state.gameTime,start+30*60000);assert(toasts.at(-1).includes('остановлена'));
let advanced=false;ctx.advanceSystems=()=>{advanced=true;return 0};ctx.state.criticalAlert={type:'breakdown'};ctx.state.gameTime=start;ctx.skipDays(5);assert.strictEqual(advanced,false);assert.strictEqual(ctx.state.gameTime,start);assert(toasts.at(-1).includes('завершите'));
assert(src.includes("document.querySelectorAll('[data-skip]').forEach"));
assert(src.includes("version:'0.11.9.74'"));
const idx=fs.readFileSync('web/index.html','utf8');assert(idx.includes('data-skip="5"'));assert(idx.includes('data-skip="10"'));assert(idx.includes('PILOT 0.11.9.74'));
console.log(JSON.stringify({pass:true,checks:14,skipDays:[5,10],interruptSafe:true,criticalAlertGuard:true},null,2));
