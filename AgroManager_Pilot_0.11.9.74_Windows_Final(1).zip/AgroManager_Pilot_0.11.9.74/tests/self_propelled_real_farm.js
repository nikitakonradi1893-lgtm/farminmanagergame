const assert=require('assert');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function risk100(h,cond,ov=0,svc=0,stress=1,reliability=.88,tires=false){let pct=.025;pct+=Math.min(.36,Math.max(0,h-2500)/1000*.026);pct+=Math.max(0,70-cond)*.010;pct+=ov*.095;pct+=Math.min(.14,svc*.009);pct+=Math.max(0,stress-1)*.55;if(tires)pct*=.38;return clamp(pct/Math.max(.72,reliability),.01,2.5)}
function wear(cond,hours,base,mult=1){return clamp(cond-base*hours*mult,1,100)}
function season({combineTire='standard',truckTire='standard'}){
 const tire={standard:{combineTraction:1,combineFuel:1,truckRoad:1,truckFuel:1,soil:1},wide:{combineTraction:1.07,combineFuel:.985,truckRoad:.90,truckFuel:1.015,soil:.76},vf:{combineTraction:1.10,combineFuel:.98,truckRoad:.95,truckFuel:1.01,soil:.70}};
 const ct=tire[combineTire],tt=tire[truckTire];
 const ha=1000,yieldT=3.2,baseRate=2.06,rate=baseRate*(1+(ct.combineTraction-1)*.35),combineH=ha/rate,tons=ha*yieldT,distance=18,capacity=14,road=70*tt.truckRoad,trips=Math.ceil(tons/capacity),truckH=trips*((distance*2)/road+.28),combineFuel=combineH*36*ct.combineFuel,truckFuel=truckH*28*tt.truckFuel;
 return{combineH,truckH,combineFuel,truckFuel,totalFuel:combineFuel+truckFuel,soilFactor:(ct.soil+tt.soil)/2};
}
const standard=season({}),flotation=season({combineTire:'vf',truckTire:'wide'});
assert(flotation.combineH<standard.combineH);
assert(flotation.soilFactor<standard.soilFactor);
// Truck flotation trades road speed for field/soil benefit; total logistics hours should rise.
assert(flotation.truckH>standard.truckH);
// But total fuel must stay within a plausible band, no magical huge saving.
assert(flotation.totalFuel>standard.totalFuel*.85&&flotation.totalFuel<standard.totalFuel*1.15);
let don={engine:78,transmission:74,running:76,hydraulics:72,h:12000,ov:1,svc:8};
let kamaz={engine:82,transmission:80,running:79,hydraulics:84,h:8000,ov:0,svc:6};
for(let y=0;y<5;y++){
 const s=season({combineTire:y%2?'vf':'standard',truckTire:'standard'});
 don.h+=s.combineH;kamaz.h+=s.truckH;
 don.engine=wear(don.engine,s.combineH,.022,1.18);don.transmission=wear(don.transmission,s.combineH,.022,1.08);don.running=wear(don.running,s.combineH,.022,1.22);don.hydraulics=wear(don.hydraulics,s.combineH,.022,.95);
 kamaz.engine=wear(kamaz.engine,s.truckH,.016,1);kamaz.transmission=wear(kamaz.transmission,s.truckH,.016,1.05);kamaz.running=wear(kamaz.running,s.truckH,.016,1.08);kamaz.hydraulics=wear(kamaz.hydraulics,s.truckH,.016,.75);
 don.svc+=1;kamaz.svc+=1;
}
const donRisk=risk100(don.h,don.engine,don.ov,don.svc,1,.82),kamazRisk=risk100(kamaz.h,kamaz.engine,kamaz.ov,kamaz.svc,1,.90);
assert(donRisk>0&&donRisk<2.5);assert(kamazRisk>0&&kamazRisk<2.5);
assert(don.engine>10&&kamaz.engine>50);
console.log(JSON.stringify({pass:true,checks:8,scenario:'1000 га пшеницы, ДОН-1500А + КамАЗ, 5 сезонов',standard:{combineH:+standard.combineH.toFixed(1),truckH:+standard.truckH.toFixed(1),fuel:+standard.totalFuel.toFixed(0),soil:+standard.soilFactor.toFixed(2)},flotation:{combineH:+flotation.combineH.toFixed(1),truckH:+flotation.truckH.toFixed(1),fuel:+flotation.totalFuel.toFixed(0),soil:+flotation.soilFactor.toFixed(2)},after5y:{donEngine:+don.engine.toFixed(1),donCriticalRiskPct100h:+donRisk.toFixed(3),kamazEngine:+kamaz.engine.toFixed(1),kamazCriticalRiskPct100h:+kamazRisk.toFixed(3)},conclusion:'узловая модель и шины дают компромисс и для комбайна/грузовика; нет бесплатного ускорения или топлива'},null,2));
