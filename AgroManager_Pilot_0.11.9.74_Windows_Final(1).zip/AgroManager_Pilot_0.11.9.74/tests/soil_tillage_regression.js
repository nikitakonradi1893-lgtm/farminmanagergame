const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function grab(name,next='function '){const start=src.indexOf(`function ${name}`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start+10);return src.slice(start,end<0?src.length:end);}
const ctx={Math,Number};ctx.clamp=(x,a,b)=>Math.max(a,Math.min(b,x));vm.createContext(ctx);
vm.runInContext(grab('defaultSoil'),ctx);vm.runInContext(grab('normalizeSoil'),ctx);vm.runInContext(grab('soilFactors'),ctx);vm.runInContext(grab('applyTillage'),ctx);
let checks=0;
let s=ctx.normalizeSoil({type:'Суглинок',ph:6.4,N:60,P:55,K:60,residue:70,compaction:68,compactionDepth:24,weeds:30,seedbed:18,organicMatter:3.1},0);assert(Number.isFinite(s.structure)&&Number.isFinite(s.infiltration)&&Number.isFinite(s.plowPan));checks+=3;
function field(){return{technology:'conventional',lastCrop:'spring_wheat',moisture:64,ridged:false,soil:{...ctx.defaultSoil(0),residue:70,compaction:68,compactionDepth:24,plowPan:62,structure:58,infiltration:52,weeds:28,seedbed:18}}}
let f=field();ctx.applyTillage(f,'deepRip',1);assert(f.soil.lastTillageDepth===35);assert(f.soil.plowPan<35);assert(f.soil.infiltration>65);checks+=3;
f=field();const beforePan=f.soil.plowPan,beforeMoist=f.moisture;ctx.applyTillage(f,'plow',1);assert(f.soil.lastTillageDepth===25);assert(f.soil.plowPan>beforePan);assert(f.moisture<beforeMoist);checks+=3;
f=field();ctx.applyTillage(f,'disk',1);assert(f.soil.lastTillageDepth===10&&f.soil.residue<50&&f.soil.structure<58);checks+=3;
f=field();ctx.applyTillage(f,'cultivate',1);assert(f.soil.seedbed>50&&f.soil.lastTillageDepth===8);checks+=2;
const crop={residueTolerance:55};let a=field(),b=field();a.technology='noTill';b.technology='noTill';b.soil.structure=82;b.soil.infiltration=82;b.soil.plowPan=20;const fa=ctx.soilFactors(a,crop),fb=ctx.soilFactors(b,crop);assert(fb.seedbed>fa.seedbed);assert(fb.compaction>fa.compaction);checks+=2;
for(const text of ['ПЛУЖНАЯ ПОДОШВА','СТРУКТУРА','ИНФИЛЬТРАЦИЯ','ГЛУБИНА ПОСЛ. ОБРАБОТКИ',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,example:{deepRip:{plowPan:f.soil.plowPan},noTillPoor:fa,noTillHealthy:fb}},null,2));
