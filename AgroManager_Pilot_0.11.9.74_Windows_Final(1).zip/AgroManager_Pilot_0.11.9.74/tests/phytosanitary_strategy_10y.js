const assert=require('assert');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
// Long-horizon system test mirrors 0.11.8.74's persistent seed-bank / carryover rules.
function season(s,{crop='winter_wheat',sameGroup=false,technology='minTill',treat=true,wet=true}){
 const weedTech=technology==='noTill'?1.14:technology==='conventional'?.88:1.0;
 let weed=clamp(12+s.seedBank*.42*weedTech,0,100);
 let disease=clamp(6+s.disease*.22+(sameGroup?14:0)+(wet?18:5)+(technology==='noTill'?6:technology==='conventional'?-5:0),0,100);
 let pest=clamp(5+s.pest*.18+(sameGroup?5:0)+(crop==='rapeseed'?14:4),0,100);
 let sprays=0;
 if(treat&&weed>22){weed*=.42;s.seedBank=clamp(s.seedBank-5,0,100);sprays++;}
 if(treat&&disease>40){disease*=.35;sprays++;}
 if(treat&&pest>38){pest*=.30;sprays++;}
 const damage=clamp(Math.max(0,disease-40)*.0024+Math.max(0,pest-38)*.0018+Math.max(0,weed-18)*.0020,0,.35);
 s.seedBank=clamp(s.seedBank+Math.max(0,weed-18)*.16-2,0,100);
 s.disease=clamp(s.disease*.62+damage*115+(technology==='noTill'?12:technology==='conventional'?2:8)+(sameGroup?9:0),0,100);
 s.pest=clamp(s.pest*.58+damage*90,0,100);
 if(technology==='conventional'){s.seedBank=clamp(s.seedBank-8,0,100);s.disease=clamp(s.disease-10,0,100);}else if(technology==='minTill'){s.seedBank=clamp(s.seedBank-4,0,100);s.disease=clamp(s.disease-4,0,100);}
 return{damage,sprays,weed,disease,pest};
}
function run(mode){const s={seedBank:42,disease:18,pest:12};let damage=0,sprays=0;for(let y=0;y<10;y++){let cfg;if(mode==='mono_no_protection')cfg={crop:'winter_wheat',sameGroup:y>0,technology:'noTill',treat:false,wet:y%3!==0};else if(mode==='mono_threshold')cfg={crop:'winter_wheat',sameGroup:y>0,technology:'minTill',treat:true,wet:y%3!==0};else cfg={crop:['winter_wheat','peas','rapeseed','barley'][y%4],sameGroup:false,technology:'minTill',treat:true,wet:y%3!==0};const r=season(s,cfg);damage+=r.damage;sprays+=r.sprays;}return{...s,damage,sprays};}
const bad=run('mono_no_protection'),mono=run('mono_threshold'),rotation=run('rotation_threshold');
assert(bad.damage>mono.damage);assert(rotation.disease<mono.disease);assert(rotation.damage<=mono.damage+.03);assert(mono.sprays>0&&rotation.sprays>0);assert(rotation.seedBank<bad.seedBank);assert(bad.disease>rotation.disease);
console.log(JSON.stringify({pass:true,checks:6,tenYears:{monocultureNoProtection:bad,monocultureThreshold:mono,rotationThreshold:rotation}},null,2));
