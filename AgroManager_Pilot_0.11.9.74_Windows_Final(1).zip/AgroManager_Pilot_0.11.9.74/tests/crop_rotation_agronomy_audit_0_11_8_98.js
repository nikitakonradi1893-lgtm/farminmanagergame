const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let depth=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){depth++;seen=true;}else if(src[i]==='}'){depth--;if(seen&&depth===0){end=i+1;break;}}}return src.slice(start,end);}
function constBlock(name,nextToken){const start=src.indexOf(`const ${name}=`);assert(start>=0,`missing const ${name}`);const end=src.indexOf(nextToken,start);assert(end>start,`missing next token for ${name}`);return src.slice(start,end).trim().replace(/;?$/,';');}
const ctx={Math,Number,Date};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','\n\nconst ROTATION_GUIDE='),ctx);vm.runInContext('this.CROPS=CROPS',ctx);
vm.runInContext(constBlock('ROTATION_TRAITS','\nfunction rotationTrait'),ctx);vm.runInContext('this.ROTATION_TRAITS=ROTATION_TRAITS',ctx);
for(const n of ['rotationTrait','nitrogenFixingCrop','sclerotiniaHost','rotationPredecessorFactor','rotationFactorFor','rotationSanitaryMultiplier'])vm.runInContext(fn(n),ctx);
let checks=0;
const field=(last,hist=[])=>({lastCrop:last,cropHistory:hist.map(c=>({crop:c}))});
const near=(a,b,t=1e-9)=>assert(Math.abs(a-b)<=t,`${a} != ${b}`);
// Full pair matrix: every field crop must produce a finite bounded rotation and sanitary result.
const fieldCrops=Object.keys(ctx.CROPS).filter(k=>ctx.CROPS[k].fieldCrop!==false);
for(const prev of fieldCrops)for(const cur of fieldCrops){const rf=ctx.rotationFactorFor(field(prev,[prev]),cur),sm=ctx.rotationSanitaryMultiplier(field(prev,[prev]),cur);assert(Number.isFinite(rf)&&rf>=.62&&rf<=1.08,`${prev}->${cur} rotation ${rf}`);assert(Number.isFinite(sm)&&sm>=.82&&sm<=1.65,`${prev}->${cur} sanitary ${sm}`);checks+=2;}
// Small grains: cereal after cereal remains a real penalty.
assert(ctx.rotationFactorFor(field('barley'),'spring_wheat')<1);checks++;
// Corn -> wheat is specifically risky, not falsely rewarded as an unrelated group.
assert(ctx.rotationFactorFor(field('corn'),'spring_wheat')<ctx.rotationFactorFor(field('peas'),'spring_wheat'));checks++;
assert(ctx.rotationSanitaryMultiplier(field('corn',['corn']),'spring_wheat')>1);checks++;
// Forage legumes are recognized as N-fixing predecessors, unlike ordinary grass.
assert(ctx.nitrogenFixingCrop('alfalfa')&&ctx.nitrogenFixingCrop('clover'));checks+=2;
assert(ctx.rotationFactorFor(field('alfalfa'),'winter_wheat')>ctx.rotationFactorFor(field('perennial_grass'),'winter_wheat'));checks++;
// Potato and sugar beet are not punished merely because both are operationally "root" crops.
near(ctx.rotationPredecessorFactor('potato','sugar_beet'),1);checks++;
near(ctx.rotationPredecessorFactor('sugar_beet','potato'),1);checks++;
// Sclerotinia-host broadleaf sequences are recognized across different operational groups.
assert(ctx.rotationPredecessorFactor('sunflower','rapeseed')<1);checks++;
assert(ctx.rotationSanitaryMultiplier(field('sunflower',['sunflower']),'rapeseed')>1);checks++;
assert(ctx.rotationSanitaryMultiplier(field('soybean',['soybean']),'sunflower')>1);checks++;
// Short return intervals for sensitive crops are worse than a long break.
const rape1=ctx.rotationFactorFor(field('barley',['rapeseed','barley']),'rapeseed');
const rapeLong=ctx.rotationFactorFor(field('barley',['winter_wheat','peas','barley','rapeseed']),'rapeseed');
assert(rape1<rapeLong);checks++;
const sun1=ctx.rotationFactorFor(field('barley',['sunflower','barley']),'sunflower');
const sunLong=ctx.rotationFactorFor(field('barley',['winter_wheat','peas','barley','sunflower']),'sunflower');
assert(sun1<sunLong);checks++;
const beet1=ctx.rotationFactorFor(field('barley',['sugar_beet','barley']),'sugar_beet');
const beetLong=ctx.rotationFactorFor(field('barley',['winter_wheat','peas','barley','sugar_beet']),'sugar_beet');
assert(beet1<beetLong);checks++;
// Immediate monoculture remains the strongest direct rotation penalty.
assert(ctx.rotationFactorFor(field('spring_wheat'),'spring_wheat')<ctx.rotationFactorFor(field('barley'),'spring_wheat'));checks++;
console.log(JSON.stringify({pass:true,checks,examples:{wheatAfterBarley:ctx.rotationFactorFor(field('barley'),'spring_wheat'),wheatAfterCorn:ctx.rotationFactorFor(field('corn'),'spring_wheat'),wheatAfterPeas:ctx.rotationFactorFor(field('peas'),'spring_wheat'),wheatAfterAlfalfa:ctx.rotationFactorFor(field('alfalfa'),'spring_wheat'),beetAfterPotato:ctx.rotationFactorFor(field('potato'),'sugar_beet'),rapeseedAfterSunflower:ctx.rotationFactorFor(field('sunflower'),'rapeseed'),sanitaryWheatAfterCorn:ctx.rotationSanitaryMultiplier(field('corn',['corn']),'spring_wheat')}},null,2));
