const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const ctx={Math,Number,Date};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.state={gameTime:new Date(2028,4,18,8).getTime()};ctx.managementWindowFor=()=>({start:ctx.state.gameTime-10*86400000,optimalEnd:ctx.state.gameTime+48*3600000,end:ctx.state.gameTime+48*3600000,label:'посев'});vm.createContext(ctx);vm.runInContext(fn('managementWindowForecast'),ctx);
let checks=0;
const f={id:1,ha:63};
const q=ctx.managementWindowForecast(f,'sow','spring_wheat',1,63,ctx.state.gameTime,0);
assert(Math.abs(q.hours-63)<1e-9);checks++;
assert(Math.round(q.windowShare*100)===76);checks++;
assert(q.finishAt>q.window.end);checks++;
const fast=ctx.managementWindowForecast(f,'sow','spring_wheat',1.5,63,ctx.state.gameTime,0);assert(fast.windowShare===1);checks++;
const partial=ctx.managementWindowForecast(f,'sow','spring_wheat',1,23,ctx.state.gameTime,40);assert(partial.windowShare===1);checks++;
for(const text of ["version:'0.11.9.74'",'Центр управления','Поля и агрономические окна','Техника и сервис','Деньги на ближайшие 30 дней','managementFieldRows','managementEquipmentRows','managementFinance30d','managementReadOnlyTaskRemaining']){assert(src.includes(text),text);checks++;}
const idx=fs.readFileSync('web/index.html','utf8');assert(idx.includes('data-page="management"'));checks++;assert(idx.includes('PILOT 0.11.9.74'));checks++;
console.log(JSON.stringify({pass:true,checks,example:{areaHa:63,hours:63,hoursToWindowEnd:48,inWindowPct:Math.round(q.windowShare*100),fasterInWindowPct:Math.round(fast.windowShare*100)}},null,2));
