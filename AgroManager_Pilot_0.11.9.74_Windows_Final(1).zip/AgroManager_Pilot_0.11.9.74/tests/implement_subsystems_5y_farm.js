const assert=require('assert');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const ops=[
 {name:'дискование',hours:1000/23.05,systems:['working','frame','hydraulics','running'],mult:{working:1.35,frame:1,hydraulics:1.12,running:1.05}},
 {name:'глубокое рыхление',hours:1000/6.34,systems:['working','frame','hydraulics','running'],mult:{working:1.65,frame:1.18,hydraulics:1.12,running:1.22}},
 {name:'культивация',hours:1000/26.69,systems:['working','frame','hydraulics','running'],mult:{working:1.35,frame:1,hydraulics:1.12,running:1.05}},
 {name:'посев',hours:1000/21.40,systems:['working','metering','hydraulics','running'],mult:{working:1.18,metering:1.28,hydraulics:1.12,running:1.05}}
];
function sim({newAsset=true,start=100,seasons=5}){const assets=ops.map(op=>({name:op.name,hours:0,systems:Object.fromEntries(op.systems.map(k=>[k,start])),protected:Object.fromEntries(op.systems.map(k=>[k,newAsset]))}));let totalH=0;for(let y=0;y<seasons;y++)for(let i=0;i<ops.length;i++){const op=ops[i],a=assets[i],h=op.hours;totalH+=h;for(const k of op.systems){const h0=a.hours,ph=a.protected[k]&&h0<2500?Math.max(0,Math.min(h,2500-h0)):0,eh=(h-ph)+ph*.5;a.systems[k]=clamp(a.systems[k]-.016*eh*op.mult[k],1,100);if(h0+h>=2500)a.protected[k]=false;}a.hours+=h;}
 return{assets,totalH};}
const fresh=sim({newAsset:true,start:100}),used=sim({newAsset:false,start:88});
// Five 1000-ha seasons should age implements meaningfully but not destroy them automatically.
for(const a of fresh.assets){assert(Math.min(...Object.values(a.systems))>88,`${a.name} new became too worn`);}
for(const a of used.assets){assert(Math.min(...Object.values(a.systems))>65,`${a.name} used became too worn`);assert(Math.min(...Object.values(a.systems))<88,`${a.name} used did not wear`);}
function factors(sys,cat){const d=k=>Math.max(0,78-(sys[k]??100))/68,wd=d('working'),md=d('metering'),dd=d('drive'),fd=d('frame'),hd=d('hydraulics'),rd=d('running');return{rate:clamp(1-.22*wd-.12*dd-.10*fd-.06*hd-.05*rd,.68,1),fuel:clamp(1+.10*wd+.08*dd+.04*rd,1,1.18),quality:clamp(1-.13*wd-.09*md-.03*fd-.02*hd,.80,1)}}
const freshFactors=fresh.assets.map(a=>({name:a.name,...factors(a.systems)})),usedFactors=used.assets.map(a=>({name:a.name,...factors(a.systems)}));
assert(freshFactors.every(x=>x.rate>=.98&&x.quality>=.985));
assert(usedFactors.some(x=>x.rate<.97||x.quality<.97));
// Illustrative old/high-hour node critical-risk check: rare per operation, meaningful over years.
function risk100(h,cond,ov=1,svc=8,mult=.72){let pct=.025;pct+=Math.min(.36,Math.max(0,h-2500)/1000*.026);pct+=Math.max(0,70-cond)*.010;pct+=ov*.095;pct+=Math.min(.14,svc*.009);return clamp(pct/.9,.01,2.5)*mult;}
const oldRisk=risk100(12000,58,1,10,.72),per150h=1-Math.pow(1-oldRisk/100,1.5);assert(per150h>0.002&&per150h<.03);
console.log(JSON.stringify({pass:true,seasons:5,areaPerOperationHa:1000,totalImplementHours:+fresh.totalH.toFixed(1),fresh: fresh.assets.map((a,i)=>({name:a.name,hours:+a.hours.toFixed(1),minCondition:+Math.min(...Object.values(a.systems)).toFixed(1),rate:+freshFactors[i].rate.toFixed(3),quality:+freshFactors[i].quality.toFixed(3)})),used: used.assets.map((a,i)=>({name:a.name,hours:+a.hours.toFixed(1),minCondition:+Math.min(...Object.values(a.systems)).toFixed(1),rate:+usedFactors[i].rate.toFixed(3),quality:+usedFactors[i].quality.toFixed(3)})),oldHighHourNodeRiskPctPer100h:+oldRisk.toFixed(3),oldNodeFailureChanceOver150hPct:+(per150h*100).toFixed(3),meaning:'на 1000 га за 5 сезонов новый дилерский агрегат не требует навязчивого ежегодного восстановления; Б/У парк ощутимо стареет; критический отказ старого узла остаётся риском, а не постоянным событием'},null,2));
