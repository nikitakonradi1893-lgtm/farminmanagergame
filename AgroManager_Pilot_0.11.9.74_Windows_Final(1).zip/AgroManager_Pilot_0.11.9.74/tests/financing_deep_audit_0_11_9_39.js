'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__f39={CONFIG,BANKS,LOAN_PRODUCTS,LEASE_TERMS,bankOffer,creditLineOffer,annuityPayment,balloonPayment,loanPaymentSetup,newLoanAnnualDebtService,financingCoverageRatio,financingOperatingCapacity,financingUnderwritingBlock,contractForecastInstallment,processFinancing,addMonthsTs,earlyRepayContract,returnLeaseAsset,get state(){return state},set state(v){state=v},freshState};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__f39;
let checks=0;function ok(x,m){assert(x,m);checks++;}
ok(a.CONFIG.version==='0.11.9.74','version');
ok(a.LOAN_PRODUCTS.seasonal.schedule==='seasonal','seasonal schedule');
ok(a.LOAN_PRODUCTS.investment.schedule==='grace_annuity'&&a.LOAN_PRODUCTS.investment.graceMonths===6,'investment grace');
ok(a.BANKS.agro.minDscr>a.BANKS.regional.minDscr&&a.BANKS.regional.minDscr>a.BANKS.capital.minDscr,'banks differ by DSCR');
ok(a.BANKS.agro.lineLimit<a.BANKS.regional.lineLimit&&a.BANKS.regional.lineLimit<a.BANKS.capital.lineLimit,'line limits differ');
a.state=a.freshState('easy');a.state.gameTime=new Date(2026,0,15).getTime();
const season=a.bankOffer('agro','seasonal'),invest=a.bankOffer('regional','investment');
ok(season.annualRate< a.bankOffer('capital','seasonal').annualRate,'Agro lower rate');
const ss=a.loanPaymentSetup(season,3000000);ok(Math.abs(ss.monthlyPayment-3000000*season.annualRate/12)<2,'seasonal monthly interest only');
const is=a.loanPaymentSetup(invest,12000000);ok(is.graceMonths===6&&is.monthlyPayment>0,'investment post-grace payment');
const annualSeason=a.newLoanAnnualDebtService(season,3000000);ok(annualSeason>3000000,'seasonal underwriting includes principal maturity');
const bp=a.balloonPayment(8000000,.14,48,1500000),ann=a.annuityPayment(8000000,.14,48);ok(bp<ann,'balloon lease lowers monthly payment');ok(a.LEASE_TERMS.residualRate===.15&&a.LEASE_TERMS.termMonths===48,'lease residual/term');
// Seasonal loan: 11 months interest-only, then principal at month 12.
let st=a.state;st.money=10000000;const now=st.gameTime;st.financing.contracts=[{id:'S1',type:'loan',balance:1000000,annualRate:.12,termMonths:12,schedule:'seasonal',monthlyPayment:10000,nextPaymentAt:a.addMonthsTs(now,1),paymentsMade:0,status:'active',arrears:{principal:0,interest:0,penalty:0}}];
a.processFinancing(now,a.addMonthsTs(now,11));let c=st.financing.contracts[0];ok(c.status==='active'&&Math.abs(c.balance-1000000)<1,'seasonal principal preserved before maturity');ok(c.paymentsMade===11,'11 seasonal payments');a.processFinancing(a.addMonthsTs(now,11),a.addMonthsTs(now,12));ok(c.status==='closed'&&c.balance===0,'seasonal principal paid at maturity');
// Missed seasonal maturity must not charge the same principal twice next month.
st=a.freshState('normal');a.state=st;st.gameTime=now;st.money=0;st.financing.contracts=[{id:'S2',type:'loan',balance:1000000,annualRate:.12,termMonths:12,schedule:'seasonal',monthlyPayment:10000,nextPaymentAt:a.addMonthsTs(now,12),paymentsMade:11,status:'active',arrears:{principal:0,interest:0,penalty:0}}];a.processFinancing(now,a.addMonthsTs(now,12));c=st.financing.contracts[0];ok(c.arrears.principal===1000000,'maturity principal moved once to arrears');const ar0=c.arrears.principal;a.processFinancing(a.addMonthsTs(now,12),a.addMonthsTs(now,13));ok(c.arrears.principal===ar0,'overdue principal not duplicated next month');
// Investment loan: six interest-only payments preserve principal.
st=a.freshState('easy');a.state=st;st.money=10000000;st.gameTime=now;const ipay=a.annuityPayment(6000000,.12,54);st.financing.contracts=[{id:'I1',type:'loan',balance:6000000,annualRate:.12,termMonths:60,schedule:'grace_annuity',graceMonths:6,monthlyPayment:ipay,nextPaymentAt:a.addMonthsTs(now,1),paymentsMade:0,status:'active',arrears:{principal:0,interest:0,penalty:0}}];a.processFinancing(now,a.addMonthsTs(now,6));c=st.financing.contracts[0];ok(Math.abs(c.balance-6000000)<1,'investment grace preserves principal');a.processFinancing(a.addMonthsTs(now,6),a.addMonthsTs(now,7));ok(c.balance<6000000,'investment amortizes after grace');
// Lease ends at residual, not zero, and asks for buyout/return.
st=a.freshState('easy');a.state=st;st.money=50000000;st.gameTime=now;const lp=a.balloonPayment(8000000,.14,48,1500000);st.financing.contracts=[{id:'L1',type:'lease',balance:8000000,annualRate:.14,termMonths:48,schedule:'lease_balloon',residualValue:1500000,monthlyPayment:lp,nextPaymentAt:a.addMonthsTs(now,1),paymentsMade:0,status:'active',arrears:{principal:0,interest:0,penalty:0}}];a.processFinancing(now,a.addMonthsTs(now,48));c=st.financing.contracts[0];ok(c.status==='buyout_due','lease reaches buyout decision');ok(c.balance>1400000&&c.balance<1600000,'lease leaves residual value');
// Player can return the leased asset instead of paying residual value.
st.equipment.fleet=[{id:'A-L',modelId:'mtz82',financeContractId:'L1',condition:80,busyUntil:0,repairUntil:0}];a.returnLeaseAsset('L1');ok(st.equipment.fleet.length===0&&c.status==='returned'&&c.balance===0,'lease return removes asset and closes residual');
// Underwriting really blocks an oversized obligation in a weak farm.
st=a.freshState('normal');a.state=st;st.gameTime=now;st.money=100000;const weakOffer=a.bankOffer('agro','development'),uw=a.financingUnderwritingBlock(weakOffer.max,weakOffer,a.newLoanAnnualDebtService(weakOffer,weakOffer.max));ok(typeof uw==='string'&&uw.length>0,'underwriting blocks weak cashflow/collateral');
// UI/runtime hooks exist for lease return and cash-flow coverage.
ok(src.includes('data-return-equipment-lease')&&src.includes('ПОКРЫТИЕ ДОЛГА'),'financing UI exposes buyout/return and coverage');
console.log(`Financing deep audit 0.11.9.47: ${checks}/${checks} PASS`);
