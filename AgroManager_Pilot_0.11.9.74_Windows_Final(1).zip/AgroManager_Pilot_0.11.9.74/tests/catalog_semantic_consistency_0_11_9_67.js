const fs=require('fs'),vm=require('vm');
const box={window:{},console};vm.createContext(box);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),box);
const E=box.window.EQUIPMENT_CATALOG;let pass=0;
function ok(v,msg){if(!v)throw new Error(msg);pass++;}
ok(E.length>=810,`catalog may expand, got ${E.length}`);ok(new Set(E.map(x=>x.id)).size===E.length,'catalog ids unique');
for(const m of E){
 ok(!(m.segment.endsWith('_new')&&!m.newAvailable),`${m.id}: new segment unavailable`);
 ok(!(m.segment.endsWith('_used')&&m.newAvailable),`${m.id}: used segment newAvailable`);
 ok(typeof m.brand==='string'&&m.brand.length>0,`${m.id}: brand missing`);
}
const legacy=['lemken_juwel8_used','lemken_korund8_used','lemken_azurit9_used','bdm6x4_used','palesse_zhzk5_used','gp_yp1625a_used'];
for(const id of legacy){const m=E.find(x=>x.id===id);ok(m&&m.legacyId===true&&m.legacyIdNote,`${id}: undocumented legacy id`);}
console.log(`catalog_semantic_consistency_0_11_9_67: ${pass} PASS`);
