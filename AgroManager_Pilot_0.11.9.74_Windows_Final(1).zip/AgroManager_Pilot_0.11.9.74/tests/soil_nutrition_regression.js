const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let depth=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){depth++;seen=true;}else if(src[i]==='}'){depth--;if(seen&&depth===0){end=i+1;break;}}}return src.slice(start,end);}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start);assert(end>start,next);return src.slice(start,end)+';';}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(n,d=1)=>Number(n).toFixed(d);ctx.state={gameTime:new Date(2028,3,15).getTime()};ctx.cropStage=f=>({progress:f.progress??0});vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);
vm.runInContext(constBlock('FERTS','const SOIL_TEST_COST')+'this.FERTS=FERTS;',ctx);
ctx.SOIL_TEST_VALID_YEARS=3;
for(const n of ['soilBufferFactor','nutrientAvailability','seasonalNitrogenCredit','nutrientSupply','fertilizerUseEfficiency','limePhGainPerTon','ensureNutrientLedger','soilTestAgeYears','soilTestStale','makeSoilTestResult','pHFactor','factorFromNutrientAmounts','targetYieldRange','yieldTargetFor','targetNutrientNeeds','nutrientFactor'])vm.runInContext(fn(n),ctx);
let checks=0;
const acid=ctx.nutrientAvailability({ph:5.0}),neutral=ctx.nutrientAvailability({ph:6.5}),alk=ctx.nutrientAvailability({ph:7.9});
assert(neutral.P>acid.P && neutral.P>alk.P);checks++;
assert(neutral.N>acid.N);checks++;
assert(neutral.K>=acid.K);checks++;
const loam={soil:{type:'Суглинок',ph:6.4,N:48,P:46,K:58,organicMatter:3.2,strawNPool:0},lastCrop:'peas',crop:null,moisture:55};
const bare={soil:{type:'Суглинок',ph:6.4,N:48,P:46,K:58,organicMatter:1.6,strawNPool:0},lastCrop:'corn',crop:null,moisture:55};
assert(ctx.seasonalNitrogenCredit(loam,'spring_wheat')>ctx.seasonalNitrogenCredit(bare,'spring_wheat'));checks++;
const wet={...loam,moisture:95},normal={...loam,moisture:55};assert(ctx.fertilizerUseEfficiency(normal,'urea').N>ctx.fertilizerUseEfficiency(wet,'urea').N);checks++;
assert(ctx.limePhGainPerTon({type:'Супесь'})>ctx.limePhGainPerTon({type:'Чернозём'}));checks++;
const wheat=ctx.CROPS.spring_wheat;assert(ctx.pHFactor({soil:{ph:6.3}},wheat)>ctx.pHFactor({soil:{ph:5.0}},wheat));checks++;
const good={crop:'spring_wheat',soil:{type:'Суглинок',ph:6.5,N:80,P:65,K:65,organicMatter:3,strawNPool:0},lastCrop:'peas'};
const poor={crop:'spring_wheat',soil:{type:'Суглинок',ph:5.0,N:35,P:35,K:40,organicMatter:1.8,strawNPool:0},lastCrop:'corn'};
assert(ctx.nutrientFactor(good,wheat)>ctx.nutrientFactor(poor,wheat));checks++;
const f={soil:{type:'Чернозём',ph:6.4,N:61,P:54,K:67,organicMatter:3.7},soilTest:{status:'done',completedAt:new Date(2024,0,1).getTime()}};ctx.state.gameTime=new Date(2028,0,5).getTime();assert(ctx.soilTestStale(f));checks++;
const r=ctx.makeSoilTestResult(f,ctx.state.gameTime);assert.strictEqual(r.N,61);assert.strictEqual(r.P,54);assert(r.availability.P>.9);checks+=3;
const ledgerField={nutrientLedger:null};let l=ctx.ensureNutrientLedger(ledgerField,new Date(2028,2,1).getTime());l.applied.N=12;l=ctx.ensureNutrientLedger(ledgerField,new Date(2029,2,1).getTime());assert.strictEqual(l.year,2029);assert.strictEqual(l.applied.N,0);checks+=2;
for(const text of ['ДОСТУПНОСТЬ N/P/K','Баланс питания','Анализ устарел',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
assert(src.includes('acidPerKg')&&src.includes('leachedN'));checks+=2;
console.log(JSON.stringify({pass:true,checks,availability:{acid,neutral,alk},credits:{legume:ctx.seasonalNitrogenCredit(loam,'spring_wheat'),plain:ctx.seasonalNitrogenCredit(bare,'spring_wheat')},ureaEfficiency:{normal:ctx.fertilizerUseEfficiency(normal,'urea').N,wet:ctx.fertilizerUseEfficiency(wet,'urea').N},limeGain:{sand:ctx.limePhGainPerTon({type:'Супесь'}),chernozem:ctx.limePhGainPerTon({type:'Чернозём'})}},null,2));
