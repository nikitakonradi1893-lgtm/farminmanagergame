const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0)return src.slice(start,i+1)}}throw new Error(name)}
let checks=0;
// A01: null is absence, not zero/min target.
const ctx={Math,Number};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.CROPS={spring_wheat:{baseYield:3.2}};ctx.targetYieldRange=()=>({min:2.3,max:4.2});vm.createContext(ctx);vm.runInContext(fn('yieldTargetFor'),ctx);
assert.strictEqual(ctx.yieldTargetFor({crop:'spring_wheat',seasonYieldTarget:null,yieldTargets:{spring_wheat:4}},'spring_wheat'),4);checks++;
// A02/A03/A04 schema persistence.
for(const token of ['plannedCrop:CROPS[o?.plannedCrop]','seedQualityFactor:Number.isFinite','sowingEquipmentFactor:Number.isFinite','trafficFactor:Number.isFinite','sowSpatialSummary:o?.sowSpatialSummary','fertilizerSpatial:o?.fertilizerSpatial','limeSpatial:o?.limeSpatial',"distanceKm:clamp(Number.isFinite(o?.distanceKm)?o.distanceKm:(fallback?.distanceKm||2+(i%24)),1,60)",'marketListed:!!lp.marketListed',"marketMode:['both','lease_only','buy_only'].includes(lp.marketMode)",'marketExpiresAt:lp.marketExpiresAt!==null','holdingId:lp.holdingId??null']){assert(src.includes(token),token);checks++;}
// A05: scheduled normal sale reserves warehouse against contract selection.
const c2={Math,Number,state:{warehouse:{stocks:{spring_wheat:100},salesTransit:[{crop:'spring_wheat',status:'scheduled',tons:92}],lots:[{id:'L1',crop:'spring_wheat',tons:100,quality:{score:80},moisture:13}]}}};c2.lotQuality=l=>l.quality;c2.CROPS={spring_wheat:{}};vm.createContext(c2);for(const n of ['reservedSaleTons','reservedWarehouseTons','warehouseFreeTons','qualifyingDeliveryLots','deliveryQualifyingTons'])vm.runInContext(fn(n),c2);assert.strictEqual(c2.warehouseFreeTons('spring_wheat'),8);checks++;assert.strictEqual(c2.deliveryQualifyingTons({crop:'spring_wheat',minQuality:0,maxMoisture:null}),8);checks++;
// A06: active hay packages reserve future hay capacity.
const c3={Math,Number,state:{gameTime:100,tasks:[{op:'hayPackage',end:200,packageTons:25}],warehouse:{stocks:{hay:110}}},baleProducts:new Set(['hay']),rootCrops:new Set(),infraSpec:k=>({cap:k==='hay'?150:1000}),storageSectionSnapshot:()=>[]};vm.createContext(c3);for(const n of ['baleStoredT','reservedIncomingBaleTons','canStoreCropTons'])vm.runInContext(fn(n),c3);assert.strictEqual(c3.canStoreCropTons('hay',25),false);checks++;
// A07: failed save cancels quit.
assert(src.includes("const saved=await writeFileSave('autosave');if(!saved)"));checks++;assert(src.includes("Выход отменён"));checks++;
// A08: open details index is captured in the full details list.
assert(src.includes("map((d,i)=>d.open?i:null).filter(i=>i!==null)"));checks++;
assert(src.includes("version:'0.11.9.74'"));checks++;
console.log(JSON.stringify({pass:true,checks},null,2));
