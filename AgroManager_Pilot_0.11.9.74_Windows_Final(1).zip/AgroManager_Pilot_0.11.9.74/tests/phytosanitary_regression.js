const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let depth=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){depth++;seen=true;}else if(src[i]==='}'){depth--;if(seen&&depth===0){end=i+1;break;}}}return src.slice(start,end);}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start);assert(end>start,next);return src.slice(start,end)+';';}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.hashDate=(ms)=>{let x=(Math.floor(ms/86400000)+0x9e3779b9)|0;x^=x<<13;x^=x>>>17;x^=x<<5;return((x>>>0)%100000)/100000;};
ctx.CROPS={winter_wheat:{group:'cereal'},spring_wheat:{group:'cereal'},barley:{group:'cereal'},corn:{group:'corn'},sunflower:{group:'oilseed'},rapeseed:{group:'oilseed'},soybean:{group:'legume'},peas:{group:'legume'},sugar_beet:{group:'root'},potato:{group:'root'},perennial_grass:{group:'forage'},alfalfa:{group:'forage'},clover:{group:'forage'}};
ctx.cropDef=f=>ctx.CROPS[f.crop];ctx.cropStage=(f,ms)=>({progress:f.progress??.4});ctx.nitrogenExcessRisk=()=>0;ctx.state={gameTime:new Date(2028,5,1).getTime()};vm.createContext(ctx);
vm.runInContext(constBlock('CROP_HEALTH_PROFILES','function cropHealthProfile'),ctx);
vm.runInContext(constBlock('ROTATION_TRAITS','function rotationTrait'),ctx);
for(const n of ['rotationTrait','nitrogenFixingCrop','sclerotiniaHost'])vm.runInContext(fn(n),ctx);
for(const n of ['cropHealthProfile','phytosanitaryState','cropProtectionState','diseaseThreshold','pestThreshold','cropWeedFactor','cropPressureYearRisk','rotationSanitaryMultiplier','residualProtectionFactor','treatmentEfficacy','applyCropPressureDay','protectionFactor'])vm.runInContext(fn(n),ctx);
let checks=0;
assert(ctx.diseaseThreshold({crop:'potato'})<ctx.diseaseThreshold({crop:'corn'}));checks++;
assert(ctx.pestThreshold({crop:'rapeseed'})<ctx.pestThreshold({crop:'winter_wheat'}));checks++;
let rot={crop:'winter_wheat',cropHistory:[{crop:'winter_wheat'},{crop:'spring_wheat'},{crop:'barley'}]};let good={crop:'winter_wheat',cropHistory:[{crop:'peas'},{crop:'sunflower'},{crop:'soybean'}]};assert(ctx.rotationSanitaryMultiplier(rot,'winter_wheat')>ctx.rotationSanitaryMultiplier(good,'winter_wheat'));checks++;
let f={crop:'winter_wheat',progress:.35,soil:{weeds:36,residue:65},moisture:70,cropWeedPressure:38,cropHistory:[],phytosanitary:{weedSeedBank:55,diseaseCarryover:45,pestCarryover:15},cropProtection:{herbicide:false,fungicide:false,insecticide:false,diseasePressure:55,pestPressure:10,diseaseDamage:0,pestDamage:0,lastHerbicideAt:null,lastFungicideAt:null,lastInsecticideAt:null,lastHerbicideEfficacy:0,lastFungicideEfficacy:0,lastInsecticideEfficacy:0},technology:'minTill',id:1};
assert(ctx.treatmentEfficacy(f,'fungicide')>.6);checks++;
const noTreat=JSON.parse(JSON.stringify(f)),treated=JSON.parse(JSON.stringify(f));treated.cropProtection.lastFungicideAt=ctx.state.gameTime;treated.cropProtection.lastFungicideEfficacy=.8;const w={temp:18,precip:4,cloud:82};ctx.applyCropPressureDay(noTreat,ctx.state.gameTime,w);ctx.applyCropPressureDay(treated,ctx.state.gameTime,w);assert(treated.cropProtection.diseasePressure<noTreat.cropProtection.diseasePressure);checks++;
const pf=ctx.protectionFactor({...f,cropWeedPressure:90,cropProtection:{...f.cropProtection,diseaseDamage:.1,pestDamage:.05}},ctx.CROPS.winter_wheat);assert(Math.abs(pf-(.9*.95))<1e-9);checks++;
assert(src.includes('БАНК СЕМЯН СОРНЯКОВ')&&src.includes('ИНФЕКЦИОННЫЙ ФОН')&&src.includes('ФОН ВРЕДИТЕЛЕЙ'));checks+=3;
assert(src.includes("version:'0.11.9.74'"));checks++;
console.log(JSON.stringify({pass:true,checks,thresholds:{potatoDisease:ctx.diseaseThreshold({crop:'potato'}),cornDisease:ctx.diseaseThreshold({crop:'corn'}),rapeseedPest:ctx.pestThreshold({crop:'rapeseed'})},rotation:{monoculture:ctx.rotationSanitaryMultiplier(rot,'winter_wheat'),rotation:ctx.rotationSanitaryMultiplier(good,'winter_wheat')},diseaseAfterDay:{untreated:noTreat.cropProtection.diseasePressure,treated:treated.cropProtection.diseasePressure}},null,2));
