const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const E=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{};
const ids=['horsch_joker12rt','salford_5200_29','salford_5200_36','salford_5200_39','salford_i2100_50','salford_i2100_60','jd_2730_26','case_ecolotiger875_26','jd_2230fh_695','horsch_sprinter18nt','horsch_panther460'];
let checks=0;
for(const id of ids){const m=E.find(x=>x.id===id);assert(m,id+' missing');assert.strictEqual(m.type,'implement');assert(m.newAvailable,id+' not dealer');assert(m.requiredHp>=435,id+' not heavy');checks+=4;}
const req=ids.map(id=>E.find(x=>x.id===id).requiredHp);
assert(Math.max(...req)===720); checks++;
assert(req.filter(x=>x>=600).length>=5); checks++;
const cats=new Set(ids.map(id=>E.find(x=>x.id===id).category));
for(const c of ['disk','deepRip','cultivate','sow_grain']){assert(cats.has(c),c+' absent');checks++;}
const tractors=E.filter(x=>x.type==='tractor'&&!x.hidden);
const maxHp=t=>Math.max(t.hp||0,...(V[t.id]||[]).map(x=>x.hp||0));
const maxTractor=Math.max(...tractors.map(maxHp));assert(maxTractor>=720);checks++;
for(const m of ids.map(id=>E.find(x=>x.id===id)))assert(tractors.some(t=>maxHp(t)>=m.requiredHp),m.name+' has no tractor');
checks+=ids.length;
const rate=m=>m.width*m.speed*(m.eff||.78)/10;
const tiers=[400,500,600,720,778];
const result={};
for(const hp of tiers){result[hp]={};for(const cat of ['disk','deepRip','cultivate','sow_grain']){const ms=E.filter(m=>m.type==='implement'&&m.category===cat&&(m.requiredHp||0)<=hp);const b=ms.sort((a,b)=>rate(b)-rate(a))[0];result[hp][cat]={name:b?.name,requiredHp:b?.requiredHp,rate:+rate(b).toFixed(2)};}}
assert(result[500].disk.rate>result[400].disk.rate);checks++;
assert(result[600].deepRip.rate>result[400].deepRip.rate);checks++;
assert(result[600].sow_grain.rate>result[400].sow_grain.rate);checks++;
assert(result[720].disk.rate>result[600].disk.rate);checks++;
console.log(JSON.stringify({pass:true,checks,heavyCount:ids.length,maxTractorHp:maxTractor,powerLadder:result},null,2));
