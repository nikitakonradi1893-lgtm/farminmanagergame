'use strict';
const fs=require('fs'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
let checks=0;
for(const text of [
  "version:'0.11.9.74'",
  'function staffPayTier(skill)',
  'function staffPayTerms(worker)',
  'function staffMonthPay(e,key)',
  'function trainingOffer(worker)',
  'function startStaffTraining(id)',
  'function finishStaffTraining(w)',
  'data-train-staff',
  'Оклад:',
  'Премия:',
  'Тариф автоматически повышается каждые 5 пунктов навыка',
  'Обучать можно только штатного сотрудника или владельца'
]){assert(src.includes(text),text);checks++;}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
function pay(role,skill){const tier=clamp(Math.floor(skill/5)*5,40,95),step=(tier-75)/5,base75=role==='driver'?37000:role==='mechanic'?42000:40000,bonus75=role==='driver'?350:role==='mechanic'?420:400;return{tier,base:Math.max(30000,Math.round((base75+step*1500)/500)*500),bonus:Math.max(250,Math.round((bonus75+step*20)/10)*10)};}
let p75=pay('operator',75);assert.deepStrictEqual(p75,{tier:75,base:40000,bonus:400});checks++;
let p50=pay('operator',50),p90=pay('operator',90);assert(p50.base<p75.base&&p50.bonus<p75.bonus);checks++;assert(p90.base>p75.base&&p90.bonus>p75.bonus);checks++;
assert.strictEqual(pay('operator',74).tier,70);checks++;assert.strictEqual(pay('operator',75).tier,75);checks++;
function monthPay(role,skill,h){const t=pay(role,skill),reg=Math.min(h,168),ot=Math.max(0,h-168);return t.base+reg*t.bonus+ot*t.bonus*2;}
assert.strictEqual(monthPay('operator',75,0),40000);checks++;
assert.strictEqual(monthPay('operator',75,100),80000);checks++;
assert.strictEqual(monthPay('operator',75,180),40000+168*400+12*800);checks++;
function training(skill){if(skill>=85)return null;if(skill<55)return{gain:Math.min(5,85-skill),days:5,cost:25000};if(skill<70)return{gain:Math.min(5,85-skill),days:7,cost:45000};if(skill<80)return{gain:Math.min(5,85-skill),days:10,cost:70000};return{gain:Math.min(5,85-skill),days:14,cost:110000};}
assert.deepStrictEqual(training(50),{gain:5,days:5,cost:25000});checks++;
assert.deepStrictEqual(training(75),{gain:5,days:10,cost:70000});checks++;
assert.deepStrictEqual(training(83),{gain:2,days:14,cost:110000});checks++;
assert.strictEqual(training(85),null);checks++;
assert(src.includes("worker.contract==='permanent'&&newPayTier>oldPayTier"));checks++;
assert(!src.includes('сверх месячной нормы 168 ч оплачено'));checks++;
console.log(JSON.stringify({pass:true,checks,p75,p50,p90},null,2));
