'use strict';
const fs=require('fs'),vm=require('vm');let checks=0;function ok(x,msg){checks++;if(!x)throw new Error(msg)}
const eq=fs.readFileSync('web/equipment.js','utf8'),app=fs.readFileSync('web/app.js','utf8');const ctx={window:{}};vm.createContext(ctx);vm.runInContext(eq,ctx);const C=ctx.window.EQUIPMENT_CATALOG,by=id=>C.find(x=>x.id===id);
ok(app.includes("version:'0.11.9.74'"),'runtime version');
const trucks={kamaz45143:[15,15.4,27],kamaz65115:[15,10.7,30],kamaz6520grain:[20,20,30],maz6501grain:[19,32,32],man_tgs26:[14.5,36,36],scania_g440:[15,38,38],volvo_fm:[15,38,38],tonar6328:[21,28,28],man_tgs_agro:[20,38,38],scania_super500_grain:[24,44,44]};
for(const [id,[payload,stock,maxVol]] of Object.entries(trucks)){const m=by(id);ok(!!m,id+' exists');ok(m.capacityT===payload,id+' payload');const cfg=m.bodyConfigs||[];ok(cfg.length>0,id+' body config');const st=cfg.find(x=>x.stock)||cfg[0];ok(Math.abs(st.bodyM3-stock)<.001,id+' stock body');ok(Math.abs(Math.max(...cfg.map(x=>x.bodyM3))-maxVol)<.001,id+' max body');ok(cfg.every(x=>m.capacityT===payload),id+' boards do not alter payload');}
const trailers={gkb8527:[7,7.9,15.8],nefaz8560_old:[7,7.8,15.4],maz857100:[10.6,8.85,14.5],nefaz8560_new:[11.15,15,20]};
for(const [id,[payload,stock,maxVol]] of Object.entries(trailers)){const m=by(id);ok(m?.truckTrailer,id+' road trailer');ok(m.capacityT===payload,id+' payload');const cfg=m.bodyConfigs||[];const st=cfg.find(x=>x.stock)||cfg[0];ok(Math.abs(st.bodyM3-stock)<.001,id+' stock body');ok(Math.abs(Math.max(...cfg.map(x=>x.bodyM3))-maxVol)<.001,id+' max body');}
ok(by('nefaz8560_new').truckTrailerFor.join(',')==='kamaz45143,kamaz65115','NEFAZ modern compatibility');
ok(by('maz857100').truckTrailerFor.join(',')==='maz5551,maz6501grain','MAZ trailer compatibility');
ok(by('man_tgs_agro').name.includes('33.540'),'MAN chassis corrected');ok(by('scania_super500_grain').name.includes('8×4'),'Scania chassis corrected');
ok(app.includes('function agriculturalCargoSpec(payloadT,bodyM3,cropKey,overloadFactor=1)'),'agricultural cargo model');
ok(app.includes('maxPractical=legal*Math.max(1,Number(overloadFactor)||1)'),'practical overload cap');
ok(app.includes('overloadRatio=Math.max(0,tons/legal-1)'),'overload ratio tracked');
ok(app.includes('speedFactor=clamp(1-overloadRatio*.22,.78,1)'),'overload speed penalty');
ok(app.includes('binCapsT:[cap,tcap]'),'road train keeps truck/trailer bins separate');
ok(app.includes('const ts=assetAgriculturalCargoSpec(ta,cropKey),tcap=ts.tons,total=cap+tcap'),'road train sums practical truck/trailer crop capacities');
ok(app.includes('capacityT:total,binCapsT:[cap,tcap]'),'road train publishes practical total and separate bins');
console.log(`Truck/road-trailer capacity audit current overload model: ${checks}/${checks} PASS`);
