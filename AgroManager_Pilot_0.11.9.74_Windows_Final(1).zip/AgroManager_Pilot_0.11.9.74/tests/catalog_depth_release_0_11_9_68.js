const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const E=ctx.window.EQUIPMENT_CATALOG,by=id=>E.find(x=>x.id===id);let checks=0;const ok=(v,m)=>{assert(v,m);checks++};
ok(E.length>=840,`catalog size ${E.length}`);ok(new Set(E.map(x=>x.id)).size===E.length,'unique ids');
const addedTractors=['jd_6m140_new','jd_6m185_new','case_vestrum130_new','case_puma200_new','nh_t5140_new','nh_t6180_new','nh_t7210_swb_new','fendt_314_gen5_new','fendt_620_new','mf_5s145_new','mf_7s210_new','df_5125_new','df_6180ttv_new','valtra_g135_new','valtra_n175_new','claas_arion470_new','claas_arion570_new'];
for(const id of addedTractors){const x=by(id);ok(x&&x.type==='tractor'&&x.newAvailable,id);ok(x.series&&x.generation,`${id} series/generation`);ok(x.brand&&x.brand!=='Прочие',`${id} brand`)}
for(const brand of ['John Deere','Case IH','New Holland','Fendt','Massey Ferguson','DEUTZ-FAHR','Valtra','CLAAS']){const a=E.filter(x=>x.type==='tractor'&&x.brand===brand&&x.newAvailable&&x.hp>=120&&x.hp<=249);ok(a.length>=2,`${brand} current 120-249 depth ${a.length}`)}
for(const cat of ['plow','cultivate','disk','sow_grain','sow_row','fertilizer','sprayer']){const a=E.filter(x=>x.type==='implement'&&(x.category===cat||(x.categories||[]).includes(cat))&&(x.requiredHp||0)<=79);ok(a.length>=2,`small choice ${cat}: ${a.length}`)}
const obvious=['John Deere','CLAAS','Ростсельмаш','ПАЛЕССЕ','JCB','Case IH','New Holland','Fendt','Massey Ferguson','DEUTZ-FAHR','AMAZONE','ТОНАР','КамАЗ','ГАЗ'];
for(const x of E.filter(x=>x.brand==='Прочие'))ok(!obvious.some(k=>x.name.toLowerCase().includes(k.toLowerCase())),`obvious brand mismatch ${x.id}`);
ok(E.filter(x=>x.type==='graincart'&&!x.newAvailable).length>=3,'used grain-cart bridge');
for(const id of ['claas_evion450_new','rsm_t500_new','rsm_vector450track_new','jd_x9_1100_new']){const x=by(id);ok(x&&x.type==='combine',id);ok(Array.isArray(x.compatibleHeaderIds)&&x.compatibleHeaderIds.length>0,`${id} headers`);ok(x.grainTankM3>0,`${id} tank`)}
ok(by('rsm161').hp===400,'RSM 161 current 400 hp passport');
console.log(`catalog_depth_release_0_11_9_68: ${checks}/${checks} PASS; catalog=${E.length}`);
