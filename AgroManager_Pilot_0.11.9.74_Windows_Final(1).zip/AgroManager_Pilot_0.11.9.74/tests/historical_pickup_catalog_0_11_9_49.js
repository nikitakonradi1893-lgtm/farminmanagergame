const fs=require('fs'),vm=require('vm');
function ok(v,m){if(!v)throw new Error(m);checks++;}
let checks=0;const ctx={window:{},console};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const C=ctx.window.EQUIPMENT_CATALOG, combines=C.filter(x=>x.type==='combine'), pickups=C.filter(x=>x.type==='header'&&x.category==='pickup_grain'), M=id=>C.find(x=>x.id===id);
ok(combines.length>=57,`grain combine catalog may expand: ${combines.length}`);ok(pickups.length===11,'11 pickup platforms after historical expansion');
for(const id of ['ppt3a_legacy','pp34_legacy','jd_914p_pickup','case_1015_pickup'])ok(!!M(id),`${id} exists`);
ok(M('ppt3a_legacy').compatibleCombineIds.includes('sk5')&&M('ppt3a_legacy').compatibleCombineIds.includes('enisey1200'),'PPT-3A Niva/Enisey compatibility');
ok(M('jd_914p_pickup').compatibleCombineIds.includes('jd9500_used')&&M('jd_914p_pickup').compatibleCombineIds.includes('jd9600_used'),'JD 914P 9000-series compatibility');
ok(['case1680_used','case2188_used','case2388'].every(id=>M('case_1015_pickup').compatibleCombineIds.includes(id)),'Case 1015 legacy Axial-Flow compatibility');
for(const c of combines){ok(pickups.some(p=>p.compatibleCombineIds.includes(c.id)),`${c.name}: some pickup`);ok(pickups.some(p=>p.compatibleCombineIds.includes(c.id)&&p.segment.endsWith('_used')),`${c.name}: used pickup`);}
ok(M('pp34_legacy').compatibleCombineIds.length===combines.length,'PP-3.4 universal adapter coverage 57/57');
ok(M('pp34_legacy').price<1000000,'old universal pickup remains sub-1m entry');ok(M('ppt3a_legacy').price<M('pp34_legacy').price,'PPT-3A is cheapest old domestic entry');
console.log(JSON.stringify({pass:true,release:'0.11.9.74',checks,combines:combines.length,pickups:pickups.length,usedPickupCoverage:`${combines.filter(c=>pickups.some(p=>p.compatibleCombineIds.includes(c.id)&&p.segment.endsWith('_used'))).length}/${combines.length}`,pp34Coverage:M('pp34_legacy').compatibleCombineIds.length},null,2));
