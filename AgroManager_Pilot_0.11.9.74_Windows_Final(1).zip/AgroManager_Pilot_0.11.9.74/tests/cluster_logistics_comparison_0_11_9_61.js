const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`cl61-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__cl61={travelPlan,assignLandCluster,sameClusterDistanceKm,setAssetFieldLocation,freshState,setState(x){state=x},getState(){return state},equipmentRoadSpeed,machineRoadFuelLph,getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__cl61,E=Array.from(a.getEquip()),M=id=>{const x=E.find(v=>v.id===id);assert(x,`model ${id}`);return x};let checks=0;
assert(src.includes("version:'0.11.9.74'"));checks++;

// 1000 ha / 20 fields: 4 compact clusters × 5 fields, identical for both farms.
const clusterIds=['N','NE','E','SE'];
const distances=[14,16,18,20,22, 18,20,22,24,26, 23,25,27,29,31, 28,30,32,34,36];
const fields=Array.from({length:20},(_,i)=>({id:i+1,code:`F-${String(i+1).padStart(4,'0')}`,ha:50,owned:true,distanceKm:distances[i],clusterId:clusterIds[Math.floor(i/5)],clusterPosition:(i%5)/4,crop:'spring_wheat',soil:{}}));
const st=a.freshState('medium');st.fields=fields;st.meadows=[];a.setState(st);for(const f of fields)a.assignLandCluster(f,st.landSeed);

const models={tractor:M('mtz82'),seeder:M('imp60'),sprayer:M('imp87'),combine:M('don1500b'),header:M('don_zhu7')};
const work={
 sow:{rate:Math.max(.1,(models.seeder.fieldCapacityHaH||models.seeder.width*models.seeder.speed*(models.seeder.eff||.78)/10)),fuelLph:models.tractor.fuelLph||18,passes:1},
 spray:{rate:Math.max(.1,(models.sprayer.fieldCapacityHaH||models.sprayer.width*models.sprayer.speed*(models.sprayer.eff||.78)/10)),fuelLph:models.tractor.fuelLph||18,passes:2},
 harvest:{rate:Math.max(.1,(models.header.fieldCapacityHaH||models.header.width*models.header.speed*(models.header.eff||.78)/10)),fuelLph:models.combine.fuelLph||35,passes:1}
};
const fuelPrice=70;
function oldTravel(model,field){const speed=a.equipmentRoadSpeed(model),h=field.distanceKm/Math.max(5,speed),l=h*2*a.machineRoadFuelLph(model);return{hours:h*2,liters:l,km:field.distanceKm*2}}
function makeAsset(id,modelId){return{id,modelId,farmId:id,locationType:'base',locationFieldId:null,locationClusterId:null}}
function newRouteForOperation(modelId,fieldSequence,id){const asset=makeAsset(id,modelId);let hours=0,liters=0,km=0;for(const f of fieldSequence){const q=a.travelPlan(f,[asset]);hours+=q.roundTripH;liters+=q.liters;km+=q.distanceKm;a.setAssetFieldLocation(asset,f);} // final deliberate return to base for implement change / end of campaign
 const last=fieldSequence[fieldSequence.length-1],m=M(modelId),retH=last.distanceKm/Math.max(5,a.equipmentRoadSpeed(m)),retL=retH*a.machineRoadFuelLph(m);hours+=retH;liters+=retL;km+=last.distanceKm;asset.locationType='base';asset.locationFieldId=null;asset.locationClusterId=null;return{hours,liters,km};}
function runSeason(useClusters){let travelH=0,travelL=0,travelKm=0,workH=0,workL=0;
 // Work cluster-by-cluster; within each cluster fields ordered by clusterPosition.
 const seq=[...fields].sort((x,y)=>clusterIds.indexOf(x.clusterId)-clusterIds.indexOf(y.clusterId)||x.clusterPosition-y.clusterPosition);
 for(const [op,sp] of Object.entries(work)){
   workH+=1000/sp.rate*sp.passes;workL+=1000/sp.rate*sp.passes*sp.fuelLph;
   const modelId=op==='harvest'?'don1500b':'mtz82';
   if(useClusters){const q=newRouteForOperation(modelId,seq,`${op}-asset`);travelH+=q.hours;travelL+=q.liters;travelKm+=q.km;}
   else for(const f of seq){const q=oldTravel(M(modelId),f);travelH+=q.hours;travelL+=q.liters;travelKm+=q.km;}
 }
 return{travelH,travelL,travelKm,workH,workL,totalH:travelH+workH,totalFuel:travelL+workL,travelCost:travelL*fuelPrice};}
let A={travelH:0,travelL:0,travelKm:0,workH:0,workL:0,totalH:0,totalFuel:0,travelCost:0},B=JSON.parse(JSON.stringify(A));
for(let yr=0;yr<3;yr++){for(const [dst,src] of [[A,runSeason(false)],[B,runSeason(true)]])for(const k of Object.keys(dst))dst[k]+=src[k];}
const saving={hours:A.travelH-B.travelH,liters:A.travelL-B.travelL,km:A.travelKm-B.travelKm,rubles:A.travelCost-B.travelCost,pctHours:(A.travelH-B.travelH)/A.travelH*100,pctFuel:(A.travelL-B.travelL)/A.travelL*100};
assert(saving.hours>100,'cluster routing should save meaningful travel time over 3 seasons');checks++;
assert(saving.liters>500,'cluster routing should save meaningful diesel');checks++;
assert(B.travelH<A.travelH*.65,'cluster routing should cut travel hours substantially');checks++;
assert(B.travelKm<A.travelKm*.65,'cluster routing should cut road km substantially');checks++;
assert(fields.every(f=>f.clusterId),'all fields must have clusters');checks++;
assert(a.sameClusterDistanceKm(fields[0],fields[1])<fields[0].distanceKm+fields[1].distanceKm,'same cluster path must be shorter than via base');checks++;
console.log(JSON.stringify({pass:true,checks,setup:{areaHa:1000,fields:20,seasons:3,clusters:4,ops:['sow','spray x2','harvest']},farmA:{system:'old_base_return',...Object.fromEntries(Object.entries(A).map(([k,v])=>[k,+v.toFixed(2)]))},farmB:{system:'cluster_field_to_field',...Object.fromEntries(Object.entries(B).map(([k,v])=>[k,+v.toFixed(2)]))},saving:Object.fromEntries(Object.entries(saving).map(([k,v])=>[k,+v.toFixed(2)]))},null,2));
