const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const E=ctx.window.EQUIPMENT_CATALOG,by=id=>E.find(x=>x.id===id);let checks=0;const ok=(v,m)=>{assert(v,m);checks++};
ok(new Set(E.map(x=>x.id)).size===E.length,'unique ids');
const tractors=['jd_5100m_new','case_farmall110a_new','nh_t5110s_new','fendt_310_gen5_new','mf_5m105_new','df_5100d_keyline_new','valtra_g105_new','claas_arion420_new'];
for(const id of tractors){const x=by(id);ok(x&&x.type==='tractor'&&x.newAvailable,id);ok(x.hp>=80&&x.hp<=119,`${id} 80-119`);ok(x.series&&x.generation,`${id} metadata`);ok(x.brand&&x.brand!=='Прочие',`${id} brand`)}
for(const brand of ['John Deere','Case IH','New Holland','Fendt','Massey Ferguson','DEUTZ-FAHR','Valtra','CLAAS']){const a=E.filter(x=>x.type==='tractor'&&x.brand===brand&&x.newAvailable&&x.hp>=80&&x.hp<=119);ok(a.length>=1,`${brand} current 80-119`)}
for(const cat of ['plow','cultivate','disk','sow_grain','sow_row','fertilizer','sprayer']){const a=E.filter(x=>x.type==='implement'&&(x.category===cat||(x.categories||[]).includes(cat))&&(x.requiredHp||0)<=119);ok(a.length>=3,`<=119 choice ${cat}: ${a.length}`)}
for(const id of ['ural5557_agro','ural_next_58314s','kamaz54901_tractor','wielton_nw3_grain_used','stas_agrostar_used','stas_agrostar_new','sespel_db4u70']){const x=by(id);ok(x&&x.brand&&x.brand!=='Прочие',`${id} normalized brand`)}
const uz=by('supply_uzsa40_zil');ok(uz&&uz.brand==='УЗСА'&&uz.bodyManufacturer==='УЗСА'&&uz.chassisBrand==='ЗИЛ','upfitter/chassis split');
const gc=by('pbn16_early_used');ok(gc&&gc.type==='graincart'&&gc.segment==='domestic_used'&&!gc.newAvailable,'domestic used graincart');
ok(E.filter(x=>x.type==='graincart'&&x.segment==='domestic_used').length>=1,'domestic used graincart coverage');
const depth=fs.readFileSync('tests/catalog_depth_audit_2_0_0_11_9_68.js','utf8');ok(!depth.includes('/mnt/data/am68/'),'depth audit is portable');
console.log(`catalog_gap_closure_0_11_9_70: ${checks}/${checks} PASS; catalog=${E.length}`);
