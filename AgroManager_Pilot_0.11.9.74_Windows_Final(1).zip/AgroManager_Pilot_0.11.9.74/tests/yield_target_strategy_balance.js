const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`),end=src.indexOf(`\n${next}`,start);assert(start>=0&&end>start);return src.slice(start,end)+';'}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=n=>String(n);ctx.state={gameTime:new Date(2029,2,20).getTime()};ctx.cropStage=()=>({progress:.3});ctx.soilKnown=()=>true;ctx.roundDose=(v,step)=>Math.max(step,Math.ceil(v/step)*step);ctx.materialAvgCost=id=>({fert_nitrate:42,fert_urea:48,fert_ammophos:66,fert_npk:58,fert_potash:46,fert_lime:6500}[id]||1);ctx.fertilizerCost=(f,op,dose)=>f.ha*dose*ctx.materialAvgCost(ctx.FERTS[op].materialId);vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);vm.runInContext(constBlock('FERTS','const SOIL_TEST_COST')+'this.FERTS=FERTS;',ctx);
for(const n of ['soilBufferFactor','nutrientAvailability','seasonalNitrogenCredit','nutrientSupply','fertilizerUseEfficiency','limePhGainPerTon','targetYieldRange','yieldTargetFor','targetNutrientNeeds','limeRecoveryPlan','targetNutrientPlan'])vm.runInContext(fn(n),ctx);
function scenario(target){const f={ha:250,crop:null,yieldTargets:{winter_wheat:target},soil:{type:'Суглинок',ph:6.25,N:45,P:44,K:48,organicMatter:2.7,strawNPool:0},lastCrop:'peas',moisture:58};const p=ctx.targetNutrientPlan(f,'winter_wheat');return{target,needs:p.needs,def:p.def,cost:p.materialCost,steps:p.steps,future:p.future};}
const low=scenario(3.4),base=scenario(4.2),high=scenario(5.2);let checks=0;
assert(low.needs.N<base.needs.N&&base.needs.N<high.needs.N);checks++;
assert(low.cost<=base.cost&&base.cost<=high.cost);checks++;
assert(high.def.N>=base.def.N);checks++;
assert(high.steps.length>=base.steps.length-1);checks++;
const all=[low,base,high];for(const x of all){assert(x.cost>=0&&Number.isFinite(x.cost));checks++;assert(x.steps.every(s=>s.dose>0));checks++;}
console.log(JSON.stringify({pass:true,checks,low:{target:low.target,cost:low.cost,needs:low.needs},base:{target:base.target,cost:base.cost,needs:base.needs},high:{target:high.target,cost:high.cost,needs:high.needs},meaning:'system balance check: higher target increases nutrient demand/cost without guaranteeing yield'},null,2));
