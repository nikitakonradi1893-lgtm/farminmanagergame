const fs=require('fs'),vm=require('vm'),assert=require('assert');
const app=fs.readFileSync('web/app.js','utf8'),eq=fs.readFileSync('web/equipment.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');let checks=0;
// 1. Correct top-row hotkey map: 6 = 1 day/s, 7 = +5d, 8 = +10d.
assert(app.includes('Digit1:1,Digit2:5,Digit3:20,Digit4:60,Digit5:240,Digit6:1440'));checks++;
assert(app.includes("e.code==='Digit7'||e.code==='Digit8'"));assert(app.includes("e.code==='Digit7'?5:10"));checks+=2;
// 2. Native SELECT must be treated as active interaction so live refresh cannot destroy an open dropdown.
const ui=app.slice(app.indexOf('function uiInteractionActive'),app.indexOf('function refreshLiveUi'));assert(ui.includes("'INPUT','TEXTAREA','SELECT'"));checks++;
const globalGuard=app.slice(app.indexOf("document.addEventListener('pointerdown'"),app.indexOf('function realtimeLoop'));
assert(globalGuard.includes("e?.target?.tagName==='SELECT'"));assert(globalGuard.includes('sel.blur()'));checks+=2;
// All rendered selects inherit the global guard; ensure project still has a broad set of select controls.
const selectCount=(app.match(/<select\b/g)||[]).length;assert(selectCount>=30,`expected broad select coverage, got ${selectCount}`);checks++;
// 3. Belarus 82.1 keeps real factory configuration IDs but dealer exposes only one gameplay-equivalent engine choice.
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(eq,ctx);const vs=ctx.window.TRACTOR_ENGINE_VARIANTS.bel821;assert.strictEqual(vs.length,4);assert.strictEqual(vs.filter(v=>v.dealerSelectable!==false).length,1);checks+=2;
for(const v of vs){assert.strictEqual(v.hp,81);assert.strictEqual(v.fuelLph,12.5);}checks++;
assert(vs.slice(1).every(v=>v.dealerSelectable===false&&!v.dealerDelta));checks++;
assert(app.includes('function dealerEngineVariantsForModel'));assert(app.includes('const ev=dealerEngineVariantsForModel(m)'));checks+=2;
console.log(JSON.stringify({pass:true,checks,selectCount,belarusDealerChoices:vs.filter(v=>v.dealerSelectable!==false).map(v=>v.name)},null,2));
