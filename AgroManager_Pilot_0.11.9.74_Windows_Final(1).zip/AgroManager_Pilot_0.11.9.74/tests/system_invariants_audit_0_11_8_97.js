const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},focus(){},blur(){}}}
const elems=new Map();const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`inv-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,cancelAnimationFrame(){},window:null};ctx.window=ctx;
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');
src=src.slice(0,pos)+`\nwindow.__inv={get state(){return state},set state(v){state=v},freshState,normalize,normalizeField,normalizeAsset,refreshLandListings,reservedSaleTons,reservedWarehouseTons,warehouseFreeTons,qualifyingDeliveryLots,deliveryQualifyingTons,canStoreCropTons,storeWarehouseLot,transportPairOptions,employeeFree};\n`+src.slice(pos);
vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__inv;let checks=0;
function ok(x,msg){assert(x,msg);checks++}
function eq(x,y,msg){assert.deepStrictEqual(x,y,msg);checks++}
// 1) Save/load round-trip: a current unowned listing must preserve its economic identity and distance.
let s=a.freshState('normal'),day=Math.floor(s.gameTime/(24*3600*1000));s.landMarketRefreshDay=day;
let f=s.fields.find(x=>!x.owned&&!x.landProfile?.holdingId);assert(f);f.distanceKm=12.4;f.landProfile.marketListed=true;f.landProfile.marketMode='buy_only';f.landProfile.marketListedAt=s.gameTime-2*86400000;f.landProfile.marketExpiresAt=s.gameTime+20*86400000;
const fieldBefore={id:f.id,distanceKm:f.distanceKm,mode:f.landProfile.marketMode,listedAt:f.landProfile.marketListedAt,expiresAt:f.landProfile.marketExpiresAt};
let n=a.normalize(JSON.parse(JSON.stringify(s)));let nf=n.fields.find(x=>x.id===f.id);eq({id:nf.id,distanceKm:nf.distanceKm,mode:nf.landProfile.marketMode,listedAt:nf.landProfile.marketListedAt,expiresAt:nf.landProfile.marketExpiresAt},fieldBefore,'market field changed across normalize');
eq(n.landMarketRefreshDay,day,'landMarketRefreshDay must persist');
// Same-day refresh after load must be idempotent.
a.state=n;const listedBefore=n.fields.filter(x=>x.landProfile?.marketListed).map(x=>x.id).sort((x,y)=>x-y);a.refreshLandListings(n.gameTime,false);const listedAfter=n.fields.filter(x=>x.landProfile?.marketListed).map(x=>x.id).sort((x,y)=>x-y);eq(listedAfter,listedBefore,'same-day land refresh changed listings');
// Null listing timestamps remain null, not Unix epoch zero.
let g=s.fields.find(x=>x.id!==f.id&&!x.owned);g.landProfile.marketListed=false;g.landProfile.marketListedAt=null;g.landProfile.marketExpiresAt=null;n=a.normalize(JSON.parse(JSON.stringify(s)));g=n.fields.find(x=>x.id===g.id);eq(g.landProfile.marketListedAt,null,'null marketListedAt became numeric');eq(g.landProfile.marketExpiresAt,null,'null marketExpiresAt became numeric');
// Legacy crop history fallback must not invent year 1970 from null harvest date.
let probe=JSON.parse(JSON.stringify(s.fields[0]));probe.cropHistory=null;probe.lastCrop='spring_wheat';probe.lastHarvest=null;let pn=a.normalizeField(probe,0,probe);ok(Array.isArray(pn.cropHistory)&&pn.cropHistory.length===1,'cropHistory fallback missing');eq(pn.cropHistory[0].year,null,'null lastHarvest became 1970');
// Nullable agronomic timestamps must stay absent; zero is a real timestamp and can fake treatment history.
probe.phytosanitary={lastUpdatedAt:null};probe.cropProtection={lastHerbicideAt:null,lastFungicideAt:null,lastInsecticideAt:null};pn=a.normalizeField(probe,0,probe);eq(pn.phytosanitary.lastUpdatedAt,null,'null phytosanitary lastUpdatedAt became 0');eq(pn.cropProtection.lastHerbicideAt,null,'null lastHerbicideAt became 0');eq(pn.cropProtection.lastFungicideAt,null,'null lastFungicideAt became 0');eq(pn.cropProtection.lastInsecticideAt,null,'null lastInsecticideAt became 0');
// Rich agronomic state survives normalize.
probe={...probe,owned:true,plannedCrop:'spring_wheat',seedQualityFactor:.93,seedSourceLabel:'Фермерские',sowingEquipmentFactor:.82,trafficFactor:.91,sowSpatialSummary:{meanAt:123,zones:[{id:'A',share:.5}]},fertilizerSpatial:{cv:.12},limeSpatial:{cv:.08},seasonYieldTarget:4.0,distanceKm:59.2};pn=a.normalizeField(probe,0,probe);eq(pn.plannedCrop,'spring_wheat');eq(pn.seedQualityFactor,.93);eq(pn.sowingEquipmentFactor,.82);eq(pn.trafficFactor,.91);eq(pn.seasonYieldTarget,4);eq(pn.distanceKm,59.2);ok(pn.sowSpatialSummary&&pn.fertilizerSpatial&&pn.limeSpatial,'spatial agronomy lost');
// Nullable repair location must survive round-trip as null, not synthetic field id 0.
const assetProbe=a.normalizeAsset({id:'A0',modelId:'gaz53',condition:90,hours:100,breakdownFieldId:null,storage:'yard',systems:{}},0);eq(assetProbe.breakdownFieldId,null,'null breakdownFieldId became 0');
// 2) Shared warehouse reservation invariant: scheduled normal sales block other consumers.
a.state={warehouse:{stocks:{spring_wheat:100},salesTransit:[{crop:'spring_wheat',status:'scheduled',tons:70}],lots:[{id:'L',crop:'spring_wheat',tons:100,moisture:13,quality:{score:85}}]},tasks:[],infrastructure:{grainLevel:0,vegetableLevel:0,hayLevel:0},deliveryContracts:{active:[]}};
eq(a.warehouseFreeTons('spring_wheat'),30,'scheduled sale reservation not subtracted');eq(a.deliveryQualifyingTons({crop:'spring_wheat',minQuality:0,maxMoisture:null}),30,'delivery contract ignored sale reservation');
// Storage itself is the final capacity guard.
a.state={warehouse:{stocks:{hay:145},lots:[],salesTransit:[]},tasks:[],infrastructure:{hayLevel:0,grainLevel:0,vegetableLevel:0}};eq(a.canStoreCropTons('hay',6),false,'hay capacity guard failed');
// 3) Machine/person exclusivity: busy resources must disappear from available pools.
s=a.freshState('normal');a.state=s;s.equipment.fleet=[{id:'TR1',farmId:'TR1',modelId:'gaz53',busyUntil:s.gameTime+3600000,repairReason:null,condition:90,systems:{engine:90,transmission:90,running:90,hydraulics:90},hours:100,storage:'yard'}];eq(a.transportPairOptions().length,0,'busy truck offered to second process');
s.staff.owner.busyUntil=s.gameTime+3600000;eq(a.employeeFree(s.staff.owner),false,'busy worker reported free');
// 4) Current version marker is aligned with release under test.
ok(src.includes("version:'0.11.9.74'"),'version marker not 0.11.9.09');
console.log(JSON.stringify({pass:true,checks},null,2));
