const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const ctx={Math,Number};vm.createContext(ctx);
for(const n of ['yieldFactorGroup','yieldFactorMode','yieldWaterfall','yieldGroupSummary','normalizedYieldReport'])vm.runInContext(fn(n),ctx);
let checks=0;
const factors=[
 {key:'sow',label:'sow',value:.95},
 {key:'weather',label:'weather',value:.9},
 {key:'nutrition',label:'nutrition',value:1.02},
 {key:'protection',label:'protection',value:.92},
 {key:'harvest',label:'harvest',value:.97}
];
const steps=ctx.yieldWaterfall(4.2,factors);
const expected=4.2*.95*.9*1.02*.92*.97;
assert(Math.abs(steps.at(-1).afterYield-expected)<1e-12);checks++;
assert(Math.abs(4.2+steps.reduce((a,x)=>a+x.deltaYield,0)-expected)<1e-12);checks++;
assert.strictEqual(steps[0].mode,'fixed');checks++;
assert.strictEqual(steps[1].mode,'live');checks++;
assert.strictEqual(steps[2].group,'Питание и pH');checks++;
const groups=ctx.yieldGroupSummary(steps);assert(groups.length===5);checks++;
const a=ctx.normalizedYieldReport({baseYield:4.2,targetYield:5,factors});
const b=ctx.normalizedYieldReport({baseYield:4.2,targetYield:3.5,factors});
assert(Math.abs(a.yieldPerHa-b.yieldPerHa)<1e-12);checks++;
assert(a.targetRatio<b.targetRatio);checks++;
assert(Math.abs(a.yieldPerHa-expected)<1e-12);checks++;
for(const text of ['Формула прозрачна','Δ т/га','После фактора','Никаких дополнительных скрытых коэффициентов','СЕЗОННАЯ ЦЕЛЬ','yieldWaterfall',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
assert(src.includes('targetYield=yieldTargetFor(f,f.crop)'));checks++;
console.log(JSON.stringify({pass:true,checks,base:4.2,expected:+expected.toFixed(6),steps:steps.map(x=>({key:x.key,coef:x.value,delta:+x.deltaYield.toFixed(4),after:+x.afterYield.toFixed(4),group:x.group,mode:x.mode})),groups},null,2));
