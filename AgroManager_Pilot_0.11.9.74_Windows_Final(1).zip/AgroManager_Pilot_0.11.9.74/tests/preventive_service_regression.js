const assert=require('assert');
const fs=require('fs'), path=require('path');
global.window={};require('../web/equipment.js');
const E=window.EQUIPMENT_CATALOG, by=id=>E.find(x=>x.id===id), clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const BASE={engine:400,transmission:600,running:500,hydraulics:450,tires:300,tracks:350,working:180,metering:220,drive:260,frame:650};
function tech(m){const y=Number(m?.years?.[0])||1980;if(m?.segment==='domestic_used')return'legacy';if(m?.segment==='foreign_new'||(m?.segment==='domestic_new'&&y>=2012))return'modern';if(m?.segment==='foreign_used'&&y>=2008)return'modern';return'mechanical'}
function interval(m,k){const mult=tech(m)==='legacy'?.82:tech(m)==='modern'?1.18:1;return Math.max(100,Math.round((BASE[k]||400)*mult/25)*25)}
function pf(used,int){if(used>=int)return 1;if(used<=int*.35)return .82;if(used<=int*.70)return .88;return .94}
function risk({h,cond,ov=0,svc=0,stress=1,reliability=.9,pfct=1}){let pct=.025;pct+=Math.min(.36,Math.max(0,h-2500)/1000*.026);pct+=Math.max(0,70-cond)*.010;pct+=ov*.095;pct+=Math.min(.14,svc*.009);pct+=Math.max(0,stress-1)*.55;return clamp(pct*pfct/Math.max(.72,reliability),.01,2.5)}
const k700=by('k700'),fendt=by('fendt942');assert(k700&&fendt);
assert(interval(k700,'engine')<interval(fendt,'engine'),'legacy maintenance interval should be shorter');
assert(interval(k700,'working')>=100);
const base=risk({h:10000,cond:68,ov:1,svc:8,pfct:1}), recent=risk({h:10000,cond:68,ov:1,svc:8,pfct:.82});
assert(recent<base&&recent/base>.75,'preventive service must reduce risk modestly, not erase age risk');
assert(pf(0,400)===.82&&pf(400,400)===1);
function contractQuote(value,count,foreign=true){const base=foreign?280000:160000;return Math.max(base,Math.round((base+value*.0035+count*25000)/10000)*10000)}
const one=contractQuote(18_000_000,1,true), fleet=contractQuote(120_000_000,6,true);assert(fleet>one);assert(one>=280000);
const src=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8');
for(const n of ['preventiveInterval','preventiveDueInfo','diagnosticForecast','startPreseasonDiagnostic','startPrepareForSeason','brandContractQuote','buyServiceContract','spareRiskAnalytics'])assert(src.includes(`function ${n}`),n);
assert(src.includes("serviceContracts:{}"));
assert(src.includes("data-season-prepare"));
assert(src.includes("Рекомендованный страховой запас"));
assert(src.includes("договор"));
console.log(JSON.stringify({pass:true,checks:18,intervals:{k700Engine:interval(k700,'engine'),fendtEngine:interval(fendt,'engine')},riskExample:{without:+base.toFixed(3),recentPreventive:+recent.toFixed(3)},contractExamples:{one,fleet}},null,2));
