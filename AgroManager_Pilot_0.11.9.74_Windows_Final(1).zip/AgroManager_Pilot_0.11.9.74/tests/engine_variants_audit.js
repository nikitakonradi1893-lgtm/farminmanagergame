const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const C=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{};
const tractors=C.filter(x=>x.type==='tractor'&&!x.hidden);
assert(tractors.length>=118,`catalog tractor count may expand, got ${tractors.length}`);assert.strictEqual(new Set(tractors.map(x=>x.id)).size,tractors.length,'tractor ids unique');
let variable=0,checks=0;
for(const m of tractors){
 const vs=V[m.id]||[];
 if(vs.length>=2){
  variable++;
  assert(vs.length>=2,`${m.id}: variant-enabled model needs >=2 variants`);checks++;
  assert.strictEqual(vs.filter(x=>x.stock).length,1,`${m.id}: exactly one stock engine`);checks++;
  assert(new Set(vs.map(x=>x.id)).size===vs.length,`${m.id}: engine IDs unique`);checks++;
  for(const e of vs){assert(e.hp>0&&e.fuelLph>0&&e.swapCost>0&&e.swapHours>=12,`${m.id}/${e.id}: valid figures`);checks++;}
  const st=vs.find(x=>x.stock);assert.strictEqual(st.hp,m.hp,`${m.id}: stock hp equals catalog hp`);checks++;
 }
}
assert(variable>=54,'audited models with meaningful variants');checks++;
const k=V.k700;assert.strictEqual(k.length,13,'K-700 engine count');checks++;
const k220=k.find(x=>x.hp===220),k400=k.find(x=>x.id==='yamz7511_400'),k500=k.find(x=>x.hp===500);
assert(k220&&k400&&k500);checks++;
assert(k400.fuelLph>k220.fuelLph&&k500.fuelLph>k400.fuelLph,'K-700 full-load fuel scales with power');checks++;
assert(k400.swapCost<13750000,'K-700 400 hp repower is cheaper than a new K-7M 350');checks++;
assert(k500.swapCost>k400.swapCost,'extreme custom swap costs more');checks++;
for(const id of ['k7m350','k7m420']){const vs=V[id];assert(vs.some(x=>x.dealerExtraDays>0),`${id}: dealer alternate adds lead time`);checks++;assert(vs.some(x=>x.dealerDelta>0),`${id}: dealer alternate changes price`);checks++;}
// Mirror the production fuel rule to catch accidental equality under a light implement.
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const loadFactor=(requiredHp,tractorHp)=>{const load=clamp(requiredHp/Math.max(1,tractorHp),.18,1.15);return clamp(.18+.82*Math.pow(load,.72),.3,1.08)};
const fuel=(e,req)=>{const reserve=Math.max(0,e.hp/req-1),oversize=1+Math.min(.16,reserve*.09);return e.fuelLph*loadFactor(req,e.hp)*oversize};
const f220=fuel(k220,220),f400=fuel(k400,220);assert(f400>f220,`400 hp K-700 should not burn exactly the same as stock on 220-hp work (${f220} vs ${f400})`);checks++;
// Visible mechanical trade-off formula used by app.js.
const stress=(hp,rated)=>Math.min(1.45,1+Math.max(0,hp/rated-1)*.48);
assert(stress(400,260)>1.2&&stress(500,260)<=1.45,'stock K-700 transmission stress rises but is capped');checks++;
console.log(JSON.stringify({pass:true,tractors:tractors.length,variantModels:variable,fixedModels:tractors.length-variable,k700Variants:k.length,checks,k700Fuel220HpWork:{stock220:+f220.toFixed(2),yamz7511_400:+f400.toFixed(2)},k700TransmissionWear400:+stress(400,260).toFixed(3),k700TransmissionWear500:+stress(500,260).toFixed(3)},null,2));
