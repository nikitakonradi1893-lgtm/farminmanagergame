const fs=require('fs'),vm=require('vm');
function el(inContent=false){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(sel){return inContent&&sel==='#content'?{}:null},getBoundingClientRect(){return{top:0,bottom:20}},blur(){}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`aud-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__a={EQUIP,makeUsedListing,modelCanBeUsed,dealerModelAvailable,dealerPrice,dealerEngineSpec,dealerTireSpec,dealerTrackSpec,dealerBodySpec,bodyConfigsForModel,engineVariantsForModel,tireVariantsForModel,trackVariantsForModel,engineSpecById,tireSpecById,trackSpecById,bodyConfigById};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__a, now=new Date(2026,8,28,8).getTime();
const candidates=a.EQUIP.filter(m=>a.dealerModelAvailable(m,now)&&a.modelCanBeUsed(m,now));
let violations=[],eqViolations=[],configuredAboveBase=[],stats=[];
for(const m of candidates){
 const baseDealer=a.dealerPrice(m,a.dealerEngineSpec(m),a.dealerTireSpec(m),a.dealerTrackSpec(m),a.dealerBodySpec(m));
 let max=0,maxL=null,min=Infinity,sum=0;
 for(let i=0;i<600;i++){
   const l=a.makeUsedListing((0x9e3779b9+i*2654435761)>>>0,i%181,m,now);
   const ratio=l.price/baseDealer; sum+=ratio;if(ratio>max){max=ratio;maxL=l}if(ratio<min)min=ratio;
   if(l.price>=baseDealer){ const ee=l.engineId?a.engineSpecById(m,l.engineId):a.dealerEngineSpec(m), tt=l.tireId?a.tireSpecById(m,l.tireId):a.dealerTireSpec(m), tr=l.trackId?a.trackSpecById(m,l.trackId):a.dealerTrackSpec(m), bb=l.bodyConfigId?a.bodyConfigById(m,l.bodyConfigId):a.dealerBodySpec(m); const eqNew=a.dealerPrice(m,ee,tt,tr,bb); {const rec={id:m.id,name:m.name,newPrice:baseDealer,equivalentNewPrice:eqNew,usedPrice:l.price,ratio,eqRatio:l.price/eqNew,year:l.year,condition:l.trueCondition,engineId:l.engineId,bodyConfigId:l.bodyConfigId,tireId:l.tireId,trackId:l.trackId}; violations.push(rec); if(l.price>=eqNew) eqViolations.push(rec);} }
   if(l.readyEquivalentPrice>baseDealer) configuredAboveBase.push({id:m.id,name:m.name,newPrice:baseDealer,ready:l.readyEquivalentPrice,usedPrice:l.price,ratioReady:l.readyEquivalentPrice/baseDealer,engineId:l.engineId,bodyConfigId:l.bodyConfigId,tireId:l.tireId,trackId:l.trackId});
 }
 stats.push({id:m.id,name:m.name,newPrice:baseDealer,maxRatio:max,minRatio:min,avgRatio:sum/600,maxUsed:maxL?.price,maxYear:maxL?.year,maxCondition:maxL?.trueCondition,maxEngine:maxL?.engineId,maxBody:maxL?.bodyConfigId});
}
const byModel=[...new Map(violations.sort((x,y)=>y.ratio-x.ratio).map(x=>[x.id,x])).values()]; const eqByModel=[...new Map(eqViolations.sort((x,y)=>y.eqRatio-x.eqRatio).map(x=>[x.id,x])).values()];
const configByModel=[...new Map(configuredAboveBase.sort((x,y)=>y.ratioReady-x.ratioReady).map(x=>[x.id,x])).values()];
console.log(JSON.stringify({candidateModels:candidates.length,samples:candidates.length*600,violationCount:violations.length,violationModels:byModel.length,violations:byModel.slice(0,100),equivalentViolationCount:eqViolations.length,equivalentViolationModels:eqByModel.length,equivalentViolations:eqByModel.slice(0,100),configuredAboveBaseModels:configByModel.length,configuredAboveBase:configByModel.slice(0,100),topRatios:stats.sort((a,b)=>b.maxRatio-a.maxRatio).slice(0,30)},null,2));

if(eqViolations.length){console.error('USED_NEW_PARITY_FAIL',eqViolations.slice(0,10));process.exitCode=1}else console.log(`Used/new price parity 0.11.9.74: ${candidates.length} models, ${candidates.length*600} listings, 0 equivalent-price inversions PASS`);
