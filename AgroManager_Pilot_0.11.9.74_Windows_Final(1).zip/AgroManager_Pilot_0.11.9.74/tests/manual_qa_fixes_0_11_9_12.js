const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`qa12-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__qa12={get state(){return state},set state(v){state=v},freshState,updateContractWorkProgress,contractProgressPct,processContracts,processContractShiftEvents,contractShiftStateAt,modelMatchesFilters,compatibilityHtml,equipmentModel,setCategory(v){equipmentCategory=v},getEquip(){return EQUIP}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__qa12;let checks=0;
assert(src.includes("version:'0.11.9.74'"));checks++;
// Fields page must not be replaced every 250 ms; this was the scroll/hover flicker source.
const liveLine=src.match(/else if\(\[([^\]]*)\]\.includes\(page\)&&!interactiveActive\)renderPreservingViewport\(\);/)?.[1]||'';
assert(!liveLine.includes("'fields'")&&!liveLine.includes("'meadows'"));checks++;
// Every truck has a physical body volume; used market falls back to base body if no body-kit variant exists.
const trucks=Array.from(a.getEquip()).filter(m=>m.type==='truck');assert(trucks.length>=10);checks++;
assert(trucks.every(m=>Number(m.bodyM3)>0),trucks.filter(m=>!(Number(m.bodyM3)>0)).map(m=>m.id).join(','));checks++;
assert(src.includes('listingBodySpec(l)?.bodyM3||m.bodyM3'));checks++;
// Road truck trailers are a separate market category from tractor trailers.
a.setCategory('roadTrailer');const road=Array.from(a.getEquip()).filter(m=>a.modelMatchesFilters(m));assert(road.length>=4&&road.every(m=>m.type==='trailer'&&m.truckTrailer));checks++;
a.setCategory('trailer');const tractorTrailers=Array.from(a.getEquip()).filter(m=>a.modelMatchesFilters(m));assert(tractorTrailers.length>0&&tractorTrailers.every(m=>m.type==='trailer'&&!m.truckTrailer));checks++;
assert(road.every(m=>Array.isArray(m.truckTrailerFor)&&m.truckTrailerFor.length>0));checks++;
assert(road.every(m=>a.compatibilityHtml(m).includes('Автопоезд:')&&m.truckTrailerFor.some(id=>a.compatibilityHtml(m).includes(a.equipmentModel(id).name))));checks++;
// Contract work progress only advances during actual work, not owner rest/weather pauses.
a.state=a.freshState('very_hard');const now=a.state.gameTime;
const c={id:'C-QA12',op:'sow',cropKey:'peas',ha:20,reward:100000,status:'working',deadline:now+48*3600000,startedAt:now,end:now+26*3600000,returnEnd:now+27*3600000,travel:{outboundH:0,returnH:1,roundTripH:1},shiftHours:8,workGroups:[{id:'g',assetIds:[],rate:2.5,breakdownAssetIds:[],activeHours:0}],remainingWorkHa:20,workProgressAt:now,assetActiveHours:{},machineAssetIds:[],workerIds:[],machineHours:8};
a.state.contracts.active=[c];a.updateContractWorkProgress(c,now+8*3600000);assert(Math.abs(c.remainingWorkHa-0)<1e-6);checks++;
// A completed physical workload must complete immediately even if old scheduled end is later.
a.state.gameTime=now+8*3600000;a.processContracts();assert(a.state.contracts.history.some(x=>x.id==='C-QA12'&&x.status==='completed'));checks++;
const c2={...c,id:'C-PAUSE',status:'working',finishedAt:null,end:now+30*3600000,returnEnd:now+31*3600000,remainingWorkHa:20,workProgressAt:now,assetActiveHours:{},workGroups:[{id:'g2',assetIds:[],rate:1,breakdownAssetIds:[],activeHours:0}],deadline:now+48*3600000};a.state.contracts.active=[c2];
a.updateContractWorkProgress(c2,now+4*3600000);assert(Math.abs(c2.remainingWorkHa-16)<1e-6);checks++;
c2.shiftPausedAt=now+4*3600000;a.updateContractWorkProgress(c2,now+12*3600000);assert(Math.abs(c2.remainingWorkHa-16)<1e-6);checks++;
c2.shiftPausedAt=null;c2.workProgressAt=now+12*3600000;c2.weatherPausedAt=now+12*3600000;a.updateContractWorkProgress(c2,now+16*3600000);assert(Math.abs(c2.remainingWorkHa-16)<1e-6);checks++;
assert(src.includes('nextContractWeatherEventTime')&&src.includes('processContractWeatherEvents')&&src.includes('nextContractShiftEventTime')&&src.includes('processContractShiftEvents'));checks++;

// Owner/8h shift: after 8 active hours, progress pauses through the 16h rest and resumes next shift.
const c3={...c2,id:'C-SHIFT-EVENT',status:'working',remainingWorkHa:20,workProgressAt:now,end:now+32*3600000,returnEnd:now+33*3600000,shiftHours:8,shiftPausedAt:null,weatherPausedAt:null,breakdownPausedAt:null,workGroups:[{id:'g3',assetIds:[],rate:1,breakdownAssetIds:[],activeHours:0}]};
a.state.contracts.active=[c3];
a.state.gameTime=now+8*3600000;a.processContractShiftEvents(now+8*3600000);assert(c3.shiftPausedAt===now+8*3600000);assert(Math.abs(c3.remainingWorkHa-12)<1e-6);checks++;
a.updateContractWorkProgress(c3,now+23*3600000);assert(Math.abs(c3.remainingWorkHa-12)<1e-6);checks++;
a.state.gameTime=now+24*3600000;a.processContractShiftEvents(now+24*3600000);assert(c3.shiftPausedAt===null);a.updateContractWorkProgress(c3,now+28*3600000);assert(Math.abs(c3.remainingWorkHa-8)<1e-6);checks++;

console.log(JSON.stringify({pass:true,checks,trucks:trucks.length,roadTrailers:road.length,tractorTrailers:tractorTrailers.length},null,2));
