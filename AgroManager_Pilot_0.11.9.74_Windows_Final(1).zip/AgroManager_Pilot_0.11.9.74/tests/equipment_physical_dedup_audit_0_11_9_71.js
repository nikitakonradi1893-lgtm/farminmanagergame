#!/usr/bin/env node
'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const target=process.argv[2]||path.join(process.cwd(),'web','equipment.js');
const code=fs.readFileSync(target,'utf8');
const sandbox={window:{},console};vm.createContext(sandbox);vm.runInContext(code,sandbox);
const C=sandbox.window.EQUIPMENT_CATALOG||[];
const norm=s=>String(s||'').toLowerCase().replace(/ё/g,'е').replace(/[–—−]/g,'-').replace(/\s+/g,' ').trim();
const canonical=s=>norm(s)
  .replace(/\s*\((?:б\/у|бу|used|новый|new)\)\s*/g,' ')
  .replace(/\s*[·•]\s*(?:б\/у|used|новый|new)\b/g,' ')
  .replace(/\b(?:б\/у|used)\b/g,' ')
  .replace(/\s+/g,' ').trim().replace(/^[-· ]+|[-· ]+$/g,'');
let pass=0,fail=0,warn=0;
const P=(ok,msg)=>{if(ok){pass++;}else{fail++;console.log('FAIL',msg)}};
const W=(msg)=>{warn++;console.log('WARN',msg)};
const ids=new Set();
for(const x of C){P(!ids.has(x.id),`duplicate id ${x.id}`);ids.add(x.id);}
const groups=new Map();
for(const x of C){const k=`${x.type}|${canonical(x.name)}`;if(!groups.has(k))groups.set(k,[]);groups.get(k).push(x);}
for(const g of groups.values())if(g.length>1)W(`physical-name duplicate: ${g.map(x=>`${x.id}:${x.name}`).join(' | ')}`);
const imp41=C.find(x=>x.id==='imp41'), imp43=C.find(x=>x.id==='imp43');
if(imp41&&Array.isArray(imp41.categories)&&imp41.categories.includes('cultivate')&&imp41.name.includes('Karat'))
  W(`stale multi-role target: imp41=${imp41.name} categories=${imp41.categories.join(',')}`);
if(imp43&&imp43.name==='КПС-4'&&!Array.isArray(imp43.categories))
  W('КПС-4 imp43 lacks multi-role categories');
for(const x of C.filter(x=>Array.isArray(x.categories))){
  if(!x.categories.includes(x.category) && x.id!=='imp41') W(`categories omit primary category ${x.id} ${x.name}`);
}
const baseRole=[['2ПТС-4',['2pts4','hay_2pts4','hay_2pts4_old']],['2ПТС-6',['2pts6','hay_2pts6_old']]];
for(const [model,list] of baseRole){const found=list.map(id=>C.find(x=>x.id===id)).filter(Boolean);if(found.length>1)W(`role duplicate ${model}: ${found.map(x=>x.id).join(', ')}`);}
console.log(`SUMMARY records=${C.length} pass=${pass} fail=${fail} warn=${warn}`);
process.exitCode=fail?1:0;
