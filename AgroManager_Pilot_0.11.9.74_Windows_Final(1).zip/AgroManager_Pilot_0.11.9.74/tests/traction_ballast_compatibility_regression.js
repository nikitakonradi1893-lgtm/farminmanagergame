const assert=require('assert');
global.window={};require('../web/equipment.js');const E=window.EQUIPMENT_CATALOG,EV=window.TRACTOR_ENGINE_VARIANTS;
const by=id=>E.find(x=>x.id===id);const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const ballast={none:{massFactor:0,traction:1,soilPressure:1,fuel:1},standard:{massFactor:.08,traction:1.035,soilPressure:1.035,fuel:1.01},heavy:{massFactor:.16,traction:1.07,soilPressure:1.075,fuel:1.025}};
function maxHp(m){const v=(EV[m.id]||[]);return v.length?Math.max(...v.map(x=>x.hp)):m.hp}
function baseMass(m){const hp=Math.max(40,+m.hp||100);let t=hp<=80?3.8:hp<=120?4.8:hp<=180?6.7:hp<=250?9.2:hp<=330?12.2:hp<=430?15.5:hp<=520?18.5:hp<=650?23.5:28;if(m.driveType==='tracked')t*=1.10;else if(m.driveType==='halftrack')t*=1.06;return t}
function tractionMob(m,kind='stock'){if(m.driveType==='tracked')return kind==='wide'?1.24:1.20;if(m.driveType==='halftrack')return kind==='wide'?1.20:1.16;return kind==='wide'?1.08:kind==='dual'?1.15:1}
function wet(moist){return moist<=52?1.04:moist<=62?1:moist<=70?1-(moist-62)*.018:clamp(1-(8*.018)-(moist-70)*.027,.55,1.08)}
function draft(im){const c=im.category;if(['deepRip','plow'].includes(c))return 1;if(['disk','stubble'].includes(c))return .82;if(c==='cultivate')return .72;if(['harrow','ridge'].includes(c))return .60;if(['sow_grain','sow_row','sow_potato'].includes(c))return .56;if(['mower','baler'].includes(c))return .50;return .46}
function calc(m,im,hp,moist=58,b='standard',mob='stock'){const mass=baseMass(m)*(1+ballast[b].massFactor),avail=mass*tractionMob(m,mob)*ballast[b].traction*wet(moist),req=im.requiredHp*.036*draft(im),ratio=avail/req,nom=m.driveType==='tracked'?5:m.driveType==='halftrack'?6:8,slip=clamp(nom+Math.max(0,1-ratio)*31+Math.max(0,1-wet(moist))*12,nom,30),rate=clamp(1-Math.max(0,slip-5)*.007,.68,1),fuel=clamp((1)*(1+Math.max(0,slip-5)*.009)*ballast[b].fuel,.92,1.38);return{mass,avail,req,ratio,slip,rate,fuel,pressure:ballast[b].soilPressure}}
const k700=by('k700'),t8=by('nh_t8435'),quad=by('case_quadtrac715'),ripper=by('case_ecolotiger875_26'),sprinter=by('horsch_sprinter18nt'),cruiser=by('horsch_cruiser12xl');
assert(k700&&t8&&quad&&ripper&&sprinter&&cruiser);
assert.strictEqual(maxHp(k700),500);
// Repower does not magically add chassis mass.
assert(baseMass(k700)<11,'K-700 chassis mass proxy should stay old-chassis class even with 500 hp engine');
// 500 hp K-700 cannot run a 600 hp implement by power alone.
assert(maxHp(k700)<ripper.requiredHp);
const kStd=calc(k700,cruiser,500,68,'standard','stock'),kHeavy=calc(k700,cruiser,500,68,'heavy','stock');
assert(kHeavy.ratio>kStd.ratio);assert(kHeavy.slip<kStd.slip);assert(kHeavy.fuel>=kStd.fuel*.98);assert(kHeavy.pressure>kStd.pressure);
const tWheel=calc(t8,sprinter,maxHp(t8),72,'standard','stock'),tWide=calc({...t8,driveType:'halftrack'},sprinter,maxHp(t8),72,'standard','wide');
assert(tWide.ratio>tWheel.ratio);assert(tWide.slip<tWheel.slip);assert(tWide.rate>=tWheel.rate);
const qWet=calc(quad,ripper,maxHp(quad),74,'standard','wide'),qDry=calc(quad,ripper,maxHp(quad),55,'standard','wide');
assert(qWet.slip>qDry.slip);assert(qWet.rate<qDry.rate);assert(qWet.fuel>qDry.fuel);
// Heavy tractors should have enough nominal drawbar ability for heavy implements on workable soil.
assert(qWet.ratio>.66);
const src=require('fs').readFileSync(require('path').join(__dirname,'../web/app.js'),'utf8');
for(const name of ['tractorImplementCompatibility','unitTractionDynamics','implementRequirementSpec','ballastControlsHtml'])assert(src.includes(`function ${name}`));
console.log(JSON.stringify({pass:true,checks:15,scenarios:{k700Standard:{ratio:+kStd.ratio.toFixed(2),slipPct:+kStd.slip.toFixed(1),rate:+kStd.rate.toFixed(3),fuel:+kStd.fuel.toFixed(3)},k700Heavy:{ratio:+kHeavy.ratio.toFixed(2),slipPct:+kHeavy.slip.toFixed(1),rate:+kHeavy.rate.toFixed(3),fuel:+kHeavy.fuel.toFixed(3)},t8WheelWet:{ratio:+tWheel.ratio.toFixed(2),slipPct:+tWheel.slip.toFixed(1)},t8SmartTraxWet:{ratio:+tWide.ratio.toFixed(2),slipPct:+tWide.slip.toFixed(1)},quadWet:{ratio:+qWet.ratio.toFixed(2),slipPct:+qWet.slip.toFixed(1)}},meaning:'Мощность больше не гарантирует полевую производительность: сцепная масса, балласт, ходовая и влажность меняют буксование; repower старого шасси не создаёт массу.'},null,2));
