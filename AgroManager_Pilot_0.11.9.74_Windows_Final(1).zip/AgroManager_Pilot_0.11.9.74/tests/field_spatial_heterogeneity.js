const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.dayStart=ms=>{const d=new Date(ms);return new Date(d.getFullYear(),d.getMonth(),d.getDate()).getTime()};ctx.daysBetween=(a,b)=>Math.floor((ctx.dayStart(b)-ctx.dayStart(a))/ctx.DAY);ctx.dateFor=(y,m,d)=>new Date(y,m-1,d,8).getTime();ctx.rngFactory=seed=>{let a=(seed>>>0)||1;return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296;}};ctx.hashString=s=>{let h=2166136261>>>0;for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}return h>>>0;};ctx.state={gameTime:new Date(2028,4,20,8).getTime()};vm.createContext(ctx);
ctx.nutrientSupply=()=>({N:62,P:44,K:44});ctx.CROPS={x:{baseYield:3.2,needs:{N:70,P:50,K:45},group:'cereal'}};ctx.yieldTargetFor=()=>3.2;ctx.targetNutrientNeeds=()=>({N:70,P:50,K:45});for(const n of ['seasonalWindow','sowTimingFactor','sowSegmentTimingFactor','fieldSpatialZones','taskSpatialSlices','summarizeSowingProgress','effectiveSowTimingFactor','fertilizerSpatialProfile','factorFromNutrientAmounts','spatialNutritionAdjustment'])vm.runInContext(fn(n),ctx);
let checks=0;
const crop={sow:{start:[4,1],optimalStart:[4,10],optimalEnd:[5,5],end:[5,20]}};
const end=ctx.seasonalWindow(crop.sow,2028).end,start=end-48*3600000,finish=start+63*3600000;
const t={start,end:finish,fieldHa:63,spatialProgress:[{from:start,to:finish,ha:63}]};
const sum=ctx.summarizeSowingProgress(t,crop);const late=sum.zones.find(z=>z.label==='После окна');const inside=sum.zones.filter(z=>z.label!=='После окна').reduce((a,z)=>a+z.share,0);
assert(late&&late.share>0.20&&late.share<0.28);checks++;
assert(inside>0.72&&inside<0.80);checks++;
assert(late.factor<sum.zones.find(z=>z.label==='В допустимом окне').factor);checks++;
assert(sum.factor>.70&&sum.factor<.90);checks++;
assert(Math.abs(sum.zones.reduce((a,z)=>a+z.share,0)-1)<1e-9);checks++;
const f={id:17};const zones=ctx.fieldSpatialZones(f);assert.strictEqual(zones.length,3);checks++;
assert(Math.abs(zones.reduce((a,z)=>a+z.share,0)-1)<1e-9);checks++;
assert(Math.abs(zones.reduce((a,z)=>a+z.share*z.fertility,0)-1)<.002);checks++;
const good=ctx.fertilizerSpatialProfile(f,1,'npk'),worn=ctx.fertilizerSpatialProfile(f,.78,'npk');assert(worn.cv>good.cv);checks++;
assert(Math.abs(good.zones.reduce((a,z,i)=>a+z.factor*zones[i].share,0)-1)<.002);checks++;
const cropN={needs:{N:70,P:50,K:45},group:'cereal'},fg={id:17,crop:'x',spatialZones:zones,fertilizerSpatial:{zones:good.zones,cv:good.cv}},fw={id:17,crop:'x',spatialZones:zones,fertilizerSpatial:{zones:worn.zones,cv:worn.cv}};const adjGood=ctx.spatialNutritionAdjustment(fg,cropN),adjWorn=ctx.spatialNutritionAdjustment(fw,cropN);assert(adjGood>=.93&&adjGood<=1);checks++;assert(adjWorn>=.93&&adjWorn<=1);checks++;assert(adjWorn<adjGood);checks++;
for(const text of ['Неоднородность поля','ПОСЕВ ПО ПЛОЩАДИ','ЗОНЫ ПИТАНИЯ И РАВНОМЕРНОСТЬ ВНЕСЕНИЯ',"version:'0.11.9.74'",'sowSpatialSummary','fertilizerSpatial']){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,example:{hours:63,insidePct:+(inside*100).toFixed(1),latePct:+(late.share*100).toFixed(1),weightedFactor:+sum.factor.toFixed(4),bands:sum.zones.map(z=>({label:z.label,pct:+(z.share*100).toFixed(1),factor:+z.factor.toFixed(4)}))},uniformity:{newCv:+(good.cv*100).toFixed(1),wornCv:+(worn.cv*100).toFixed(1),nutritionAdjustmentGood:+adjGood.toFixed(4),nutritionAdjustmentWorn:+adjWorn.toFixed(4)}},null,2));
