const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let depth=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){depth++;seen=true;}else if(src[i]==='}'){depth--;if(seen&&depth===0){end=i+1;break;}}}return src.slice(start,end);}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start);assert(end>start,next);return src.slice(start,end)+';';}
const ctx={Math,Number,Date};ctx.DAY=86400000;ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.state={gameTime:new Date(2028,3,15).getTime()};ctx.cropStage=f=>({progress:f.progress??0});vm.createContext(ctx);
vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);
for(const n of ['nutrientAvailability','seasonalNitrogenCredit','nutrientSupply','targetYieldRange','yieldTargetFor','targetNutrientNeeds','nutrientStatus'])vm.runInContext(fn(n),ctx);
let checks=0;
const f={soil:{ph:5.1,N:40,P:35,K:55,organicMatter:2.4,strawNPool:0},lastCrop:'corn'};
const x=ctx.nutrientStatus(f,'spring_wheat');
assert(x.deficits.N>0&&x.deficits.P>0);checks++;
assert(['N','P','K'].includes(x.limiting));checks++;
assert(x.score<1);checks++;
for(const text of ['Агрохимия и питание','ПОТРЕБНОСТЬ N/P/K','ДОСТУПНО СЕЙЧАС','ДЕФИЦИТ N/P/K','АЗОТНЫЙ КРЕДИТ','РЕКОМЕНДАЦИЯ НА ТЕКУЩИЙ МОМЕНТ',"version:'0.11.9.74'"]){assert(src.includes(text),text);checks++;}
assert(src.includes('${f.owned?nutritionDashboardHtml(f,cropKey):\'\'}'));checks++;
console.log(JSON.stringify({pass:true,checks,limiting:x.limiting,score:x.score,deficits:x.deficits},null,2));
