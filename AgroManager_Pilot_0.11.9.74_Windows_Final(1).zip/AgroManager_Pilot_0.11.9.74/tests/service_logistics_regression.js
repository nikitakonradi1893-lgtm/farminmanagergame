const assert=require('assert');
global.window={};require('../web/equipment.js');
const E=window.EQUIPMENT_CATALOG, by=id=>E.find(x=>x.id===id), clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const SIMPLE=new Set(['running','tires','tracks','working','frame']), COMPLEX=new Set(['engine','transmission','hydraulics','metering','drive']);
function tech(m){const y=Number(m.years?.[0])||1980;if(m.segment==='domestic_used')return'legacy';if(m.segment==='foreign_new'||(m.segment==='domestic_new'&&y>=2012))return'modern';if(m.segment==='foreign_used'&&y>=2008)return'modern';return'mechanical'}
function cls(m,target,mode='partial'){const complex=COMPLEX.has(target);if(tech(m)==='legacy')return mode!=='partial'&&complex?'heavy_mechanical':'simple';if(tech(m)==='mechanical')return mode!=='partial'&&complex?'specialist':'simple';return complex?'brand':'specialist'}
function own(m,target,mode,lvl){const c=cls(m,target,mode);return c==='brand'?false:c==='simple'?lvl>=1:c==='heavy_mechanical'?lvl>=2:c==='specialist'?lvl>=3:false}
function field(m,target,mode,fleetLvl){if(mode==='capital'||fleetLvl<1)return false;if(mode==='replace'&&['engine','transmission','frame','drive'].includes(target))return false;if(['frame','engine','transmission'].includes(target))return mode==='partial'&&tech(m)==='legacy'&&fleetLvl>=2&&target!=='frame';return SIMPLE.has(target)||['hydraulics','metering','drive'].includes(target)}
function tow(distance,mass){const heavy=Math.max(0,mass-8),cost=distance>0?Math.round((30000+distance*2400+heavy*6500)/5000)*5000:0,hours=distance>0?clamp(1.2+distance/32+heavy*.035,1.5,10):0;return{cost,hours}}
const k700=by('k700'), fendt=by('fendt942'), k7m=by('k7m420');
assert(k700&&fendt&&k7m);
assert.strictEqual(tech(k700),'legacy');
assert.strictEqual(cls(k700,'running','partial'),'simple');
assert.strictEqual(cls(k700,'engine','capital'),'heavy_mechanical');
assert.strictEqual(own(k700,'engine','capital',1),false);
assert.strictEqual(own(k700,'engine','capital',2),true);
assert.strictEqual(cls(fendt,'engine','capital'),'brand');
assert.strictEqual(cls(fendt,'transmission','partial'),'brand');
assert.strictEqual(own(fendt,'engine','capital',6),false,'brand work must not become own repair even with max workshop');
assert.strictEqual(cls(k7m,'engine','capital'),'brand');
assert.strictEqual(field(k700,'running','partial',1),true);
assert.strictEqual(field(k700,'engine','partial',1),false);
assert.strictEqual(field(k700,'engine','partial',2),true,'legacy minor engine work may be field-serviced by service truck');
assert.strictEqual(field(k700,'engine','replace',2),false,'engine replacement requires workshop/tow');
assert.strictEqual(field(k700,'running','replace',1),true,'simple running-gear replacement can be field service');
assert.strictEqual(field(fendt,'transmission','partial',2),false,'modern complex transmission work is not a farm field-repair path');
const t1=tow(5,8),t2=tow(30,8),t3=tow(30,22);
assert(t2.cost>t1.cost); assert(t3.cost>t2.cost); assert(t3.hours>=t2.hours);
const src=require('fs').readFileSync(require('path').join(__dirname,'../web/app.js'),'utf8');
for(const name of ['serviceExecutionPlan','towQuote','fieldRepairEligible','ownWorkshopCanHandle','workshopBusySlots','serviceFleetBusyTeams'])assert(src.includes(`function ${name}`));
assert(src.includes("Представитель бренда"));
assert(src.includes("serviceFleet:["));
assert(src.includes("breakdownFieldId=task?.fieldId||null"));
console.log(JSON.stringify({pass:true,checks:26,examples:{k700CapitalEngine:cls(k700,'engine','capital'),fendtEngine:cls(fendt,'engine','capital'),tow5km8t:t1,tow30km22t:t3},meaning:'простая старая техника ремонтируется своими силами при достаточной мастерской; сложная современная требует брендового сервиса; выездной ремонт и эвакуация имеют отдельные ограничения и стоимость'},null,2));
