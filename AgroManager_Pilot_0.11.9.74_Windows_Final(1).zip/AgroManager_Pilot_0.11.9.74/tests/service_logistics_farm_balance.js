const assert=require('assert');
// 5-year 1000-ha scenario: compare old mechanical fleet with modern brand-dependent fleet.
// The test uses the release service multipliers/delays to verify that neither path is economically dominant.
function ownJob(baseCost,baseHours,skill=78,field=false,distance=12){let cost=baseCost*(field?.62:.68),hours=baseHours*(field?1.10:.82);const k=Math.max(.66,Math.min(.78,.82-skill*.0015));cost*=k;hours*=Math.max(.68,Math.min(.9,1.05-skill*.004));const call=field?15000:0,arrival=field?Math.max(1,Math.min(4,.5+distance/45)):0;return{cost:Math.round(cost+call),hours:hours+arrival}}
function brandJob(baseCost,baseHours,foreign=true,distance=12,mass=16){const mult=foreign?1.20:1.10,arrival=foreign?36:18,heavy=Math.max(0,mass-8),tow=Math.round((30000+distance*2400+heavy*6500)/5000)*5000,towH=Math.max(1.5,Math.min(10,1.2+distance/32+heavy*.035));return{cost:Math.round(baseCost*mult+80000+tow),hours:baseHours*.95+arrival+towH}}
let old={cost:0,hours:0,fieldRepairs:0,tows:0},modern={cost:0,hours:0,brandCalls:0,tows:0};
for(let y=0;y<5;y++){
  // Old fleet: one ordinary running/hydraulic issue per year, field repairable; one heavy shop repair every 2 years.
  const f=ownJob(85000,10,78,true,14); old.cost+=f.cost;old.hours+=f.hours;old.fieldRepairs++;
  if(y%2===1){const h=ownJob(260000,34,78,false,0);old.cost+=h.cost;old.hours+=h.hours;}
  // Modern fleet: fewer failures, but every second season one complex electronic/powertrain repair needs brand rep.
  if(y!==2){const routine=ownJob(110000,8,82,true,14);modern.cost+=routine.cost;modern.hours+=routine.hours;}
  if(y%2===0){const b=brandJob(320000,30,true,14,18);modern.cost+=b.cost;modern.hours+=b.hours;modern.brandCalls++;modern.tows++;}
}
assert(old.fieldRepairs===5);assert(modern.brandCalls===3);
assert(old.cost<modern.cost,'old simple fleet should retain a service-cost advantage');
assert(modern.hours>old.hours*.75,'brand logistics must create material downtime, not instant magic');
assert(modern.cost<old.cost*4,'brand service should be expensive but not economically absurd');
const emergencyContractorFor40ha=198700;
assert(emergencyContractorFor40ha<modern.cost,'contractor rescue can rationally beat waiting for repeated brand repairs during a narrow window');
console.log(JSON.stringify({pass:true,seasons:5,areaHa:1000,oldFleet:{serviceCost:old.cost,downtimeH:+old.hours.toFixed(1),fieldRepairs:old.fieldRepairs},modernFleet:{serviceCost:modern.cost,downtimeH:+modern.hours.toFixed(1),brandCalls:modern.brandCalls,tows:modern.tows},meaning:'старая простая техника сохраняет преимущество ремонтопригодности; современная ломается не чаще в этой проверке, но сложный ремонт дороже и логистически тяжелее; подрядчик остаётся рациональной страховкой сезонного окна'},null,2));
