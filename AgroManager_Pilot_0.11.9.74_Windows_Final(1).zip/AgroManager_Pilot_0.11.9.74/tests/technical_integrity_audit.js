const fs=require('fs'),assert=require('assert');
const app=fs.readFileSync('web/app.js','utf8'), idx=fs.readFileSync('web/index.html','utf8'), eq=fs.readFileSync('web/equipment.js','utf8');
const all=app+'\n'+idx;
let checks=0;
// Every literal interactive element must expose at least one handled data-* attribute, a delegated data-page, or one of the fixed top-level IDs.
const handled=new Set([...all.matchAll(/\[data-([a-z0-9-]+)(?:[=\]])/ig)].map(m=>'data-'+m[1].toLowerCase()));
const fixedIds=new Set(['manualSaveBtn','manualLoadBtn','resetBtn','exitBtn']);
const unbound=[];let interactive=0;
for(const m of all.matchAll(/<(button|select|input|textarea)\b([^>]*)>/igs)){
  interactive++;
  const attrs=m[2], das=[...attrs.matchAll(/\b(data-[a-z0-9-]+)(?:=|\s|$)/ig)].map(x=>x[1].toLowerCase()), id=(attrs.match(/\bid=["']([^"']+)["']/i)||[])[1];
  if(id&&fixedIds.has(id))continue;
  if(das.includes('data-page'))continue;
  if(das.some(d=>handled.has(d)))continue;
  unbound.push(m[0].slice(0,220));
}
assert.deepStrictEqual(unbound,[],'unbound interactive elements: '+unbound.join('\n'));checks++;
// No duplicate function declarations: later declarations silently override earlier ones in classic JS.
for(const [file,text] of [['app.js',app],['equipment.js',eq]]){
  const names=[...text.matchAll(/^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/gm)].map(m=>m[1]);
  const dup=[...new Set(names.filter((n,i)=>names.indexOf(n)!==i))];
  assert.deepStrictEqual(dup,[],file+' duplicate functions: '+dup.join(','));checks++;
}
// No unreachable named function declarations (single lexical occurrence = declaration only).
const dead=[];
for(const m of app.matchAll(/^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/gm)){
  const n=m[1], re=new RegExp('(^|[^A-Za-z0-9_$])'+n.replace(/[$]/g,'\\$&')+'([^A-Za-z0-9_$]|$)','g');
  if([...app.matchAll(re)].length===1)dead.push(n);
}
assert.deepStrictEqual(dead,[],'dead named functions: '+dead.join(','));checks++;
// Nav pages must all be represented in render map.
const nav=[...idx.matchAll(/data-page="([^"]+)"/g)].map(m=>m[1]);
const map=(app.match(/const map=\{([^}]+)\};document\.getElementById\('content'\)/)||[])[1]||'';
for(const p of nav){assert(new RegExp('(?:^|,)'+p+':').test(map),`nav page without renderer: ${p}`);checks++;}
// High-frequency live pages must refresh while time is running. Fields/Meadows are intentionally excluded to avoid full-DOM scroll/hover flicker; they rerender on actual actions/navigation.
const live=(app.match(/else if\(\[(.*?)\]\.includes\(page\)/)||[])[1]||'';
for(const p of ['dashboard','management','operations','processes','fieldDetail','agronomy','calendar','weather','finance','materials','market','contracts','deliveryContracts','warehouse','infrastructure','staff']){assert(live.includes(`'${p}'`),`live page not refreshed: ${p}`);checks++;}
assert(app.includes('equipmentUiRevision++;}\nfunction transportPairOptions'), 'equipment UI revision is not bumped after machine usage');checks++;
// Runtime assets must be versioned with current release, and no obsolete runtime backups may be embedded.
assert(idx.includes('0.11.9.74'));checks++;for(const a of ['styles.css?v=011974','equipment.js?v=011974','app.js?v=011974']){assert(idx.includes(a),a);checks++;}
for(const f of ['web/app.js.pre70','web/index.html.pre70','web/equipment.js.bak59','web/equipment.js.bak60','web/README.txt']){assert(!fs.existsSync(f),`obsolete runtime file remains: ${f}`);checks++;}
// No explicit unfinished/debug markers in live runtime code.
assert(!/\b(?:TODO|FIXME|NOT IMPLEMENTED)\b|debugger\s*;/i.test(app+'\n'+eq));checks++;
console.log(JSON.stringify({pass:true,checks,interactiveElements:interactive,navPages:nav.length,livePages:16},null,2));
