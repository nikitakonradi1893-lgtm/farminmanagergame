'use strict';
const fs=require('fs'),vm=require('vm');
let checks=0;function ok(x,msg){checks++;if(!x)throw new Error(msg)}
const eq=fs.readFileSync('web/equipment.js','utf8'),app=fs.readFileSync('web/app.js','utf8');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(eq,ctx);
const C=ctx.window.EQUIPMENT_CATALOG,by=id=>C.find(x=>x.id===id);
ok(app.includes("version:'0.11.9.74'"),'runtime version');
const caps=[
 ['capello_quasar4','corn',1210,'кукурузная жатка'],['capello_quasar6','corn',1750,'кукурузная жатка'],['capello_quasar8','corn',2230,'кукурузная жатка'],['capello_quasar12','corn',3650,'кукурузная жатка'],
 ['capello_hel57','sunflower',1800,'жатка для подсолнечника'],['capello_hel75','sunflower',2400,'жатка для подсолнечника'],['capello_hel94','sunflower',2900,'жатка для подсолнечника'],['capello_hel119','sunflower',3500,'жатка для подсолнечника']
];
for(const [id,cat,kg,label] of caps){const h=by(id);ok(!!h,id+' exists');ok(h.category===cat,id+' category');ok(h.headerWeightKg===kg,id+' weight');ok(h.name.toLowerCase().includes(label),id+' visible purpose');ok(h.compatibleCombineIds.length>0,id+' compatibility');for(const cid of h.compatibleCombineIds){const c=by(cid);ok(c.type==='combine',id+' combine ref '+cid);ok(c.compatibleHeaderIds.includes(id),id+' symmetry '+cid);ok((c.maxHeaderWidth||0)+.01>=h.width,id+' width gate '+cid);ok((c.maxHeaderWeightKg||0)+1>=kg,id+' weight gate '+cid);ok((c.hp||0)>=(h.minCombineHp||0),id+' hp gate '+cid);}}
ok(by('capello_hel119').name.includes('12.0'),'Helianthus official model name 12.0');ok(by('capello_hel119').width===11.9,'Helianthus 12.0 working width 11.9');
for(const id of ['jd9500_used','jd9600_used','case1680_used','case2188_used','nh_tx66_used','claas_mega208_used'])ok(by(id).compatibleHeaderIds.some(x=>x.startsWith('capello_')),'legacy adapter '+id);
ok(app.includes('function headerCompatibleForCrop'),'crop-aware compatibility helper');ok(app.includes("headerCategoryFor(cropKey)===headerModel?.category"),'crop category gate');ok(app.includes("m.category==='corn'?'Кукурузная жатка':m.category==='sunflower'?'Жатка для подсолнечника'"),'purpose labels');ok(app.includes("['grain','Зерновые'],['pickup_grain','Подбор валков'],['corn','Кукуруза'],['sunflower','Подсолнечник']"),'combine compatibility grouped by crop');
console.log(`Capello header compatibility 0.11.9.24: ${checks}/${checks} PASS`);
