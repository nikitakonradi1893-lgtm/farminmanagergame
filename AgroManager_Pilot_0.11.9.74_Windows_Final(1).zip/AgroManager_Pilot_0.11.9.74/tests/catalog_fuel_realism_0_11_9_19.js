const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const C=ctx.window.EQUIPMENT_CATALOG,M=id=>C.find(x=>x.id===id);let checks=0;
function ok(v,msg){assert(v,msg);checks++;}
const requested=[
 ['jcb_fastrac4220','JCB','tractor','foreign_new'],['valtra_q305','Valtra','tractor','foreign_new'],
 ['brantner_z18051_2xxl','Brantner','trailer','foreign_new'],['kinze_3665_bluedrive','Kinze','implement','foreign_new'],
 ['vicon_fanex904','Vicon','implement','foreign_new'],['arcusin_fsx6372','Arcusin','implement','foreign_new'],
 ['bale_anderson_rbm2000','Anderson Group','implement','foreign_new'],['bobruisk_tp10_1','Бобруйскагромаш','implement','domestic_new']
];
for(const [id,brand,type,segment] of requested){const m=M(id);ok(!!m,`${id} exists`);ok(m.brand===brand,`${id} brand`);ok(m.type===type,`${id} type`);ok(m.segment===segment,`${id} segment`);}
const old=['jcb_fastrac185_used','jd7810_used','case7240_used','fendt_favorit926_used','valmet8950_used','mf3690_used','df_agrostar681_used','nh_1033_stackliner_used'];
for(const id of old){const m=M(id);ok(!!m,`${id} exists`);ok(m.segment==='foreign_used',`${id} old foreign`);ok(m.years[0]<2000,`${id} pre-2000`);}
ok(M('nh_1033_stackliner_used').type==='implement'&&M('nh_1033_stackliner_used').category==='bale_transport','1033 pull-type bale wagon classification');
ok(M('nh_1033_stackliner_used').baleSelfLoading===true&&M('nh_1033_stackliner_used').baleCapacity.small_square===104,'1033 small-square self loading');
const sc=M('bale_nh_stackcruiser102');ok(sc.type==='truck','Stackcruiser remains self-propelled transport');ok(sc.baleRole==='self_propelled_stack_wagon','Stackcruiser role');ok(sc.baleHaulEligible===false,'Stackcruiser excluded from tractor-trailer premium');
ok(M('arcusin_fsx6372').baleFormats.includes('large_square'),'Arcusin large-square');ok(M('bale_anderson_rbm2000').baleCapacity.round===20,'RBM2000 capacity');ok(M('bale_anderson_rbm2000').requiredHp>=130,'RBM2000 hp floor');
const powered=C.filter(m=>Number(m.workFuelLph)>0);ok(powered.length>=210,'powered inventory did not shrink');
for(const m of powered){ok(Number.isFinite(m.workFuelLph)&&m.workFuelLph>0,`${m.id} work fuel`);ok(Number.isFinite(m.roadFuelLph)&&m.roadFuelLph>0,`${m.id} road fuel`);if(m.type!=='truck')ok(m.roadFuelLph<m.workFuelLph,`${m.id} road lower than work`);}
ok(powered.some(m=>m.fuelLphOriginal>m.workFuelLph),'high outliers were reduced');
ok(M('sk5').workFuelLph===18&&M('sk5').fuelLphOriginal===22,'SK-5 high work fuel capped');
ok(M('mtz82').workFuelLph<14&&M('mtz82').roadFuelLph<M('mtz82').workFuelLph,'MTZ-82 calibrated');
ok(M('valtra_q305').roadFuelLph>=15&&M('valtra_q305').roadFuelLph<=20,'Q305 road fuel plausible band');
const app=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');
ok(app.includes("version:'0.11.9.74'"),'runtime version');ok(idx.includes('PILOT 0.11.9.74')&&idx.includes('011974'),'HTML version/cache');
ok(app.includes('machineRoadFuelLph'),'road fuel helper wired');ok(app.includes('machineWorkFuelLph'),'work fuel helper wired');ok(app.includes('Расход при перегоне'),'UI road fuel');ok(app.includes('baleHaulEligible!==false'),'Premium eligibility gate');ok(app.includes('function equipmentUiCategory'),'UI category helper');ok(app.includes("selfPropelled:'Самоходные машины'"),'self-propelled market section');ok(C.filter(m=>m.type==='implement'&&m.selfPropelled).length>=18,'self-propelled implement inventory did not shrink');
console.log(JSON.stringify({pass:true,checks,catalog:C.length,active:C.filter(m=>!m.hidden).length,powered:powered.length,earliestForeignUsed:Math.min(...C.filter(m=>m.segment==='foreign_used').map(m=>m.years?.[0]||9999)),fuelExamples:{mtz82:{work:M('mtz82').workFuelLph,road:M('mtz82').roadFuelLph},sk5:{work:M('sk5').workFuelLph,road:M('sk5').roadFuelLph},q305:{work:M('valtra_q305').workFuelLph,road:M('valtra_q305').roadFuelLph}}},null,2));
