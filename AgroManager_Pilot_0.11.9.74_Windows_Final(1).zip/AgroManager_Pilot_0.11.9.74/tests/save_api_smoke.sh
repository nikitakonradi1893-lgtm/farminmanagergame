#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
rm -rf "$ROOT/launcher_source/web"
cp -a "$ROOT/web" "$ROOT/launcher_source/web"
trap 'rm -rf "$ROOT/launcher_source/web"; rm -rf "$TMP"' EXIT
(cd "$ROOT/launcher_source" && go build -o "$TMP/agro_test" .)
cd "$TMP"
./agro_test >launcher.log 2>&1 &
PID=$!
for i in $(seq 1 50); do curl -fsS http://127.0.0.1:38471/health >/dev/null 2>&1 && break; sleep .1; done
for n in 1 2 3 4; do curl -fsS -X POST 'http://127.0.0.1:38471/api/save?slot=autosave' -H 'Content-Type: application/json' --data-binary "{\"version\":\"0.11.9.14\",\"seq\":$n,\"gameTime\":1760000000000,\"money\":2000000,\"fields\":[],\"warehouse\":{}}" >/dev/null; done
[ "$(cat saves/autosave.json)" = '{"version":"0.11.9.14","seq":4,"gameTime":1760000000000,"money":2000000,"fields":[],"warehouse":{}}' ]
[ "$(cat saves/autosave.json.bak1)" = '{"version":"0.11.9.14","seq":3,"gameTime":1760000000000,"money":2000000,"fields":[],"warehouse":{}}' ]
[ "$(cat saves/autosave.json.bak2)" = '{"version":"0.11.9.14","seq":2,"gameTime":1760000000000,"money":2000000,"fields":[],"warehouse":{}}' ]
[ "$(cat saves/autosave.json.bak3)" = '{"version":"0.11.9.14","seq":1,"gameTime":1760000000000,"money":2000000,"fields":[],"warehouse":{}}' ]
printf '{broken' > saves/autosave.json
curl -fsS -D headers.txt 'http://127.0.0.1:38471/api/save?slot=autosave' -o recovered.json
[ "$(cat recovered.json)" = '{"version":"0.11.9.14","seq":3,"gameTime":1760000000000,"money":2000000,"fields":[],"warehouse":{}}' ]
grep -qi '^X-Save-Recovered: true' headers.txt

# Schema guard: syntactically valid but non-game JSON must be rejected.
if curl -fsS -X POST 'http://127.0.0.1:38471/api/save?slot=manual' -H 'Content-Type: application/json' --data-binary '{}' >/dev/null 2>&1; then echo 'invalid schema accepted' >&2; exit 1; fi
curl -fsS -X POST http://127.0.0.1:38471/quit >/dev/null || true
wait "$PID" || true
echo PASS
