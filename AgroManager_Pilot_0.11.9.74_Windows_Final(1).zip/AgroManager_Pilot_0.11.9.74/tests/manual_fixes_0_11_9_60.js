const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(inContent=false){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(sel){return inContent&&sel==='#content'?{}:null},getBoundingClientRect(){return{top:0,bottom:20}},blur(){}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));
const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`ui60-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__ui60={freshState,setState(x){state=x},fuelPurchaseQuote,makeUsedListing,equipmentModel,implementCatLabel,renderSpareRiskGroups,uiInteractionActive,generateUsedMarket,ensureUsedCategoryCoverage,getState(){return state},advanceSystems};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});
const a=ctx.__ui60;let checks=0;assert(src.includes("version:'0.11.9.74'"));checks++;
const st=a.freshState('medium');a.setState(st);
// 1 fuel savings must rise as supplier becomes cheaper, while final totals fall.
const qFast=a.fuelPurchaseQuote(5000,'bulk','fast'),qReg=a.fuelPurchaseQuote(5000,'bulk','regional'),qWh=a.fuelPurchaseQuote(5000,'bulk','wholesale');
assert(qFast.cost>qReg.cost&&qReg.cost>qWh.cost);checks++;assert(qFast.savings<qReg.savings&&qReg.savings<qWh.savings);checks++;assert(qFast.discount===qReg.discount&&qReg.discount===qWh.discount);checks++;
// 2 old equipment market must include rare high-condition restored examples.
const k700=a.equipmentModel('k700');assert(k700);checks++;let best=0,ref=0;for(let i=0;i<1200;i++){const l=a.makeUsedListing(12345+i,i%200,k700,Date.UTC(2026,5,1));best=Math.max(best,l.trueCondition);if(l.refurbished){ref++;assert(l.trueCondition>=70);}}assert(ref>0&&best>=70);checks++;
// 3 localization of new categories.
for(const [k,label] of [['silage_leveler','Разравниватели силоса'],['silage_compactor','Уплотнители силоса'],['fuel_supply_kit','Комплекты полевого ГСМ'],['fuel_supply_container','Мобильные ёмкости ГСМ']]){assert.strictEqual(a.implementCatLabel(k),label);checks++;}
// 4 light support assets exist and used market guarantees them.
for(const id of ['fuel_uaz469','fuel_uaz3303','fuel_gazelle3302','fuel_light_trailer500']){assert(a.equipmentModel(id));checks++;}
st.equipment.usedMarket=[];a.ensureUsedCategoryCoverage(777,st.gameTime);assert(st.equipment.usedMarket.some(l=>a.equipmentModel(l.modelId)?.category==='fuel_support_light'));checks++;assert(st.equipment.usedMarket.some(l=>a.equipmentModel(l.modelId)?.category==='fuel_support_trailer'));checks++;
// 5 insurance reserve is grouped by machine model and collapsible.
const html=a.renderSpareRiskGroups([{modelId:'k700',modelName:'К-700',key:'engine',count:5,risk500:.12,maxRisk:.03,inventory:0},{modelId:'k700',modelName:'К-700',key:'transmission',count:5,risk500:.08,maxRisk:.02,inventory:1}]);assert((html.match(/<summary>/g)||[]).length===1&&html.includes('<details')&&html.includes('Двигатель'));checks++;
// 6 top speed button focus must not block live content refresh.
document.activeElement=el(false);document.activeElement.tagName='BUTTON';assert.strictEqual(a.uiInteractionActive(),false);checks++;document.activeElement=el(true);document.activeElement.tagName='BUTTON';assert.strictEqual(a.uiInteractionActive(),true);checks++;
console.log(JSON.stringify({pass:true,checks,fuel:{fast:qFast,regional:qReg,wholesale:qWh},usedK700:{best,refurbishedSamples:ref}},null,2));
