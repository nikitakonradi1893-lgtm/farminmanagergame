const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
const H=3600000,DAY=24*H,start=new Date(2028,4,18,8).getTime();
const ctx={Math,Number,Date,DAY};ctx.clamp=(v,a,b)=>Math.max(a,Math.min(b,v));ctx.num=(v,d=0)=>Number(v).toFixed(d);ctx.rub=v=>`${Math.round(v)} ₽`;
ctx.durationText=(h)=>{const m=Math.round((Number(h)||0)*60),hh=Math.floor(m/60),mm=m%60;return hh+(mm?` ч ${mm} мин`:' ч')};
ctx.state={gameTime:start,money:2_000_000,staff:{owner:{id:'OWNER',role:'owner',name:'Владелец',skill:45,busyUntil:0,restUntil:0},employees:[{id:'P1',role:'operator',name:'Штатный механизатор',skill:74,contract:'permanent',salaryMonthly:80000,busyUntil:0,restUntil:0}],market:[{id:'S1',role:'operator',name:'Сезонный механизатор',skill:72,marketType:'seasonal',salaryMonthly:90000,hourlyRate:900},{id:'G1',role:'operator',name:'Разовый механизатор',skill:70,marketType:'permanent',salaryMonthly:80000,hourlyRate:700}],gigBusyUntil:{},gigRestUntil:{}}};
ctx.roleForUnit=()=> 'operator';ctx.unitSkillRequirement=()=>({threshold:60});ctx.activeEmployee=e=>e&&(!e.contractEnd||e.contractEnd>ctx.state.gameTime);ctx.ownerWorker=()=>ctx.state.staff.owner;ctx.gigCandidateFree=(c,at)=>Number(ctx.state.staff.gigBusyUntil[c.id]||0)<=at&&Number(ctx.state.staff.gigRestUntil[c.id]||0)<=at;ctx.seasonalContractCost=(c,days)=>Math.round(c.salaryMonthly*(days/30)*1.25);ctx.OPS={sow:{cost:1800},herbicide:{cost:1300}};
ctx.contractorTierQuote=(field,op,tier,crop)=>({tierId:'standard',tier:{label:'Стандарт'},rate:4,priceFactor:1,mobilizationCost:op==='sow'?5400:3900,label:'Стандарт'});
vm.createContext(ctx);for(const n of ['managementWorkerQualified','managementWorkerAvailableHours','managementStaffScenarios','managementPortfolioStaffAllocation','managementContractorScenario','managementStaffRecommendation'])vm.runInContext(fn(n),ctx);
let checks=0;const unit={key:'u',assets:[]};const end=start+48*H;
const allocation=ctx.managementPortfolioStaffAllocation([
 {id:'sow',label:'Поле 1 · посев',units:[unit],endAt:end,workHours:32,priority:3},
 {id:'spray',label:'Поле 2 · гербицид',units:[unit],endAt:end,workHours:24,priority:2}
],start);
assert.strictEqual(allocation.sow.allocatedHours,16);checks++;
assert.strictEqual(allocation.spray.allocatedHours,0);checks++;
assert.strictEqual(allocation.spray.conflictHours,16);checks++;
const sowFc={window:{start,optimalEnd:end,end}},sprayFc={window:{start,optimalEnd:end,end}};
const sow=ctx.managementStaffRecommendation([unit],sowFc,2,64,start,{currentHours:allocation.sow.allocatedHours,conflictHours:allocation.sow.conflictHours,reservedFor:allocation.sow.reservedFor,field:{ha:64},op:'sow',cropKey:'spring_wheat'});
const spray=ctx.managementStaffRecommendation([unit],sprayFc,2,48,start,{currentHours:allocation.spray.allocatedHours,conflictHours:allocation.spray.conflictHours,reservedFor:allocation.spray.reservedFor,field:{ha:48},op:'herbicide',cropKey:'spring_wheat'});
assert.strictEqual(sow.currentPct,50);checks++;
assert.strictEqual(sow.seasonalPct,100);checks++;
assert.strictEqual(sow.gigPct,88);checks++;
assert.strictEqual(sow.economicChoice.label,'подрядчик на остаток');checks++;
assert.strictEqual(sow.economicChoice.cost,63000);checks++;
assert.strictEqual(spray.currentPct,0);checks++;
assert.strictEqual(spray.comboPct,100);checks++;
assert.strictEqual(spray.economicChoice.label,'подрядчик на остаток');checks++;
assert.strictEqual(spray.economicChoice.cost,66300);checks++;
const rescueCost=sow.economicChoice.cost+spray.economicChoice.cost,after=ctx.state.money-rescueCost;
assert(after>1_800_000);checks++;
assert(sow.text.includes('Дефицит до полного выполнения: 16.0 чел.-ч.'));checks++;
assert(spray.text.includes('Переброска сюда возможна только ценой снижения покрытия'));checks++;
assert(sow.text.includes('Сезонный договор дешевле эквивалентных разовых смен примерно с 21-й 8-часовой смены'));checks++;
console.log(JSON.stringify({pass:true,checks,scenario:'хозяйство со стартом 2 млн ₽, один штатный квалифицированный механизатор, две пересекающиеся операции по 48 ч',startMoney:ctx.state.money,allocation:{sowH:allocation.sow.allocatedHours,sprayH:allocation.spray.allocatedHours,sprayConflictH:allocation.spray.conflictHours},sow:{currentPct:sow.currentPct,seasonalPct:sow.seasonalPct,gigPct:sow.gigPct,cheapest100:sow.economicChoice},spray:{currentPct:spray.currentPct,seasonalPct:spray.seasonalPct,gigPct:spray.gigPct,comboPct:spray.comboPct,cheapest100:spray.economicChoice},rescueCost,cashAfterRescue:after},null,2));
