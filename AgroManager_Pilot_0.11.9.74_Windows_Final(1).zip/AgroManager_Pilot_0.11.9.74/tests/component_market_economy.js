const assert=require('assert');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const specs=[
 {name:'K-700 stock trans',price:420000,h:30},
 {name:'K-700 reinforced trans',price:780000,h:42},
 {name:'K-700 heavy trans',price:1180000,h:56},
 {name:'K-700 reinforced running',price:690000,h:38},
 {name:'K-700 reinforced hydraulics',price:470000,h:30}
];
let checks=0,rows=[];
for(const s of specs){const dealer=Math.round(s.price*1.06/10000)*10000;const resaleNew=Math.max(20000,Math.round(s.price*(.22+.0068*100)*1*.84/10000)*10000);assert(resaleNew<dealer);checks++;const usedBuy=Math.max(30000,Math.round(s.price*(.28+.0061*70)*clamp(1-7000/35000,.60,1)*.90/10000)*10000);const usedResale=Math.max(20000,Math.round(s.price*(.22+.0068*70)*clamp(1-7000/35000,.58,1)*.84/10000)*10000);assert(usedResale<usedBuy);checks++;rows.push({name:s.name,dealer,resaleNew,used70h7000:usedBuy,resaleUsed:usedResale});}
const labor=Math.max(60000,Math.round(42*3800/10000)*10000);assert(labor===160000);checks++;
// A stored identical replacement can be reinstalled for labour only; no second hardware purchase.
const first=780000+labor,reinstall=labor;assert(reinstall<first*.2);checks++;
console.log(JSON.stringify({pass:true,checks,rows,reinstallLabor:reinstall,firstPurchaseAndInstall:first},null,2));
