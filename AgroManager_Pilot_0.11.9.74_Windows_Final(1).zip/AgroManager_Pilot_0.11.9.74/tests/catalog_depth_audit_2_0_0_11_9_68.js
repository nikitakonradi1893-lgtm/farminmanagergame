const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=process.cwd();
const src=fs.readFileSync(root+'/web/equipment.js','utf8');const ctx={window:{},console};vm.createContext(ctx);vm.runInContext(src,ctx);const E=ctx.window.EQUIPMENT_CATALOG;
let pass=0,warn=[];const ok=(v,m)=>{assert(v,m);pass++};
ok(E.length>=840,`catalog count ${E.length}`);
ok(new Set(E.map(x=>x.id)).size===E.length,'unique ids');
ok(E.filter(x=>x.type==='tractor').length>=152,`tractor count ${E.filter(x=>x.type==='tractor').length}`);
const essential=['plow','cultivate','sow_grain','fertilizer','sprayer'];
for(const hp of [79,119,159,199,249,299,349,399,499,700])for(const cat of essential){const n=E.filter(x=>x.type==='implement'&&x.category===cat&&(x.requiredHp||0)<=hp).length;ok(n>0,`${hp} hp has ${cat}`)}
// thin-choice screens rather than hard failures
for(const hp of [79,119])for(const cat of ['plow','cultivate','disk','sow_grain','sow_row','fertilizer','sprayer','baler']){const a=E.filter(x=>x.type==='implement'&&x.category===cat&&(x.requiredHp||0)<=hp);if(a.length<3)warn.push({kind:'thin_power_choice',hp,category:cat,count:a.length});}
// obvious semantic brand mismatch detector
const known=['John Deere','CLAAS','Ростсельмаш','ПАЛЕССЕ','JCB','Case IH','New Holland','Fendt','Massey Ferguson','DEUTZ-FAHR','LOVOL','YTO','Väderstad','HORSCH','Kverneland','KUHN','Amazone','AMAZONE','Lemken','LEMKEN','Great Plains','Gaspardo','GRIMME','AVR','MacDon','Capello','Manitou','АМКОДОР','ТОНАР','КамАЗ','МАЗ','ГАЗ','УАЗ','Scania','Volvo','MAN','Pronar','Fliegl','JOSKIN','Krampe','Brantner','Kinze'];
for(const x of E){if(x.brand!=='Прочие')continue;const expected=known.find(k=>x.name.toLowerCase().includes(k.toLowerCase()));if(expected)warn.push({kind:'obvious_brand_mismatch',id:x.id,name:x.name,expected});}
// current-new line power holes for major brands (screen only, not a passport verdict)
const bins=[[50,79],[80,119],[120,159],[160,199],[200,249],[250,299],[300,349],[350,399],[400,499],[500,999]];
for(const brand of ['John Deere','Case IH','New Holland','Fendt','CLAAS','Massey Ferguson','DEUTZ-FAHR','Valtra','Беларус','Кировец']){
 const a=E.filter(x=>x.type==='tractor'&&x.brand===brand&&x.newAvailable);
 warn.push({kind:'new_brand_ladder',brand,count:a.length,bins:bins.map(([l,h])=>a.some(x=>x.hp>=l&&x.hp<=h)?1:0).join('')});
}
// transport ladder basic continuity
for(const typ of ['truck','trailer','graincart'])ok(E.some(x=>x.type===typ),`has ${typ}`);
const carts=E.filter(x=>x.type==='graincart'); if(carts.filter(x=>!x.newAvailable).length<2)warn.push({kind:'used_graincart_thin',count:carts.filter(x=>!x.newAvailable).length});
// combine/header mutual matrix must remain nonempty
const combines=E.filter(x=>x.type==='combine'),headers=E.filter(x=>x.type==='header'),byId=new Map(E.map(x=>[x.id,x]));
for(const c of combines)ok(Array.isArray(c.compatibleHeaderIds)&&c.compatibleHeaderIds.length>=1,`headers ${c.id}`);
for(const h of headers)ok(Array.isArray(h.compatibleCombineIds)&&h.compatibleCombineIds.length>=1,`combines ${h.id}`);
const out={pass,warnings:warn.length,warningKinds:Object.fromEntries([...new Set(warn.map(x=>x.kind))].map(k=>[k,warn.filter(x=>x.kind===k).length])),warn};
fs.writeFileSync('/mnt/data/catalog_depth_audit_2_0_results.json',JSON.stringify(out,null,2));console.log(JSON.stringify({pass,warnings:warn.length,warningKinds:out.warningKinds},null,2));
