const assert=require('assert');
// Long-horizon systems test. Uses the same critical-risk shape and .72 preventive reduction logic,
// with farm-size-dependent annual operating hours. This is a system/economy test, not browser e2e.
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function risk100(h,cond,ov,svc,stress,pf=1,reliability=.9){let p=.025;p+=Math.min(.36,Math.max(0,h-2500)/1000*.026);p+=Math.max(0,70-cond)*.010;p+=ov*.095;p+=Math.min(.14,svc*.009);p+=Math.max(0,stress-1)*.55;return clamp(p*pf/Math.max(.72,reliability),.01,2.5)}
function rng(seed){let x=seed>>>0;return()=>{x=(Math.imul(1664525,x)+1013904223)>>>0;return x/4294967296}}
function run(startMoney,preventive,seed){const r=rng(seed^startMoney), scale=startMoney===2e6?.65:startMoney===5e6?1:1.45;let cash=startMoney, downtime=0, critical=0, missed=0, service=0, spareSpend=0;const nodes=[
 {h:startMoney===2e6?7000:3500,cond:startMoney===2e6?72:84,ov:0,svc:4,stress:1.04,rate:230*scale,cost:650000},
 {h:startMoney===2e6?9000:4500,cond:startMoney===2e6?68:82,ov:1,svc:6,stress:1.08,rate:190*scale,cost:820000},
 {h:startMoney===2e6?5000:2200,cond:startMoney===2e6?76:90,ov:0,svc:3,stress:1.00,rate:160*scale,cost:430000}
 ];
 // larger farms gradually add modern machines and a service contract after scale justifies it
 let contract=false;
 for(let y=0;y<15;y++){
   if(preventive && startMoney>=10e6 && y>=4 && !contract){cash-=520000;service+=520000;contract=true}
   for(const n of nodes){
     const annual=n.rate*(.85+r()*.3), cycles=Math.max(1,Math.ceil(annual/50));
     let since=preventive?0:9999;
     for(let c=0;c<cycles;c++){
       const dh=Math.min(50,annual-c*50); if(dh<=0)break;
       n.h+=dh; n.cond=Math.max(45,n.cond-dh*(.0012+.00035*n.stress)); since+=dh;
       if(preventive && since>=350){const cost=22000+Math.round(n.cost*.006);cash-=cost;service+=cost;since=0;n.svc++;}
       const pf=preventive?(since<125?.82:since<245?.88:.94):1;
       const p=risk100(n.h,n.cond,n.ov,n.svc,n.stress,pf)/100*(dh/100);
       if(r()<p){critical++;const urgent=(r()<.62),hours=(urgent?6:72)+(contract?18:32);downtime+=hours;cash-=n.cost*(urgent?.58:1.08);service+=n.cost*(urgent?.58:1.08);if(hours>48)missed++;n.cond=urgent?70:100;n.h=urgent?4000+r()*5000:0;n.ov=urgent?(r()<.25?1:0):0;}
     }
   }
   // prevention sometimes keeps one practical spare for higher-risk larger fleets; carrying capital isn't free
   if(preventive && startMoney>=5e6 && y===3){spareSpend=startMoney>=10e6?700000:420000;cash-=spareSpend;}
   // representative farm operating surplus, purpose is comparative not full agronomy simulation
   cash+=startMoney===2e6?2.0e6:startMoney===5e6?3.9e6:6.4e6;
 }
 return{cash,downtime,critical,missed,service,spareSpend};
}
for(const budget of [2e6,5e6,10e6]){
 let R={downtime:0,critical:0,missed:0,cash:0},P={downtime:0,critical:0,missed:0,cash:0};
 for(let s=1;s<=200;s++){const a=run(budget,false,s),b=run(budget,true,s);for(const k of Object.keys(R))R[k]+=a[k];for(const k of Object.keys(P))P[k]+=b[k];}
 for(const x of [R,P])for(const k of Object.keys(x))x[k]/=200;
 assert(P.downtime<R.downtime,'prevention should reduce downtime');
 assert(P.critical<=R.critical*1.02,'prevention should not increase critical failures materially');
 assert(P.missed<=R.missed,'prevention should protect seasonal windows');
 // do not demand that prevention is always more profitable: small farm can rationally stay reactive.
 if(budget===2e6) assert(P.cash<R.cash*1.08,'prevention must not become a free-profit meta for tiny farms');
 console.log(JSON.stringify({budget,reactive:R,preventive:P,downtimeReductionPct:+((1-P.downtime/R.downtime)*100).toFixed(1),criticalReductionPct:+((1-P.critical/R.critical)*100).toFixed(1)}));
}
console.log(JSON.stringify({pass:true,seedsPerBudget:200,seasons:15,meaning:'профилактика снижает простои и риск пропуска окон, но имеет стоимость; на малом хозяйстве реактивная стратегия остаётся жизнеспособной'}));
