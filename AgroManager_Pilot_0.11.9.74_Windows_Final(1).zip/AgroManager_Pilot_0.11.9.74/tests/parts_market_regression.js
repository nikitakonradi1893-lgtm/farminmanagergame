const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const EQUIP=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{},BY=Object.fromEntries(EQUIP.map(x=>[x.id,x]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function variants(m){return m?.type==='tractor'?(m.engineVariants||V[m.id]||[]):[]}
function stock(m){const vs=variants(m);return vs.find(x=>x.id===m.stockEngineId)||vs.find(x=>x.stock)||vs[0]}
function physical(e){return !!e&&e.kind!=='power_grade'}
function hw(e){return !physical(e)?0:Math.max(80000,Math.round((Number(e.swapCost)||0)*.78/10000)*10000)}
function labor(e){const h=Math.max(12,Number(e.swapHours)||36);return Math.max(90000,Math.round(h*4200/10000)*10000)}
function usedEnginePrice(e,cond,h){return Math.max(40000,Math.round(hw(e)*(.30+.0062*cond)*clamp(1-h/32000,.58,1)*.90/10000)*10000)}
function missingShellPrice(ready,e,cond,h){return Math.max(50000,Math.round((ready-usedEnginePrice(e,cond,h)-labor(e)*1.05)/10000)*10000)}
function dealerEnginePrice(e){return Math.round(hw(e)*1.08/10000)*10000}
const k=BY.k700;k.engineVariants=V.k700;k.stockEngineId='yamz238nb_220';const e220=variants(k).find(x=>x.id==='yamz238nb_220');assert(e220);
let checks=0;
for(const cond of [35,50,70,90])for(const h of [1000,7000,15000]){const ready=1200000+cond*11000;const shell=missingShellPrice(ready,e220,cond,h),used=usedEnginePrice(e220,cond,h),l=labor(e220),newp=dealerEnginePrice(e220);assert(shell+used+l<=ready+10000);checks++;assert(shell+l<ready);checks++;assert(shell+newp+l>=shell+used+l);checks++;}
// New dealer engine first-resource protection: half wear until 5000 h or first overhaul.
function effectiveEngineWearHours(start,hours,protectedFlag,overhauls){if(!protectedFlag||overhauls>0||start>=5000)return hours;const ph=Math.max(0,Math.min(hours,5000-start));return (hours-ph)+ph*.5}
assert.equal(effectiveEngineWearHours(0,1000,true,0),500);checks++;
assert.equal(effectiveEngineWearHours(4500,1000,true,0),750);checks++;
assert.equal(effectiveEngineWearHours(0,1000,true,1),1000);checks++;
assert.equal(effectiveEngineWearHours(5000,1000,true,0),1000);checks++;
// Catalog scope: only actual physical engines enter parts market.
const phys=[];const seen=new Set();for(const m of EQUIP){for(const e of variants(m)){if(physical(e)&&!seen.has(e.id)){seen.add(e.id);phys.push(e)}}}
assert(phys.length>10);checks++;
assert(phys.every(e=>hw(e)>0));checks++;
console.log(JSON.stringify({pass:true,checks,physicalEngineSkus:phys.length,k700:{engine:e220.name,hardware:hw(e220),labor:labor(e220),dealerNew:dealerEnginePrice(e220),used70pct7000h:usedEnginePrice(e220,70,7000)}},null,2));
