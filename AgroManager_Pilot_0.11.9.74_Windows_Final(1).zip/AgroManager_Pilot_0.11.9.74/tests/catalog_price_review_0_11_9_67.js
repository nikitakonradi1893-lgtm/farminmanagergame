const fs=require('fs'),vm=require('vm');
const box={window:{},console};vm.createContext(box);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),box);
const E=box.window.EQUIPMENT_CATALOG;let pass=0;
function ok(v,msg){if(!v)throw new Error(msg);pass++;}
// 0.11.9.65 screen candidates were manually reviewed in 0.11.9.74. The simple width*speed index
// ignores baler format, self-loading, precision systems, working depth and loader-tool capacity;
// therefore the 12 values are retained unless their own price ladder is internally contradictory.
const ids=['hay_sipma_z224','spr_jarmet_p1282_new','hay_fl902','szs21x3_new','szs21x5_new','szs21_new','tool_bigbag_hook','imp27','imp47','imp55','tool_wheel_grab35','imp16'];
for(const id of ids)ok(!!E.find(x=>x.id===id),`${id}: reviewed item missing`);
const sz=['szs21_new','szs21x3_new','szs21x5_new'].map(id=>E.find(x=>x.id===id));ok(sz[0].price<sz[1].price&&sz[1].price<sz[2].price,'SZS price ladder broken');
const tools=['tool_bigbag_hook','tool_bale_fork','tool_bucket_general10','tool_wheel_bulk30','tool_wheel_grab35'].map(id=>E.find(x=>x.id===id));ok(tools.every(Boolean),'loader tools missing');ok(tools[0].price<tools[2].price&&tools[2].price<tools[3].price&&tools[3].price<tools[4].price,'loader tool price ladder broken');
console.log(`catalog_price_review_0_11_9_67: ${pass} PASS`);
