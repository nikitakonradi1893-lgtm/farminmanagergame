const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8'),idx=fs.readFileSync('web/index.html','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
let checks=0;
// Human-readable durations keep decimal hours internal but never show them to the player.
const fmtCtx={Math,Number};vm.createContext(fmtCtx);vm.runInContext(fn('durationText'),fmtCtx);
assert.strictEqual(fmtCtx.durationText(.7),'42 мин');checks++;
assert.strictEqual(fmtCtx.durationText(3+23/60),'3 ч 23 мин');checks++;
assert.strictEqual(fmtCtx.durationText(36.7),'1 д 12 ч 42 мин');checks++;
assert.strictEqual(fmtCtx.durationText(1),'1 ч');checks++;
// Realtime clock accumulates real elapsed time into whole game minutes. At x5, 0.6 real seconds = 3 game minutes.
function makeClock(speed){const calls=[];const c={Math,Number,Date,state:{gameTime:0,criticalAlert:null},speed,lastReal:0,realtimeMinuteRemainderMs:0,realtimeAdvanceDepth:0};c.advanceSystems=(old,target)=>{calls.push([old,target]);return target};vm.createContext(c);vm.runInContext(fn('advanceRealtimeClock'),c);return{c,calls};}
let x=makeClock(5);x.c.advanceRealtimeClock(600,false);assert.strictEqual(x.c.state.gameTime,3*60000);assert.strictEqual(x.calls.length,3);assert(x.calls.every(([a,b])=>b-a===60000));checks+=3;
// At x60 the same model advances one game minute per logical realtime tick and catches all elapsed minutes.
x=makeClock(60);x.c.advanceRealtimeClock(100,false);assert.strictEqual(x.c.state.gameTime,6*60000);assert.strictEqual(x.calls.length,6);checks+=2;
// Exact intermediate events are not rounded to a minute boundary; automatic pause discards unused acceleration backlog.
x=makeClock(5);x.c.advanceSystems=(old,target)=>{x.calls.push([old,target]);if(target>=150000){x.c.state.criticalAlert={type:'test'};x.c.speed=0;return 150000}return target};x.c.advanceRealtimeClock(600,false);assert.strictEqual(x.c.state.gameTime,150000);assert.strictEqual(x.c.realtimeMinuteRemainderMs,0);checks+=2;
// Speed changes/pause first settle elapsed time at the previous speed, and the old 1-second jump loop is gone.
const setSpeed=fn('setGameSpeed');assert(setSpeed.includes('advanceRealtimeClock(now,true)'));checks++;
assert(!src.includes('setInterval(()=>{const now=Date.now(),elapsed=(now-lastReal)/1000'));checks++;
assert(src.includes('requestAnimationFrame(realtimeFrame)'));checks++;
assert(src.includes("version:'0.11.9.74'"));assert(idx.includes('PILOT 0.11.9.74')&&idx.includes('app.js?v=011974'));checks+=2;
for(const text of ['durationText(q.hours)','durationText(previewHours)','durationText(remain)','durationText(q.arrivalH)']){assert(src.includes(text),text);checks++;}
console.log(JSON.stringify({pass:true,checks,x5_600ms_minutes:3,x60_100ms_minutes:6,eventAtMinutes:2.5,duration36_7:'1 д 12 ч 42 мин'},null,2));
