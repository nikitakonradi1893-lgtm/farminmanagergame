const fs=require('fs'),vm=require('vm'),assert=require('assert');let checks=0;const ok=(v,m)=>{assert(v,m);checks++};
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG;const cats=new Set(['stubble','disk','plow','deepRip','cultivate','harrow']);const T=E.filter(x=>x.type==='implement'&&cats.has(x.category));
ok(T.length>=115,`physical tillage implements after de-dup: ${T.length}`);
ok(!T.some(x=>String(x.years)==='1980,2018'),'no legacy 1980-2018 placeholder years');
const norm=n=>n.toLowerCase().replace(/\s*\(б\/у\)\s*/g,'').replace(/×/g,'x').replace(/\s+/g,' ').trim();const seen=new Set();for(const x of T){const k=norm(x.name);ok(!seen.has(k),'no physical duplicate: '+x.name);seen.add(k)}
const M=id=>E.find(x=>x.id===id);ok(M('bdm24x2_new')?.years?.[0]===2006&&M('bdm24x2_new')?.newAvailable,'BDM 2.4 consolidated');
ok(M('bdm4x2_new')?.years?.[0]===2008&&M('bdm4x2_new')?.newAvailable,'BDM 4 consolidated');
ok(M('bdm32x4_new')?.years?.[0]===2008&&M('bdm32x4_new')?.newAvailable,'BDM 3.2x4 consolidated');
ok(M('bdm6x4_used')?.segment==='domestic_new'&&M('bdm6x4_used')?.newAvailable,'BDM 6x4 consolidated current model');
ok(M('lemken_juwel8_used')?.years?.[0]===2013&&M('lemken_juwel8_used')?.newAvailable,'Juwel single current record');
ok(M('lemken_diamant16_new')?.years?.[0]===2019,'Diamant modern era');
ok(M('imp10')?.years?.[0]===2014,'Cenius 5003-2TX launch era');
ok(M('imp20')?.years?.[0]===2007,'Joker RT era');
ok(M('imp7')?.years?.[0]===2003,'Terrano FX era');
ok(M('imp29')?.years?.[0]>=2014,'Kverneland 2500 i-Plough modern era');
console.log(`Tillage final audit 0.11.9.47: ${checks}/${checks} PASS`);
