'use strict';
const fs=require('fs'),vm=require('vm');let checks=0;function ok(x,msg){checks++;if(!x)throw new Error(msg)}
const eq=fs.readFileSync('web/equipment.js','utf8'),app=fs.readFileSync('web/app.js','utf8'),ctx={window:{}};vm.createContext(ctx);vm.runInContext(eq,ctx);const C=ctx.window.EQUIPMENT_CATALOG,by=id=>C.find(x=>x.id===id);
ok(app.includes("version:'0.11.9.74'"),'runtime version');
for(const id of ['ural5557_agro','ural_next_58314s','zil45065'])ok(!!by(id),id+' exists');
const z=by('zil45065');ok(z.capacityT===5.7,'ZIL-45065 payload 5.7t');ok(z.bodyConfigs.some(x=>x.stock&&x.bodyM3===6),'ZIL stock 6m3');ok(z.bodyConfigs.some(x=>x.id==='ext'&&x.bodyM3===12.5),'ZIL extension 12.5m3');
const u=by('ural5557_agro'),un=by('ural_next_58314s'),sz=by('szap8551_ural');ok(u.capacityT===7,'old Ural payload');ok(un.capacityT===10.5,'Ural NEXT payload');ok(sz?.truckTrailer,'SZAP road trailer');ok(sz.truckTrailerFor.includes('ural5557_agro')&&sz.truckTrailerFor.includes('ural_next_58314s'),'SZAP compatible with both Urals');ok(sz.bodyConfigs.some(x=>x.bodyM3===18.8),'SZAP high body 18.8m3');
const tractors=['kamaz5410_tractor','maz5432_tractor','volvo_fh12_420_tractor','scania_r420_tractor','kamaz54901_tractor','maz5440c9_tractor','man_tgx18520_tractor','volvo_fh_aero500_tractor'];
for(const id of tractors){const m=by(id);ok(!!m,id+' exists');ok(m.tractorUnit===true,id+' tractorUnit');ok(m.agCargoEligible===false,id+' no standalone grain body');ok(m.capacityT===0,id+' zero standalone payload');}
const semis=['odaz9370_grain','tonar9523_used','wielton_nw3_grain_used','stas_agrostar_used','maz934700_grain','tonar9523_al_grain','stas_agrostar_new','sespel_db4u70'];
for(const id of semis){const m=by(id);ok(!!m,id+' exists');ok(m.truckTrailer===true,id+' truck trailer');ok(m.semiTrailer===true,id+' semi-trailer');ok(Array.isArray(m.truckTrailerFor)&&m.truckTrailerFor.length>0,id+' compatible tractor units');}
for(const seg of ['domestic_used','domestic_new','foreign_used','foreign_new'])ok(tractors.some(id=>by(id).segment===seg),'tractor-unit segment '+seg);
for(const seg of ['domestic_used','domestic_new','foreign_used','foreign_new'])ok(semis.some(id=>by(id).segment===seg),'semi-trailer segment '+seg);
ok(app.includes("if(!m.tractorUnit)out.push"),'tractor units cannot run standalone cargo');ok(app.includes("fifthWheel:!!rm.semiTrailer"),'fifth-wheel pairing marked');
console.log(`Road transport expansion 0.11.9.74: ${checks}/${checks} PASS`);
