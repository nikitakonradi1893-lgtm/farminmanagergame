const fs=require('fs'),vm=require('vm'),assert=require('assert');
function storage(){return{getItem(){return null},setItem(){},remove(){},removeItem(){}}}
const document={getElementById(){return{textContent:'',classList:{add(){},remove(){}},innerHTML:'',addEventListener(){},style:{}}},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){},body:{classList:{add(){},remove(){}}}};
class XHR{open(){}send(){}setRequestHeader(){}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`t-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__t={CONFIG,EQUIP,equipmentModel,headerCompatible,headerWorkRate,ownedUnitOptions,contractorCatalogUnits,newAsset,freshState,get state(){return state},set state(v){state=v}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__t;
let n=0;const ok=(v,m)=>{assert(v,m);n++};
ok(a.CONFIG.version==='0.11.9.74','version');
const windrowHeads=a.EQUIP.filter(m=>m.type==='header'&&m.category==='grain_windrow');
ok(windrowHeads.length===3,'three combine-mounted grain windrow headers');
for(const id of ['zhvn6a','zhvn6v','zhn6b_don']){const h=a.equipmentModel(id);ok(h?.type==='header'&&h.category==='grain_windrow',`${id} is header, not tractor implement`);}
const expected={
 zhvn6a:['sk5','enisey1200'],
 zhvn6v:['sk5','nivaeffect','enisey1200','enisey950'],
 zhn6b_don:['don1200','don1500a','don1500b']
};
for(const [hid,cids] of Object.entries(expected))for(const cid of cids)ok(a.headerCompatible(a.equipmentModel(cid),a.equipmentModel(hid)),`${hid} compatible with ${cid}`);
ok(!a.headerCompatible(a.equipmentModel('jd9500_used'),a.equipmentModel('zhvn6a')),'old JD does not get Soviet header by default');
const legacySelf=['kps5g_grain','fortschritt_e303_grain','versatile_4400_grain','hesston_8100_grain'];
for(const id of legacySelf){const m=a.equipmentModel(id);ok(m?.type==='implement'&&m.selfPropelled&&m.category==='grain_windrower'&&m.grainWindrow===true,`${id} self-propelled grain windrower`);ok(m.segment.endsWith('_used'),`${id} is used-market segment`);}
const oldPrices=legacySelf.map(id=>a.equipmentModel(id).price);ok(Math.max(...oldPrices)<5000000,'historical self-propelled tier stays below 5M');
ok(a.equipmentModel('kps5g_grain').price<a.equipmentModel('rsm_ksu1').price/8,'KPS-5G creates cheap domestic entry');
ok(a.equipmentModel('hesston_8100_grain').price<a.equipmentModel('hay_macdon_m1170').price/5,'old foreign swather creates cheap foreign entry');
// Picker must expose both combine+windrow-header and dedicated self-propelled windrowers.
a.state=a.freshState('very_hard');a.state.gameTime=new Date(2026,7,15,10).getTime();let f=a.state.fields.find(x=>x.owned);if(!f){f=a.state.fields[0];f.owned=true;f.tenure='owned';}f.crop='spring_wheat';f.plantedAt=new Date(2026,3,5).getTime();f.ha=100;f.moisture=50;
const sk5=a.equipmentModel('sk5'),zh=a.equipmentModel('zhvn6a'),kps=a.equipmentModel('kps5g_grain');const ca=a.newAsset(sk5,'used',{condition:80,purchasedAt:a.state.gameTime}),ha=a.newAsset(zh,'used',{condition:80,purchasedAt:a.state.gameTime}),wa=a.newAsset(kps,'used',{condition:80,purchasedAt:a.state.gameTime});a.state.equipment.fleet=[ca,ha,wa];const units=a.ownedUnitOptions(f,'grainWindrow','spring_wheat');
ok(units.some(u=>u.models.some(m=>m.id==='sk5')&&u.models.some(m=>m.id==='zhvn6a')),'owned picker offers SK-5 + ZHVN-6A');
ok(units.some(u=>u.models.some(m=>m.id==='kps5g_grain')),'owned picker offers KPS-5G dedicated unit');
const contracts=a.contractorCatalogUnits('grainWindrow','spring_wheat');ok(contracts.some(u=>u.models.some(m=>m.type==='combine')&&u.models.some(m=>m.category==='grain_windrow')),'contractor catalog includes combine + windrow header');ok(contracts.some(u=>u.models.some(m=>m.id==='hesston_8100_grain')),'contractor catalog includes historical self-propelled swather');
console.log(JSON.stringify({pass:true,checks:n,windrowHeaders:windrowHeads.length,selfPropelledLegacy:legacySelf.length,ownedOptions:units.map(u=>u.label),cheapDomestic:a.equipmentModel('kps5g_grain').price,cheapForeign:a.equipmentModel('fortschritt_e303_grain').price},null,2));
