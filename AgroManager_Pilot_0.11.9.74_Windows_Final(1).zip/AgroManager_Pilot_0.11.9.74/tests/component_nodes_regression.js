const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const E=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{},BY=Object.fromEntries(E.map(x=>[x.id,x]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const C={
 k700:{transmission:[['stock',260,420000,30],['reinforced',420,780000,42],['heavy',520,1180000,56]],running:[['stock',300,360000,28],['reinforced',460,690000,38]],hydraulics:[['stock',320,240000,20],['reinforced',480,470000,30]]},
 k701:{transmission:[['stock',330,520000,32],['reinforced',450,880000,44]],running:[['stock',350,450000,30],['reinforced',470,760000,40]],hydraulics:[['stock',350,280000,20],['reinforced',460,520000,30]]},
 t150k:{transmission:[['stock',185,300000,26],['reinforced',260,560000,36]],running:[['stock',200,240000,24],['reinforced',270,430000,32]],hydraulics:[['stock',210,180000,16],['reinforced',270,330000,24]]}
};
function stress(hp,rated,key){const overload=Math.max(0,hp/Math.max(1,rated)-1),k=key==='transmission'?.48:key==='running'?.30:.20;return Math.min(key==='transmission'?1.45:key==='running'?1.30:1.20,1+overload*k)}
function labor(hours){return Math.max(60000,Math.round(hours*3800/10000)*10000)}
let checks=0;
const k=BY.k700;const vars=V.k700;assert(k&&vars.length===13);checks++;
for(const hp of [220,235]){assert(stress(hp,260,'transmission')<=1.0+1e-9);checks++;} assert(stress(300,260,'transmission')<1.08);checks++;
assert(stress(400,260,'transmission')>1.20);checks++;
assert.strictEqual(stress(400,420,'transmission'),1);checks++;
assert.strictEqual(stress(400,460,'running'),1);checks++;
assert.strictEqual(stress(400,480,'hydraulics'),1);checks++;
assert.strictEqual(stress(500,520,'transmission'),1);checks++;
assert(stress(500,460,'running')<1.03);checks++;
const upgradeCost=C.k700.transmission[1][2]+labor(C.k700.transmission[1][3])+C.k700.running[1][2]+labor(C.k700.running[1][3])+C.k700.hydraulics[1][2]+labor(C.k700.hydraulics[1][3]);
assert(upgradeCost>1800000&&upgradeCost<2800000);checks++;
const transUsed={condition:72,hours:7200,price:C.k700.transmission[1][2]};
const resale=Math.round(transUsed.price*(.22+.0068*transUsed.condition)*clamp(1-transUsed.hours/35000,.58,1)*.84/10000)*10000;
assert(resale>250000&&resale<C.k700.transmission[1][2]);checks++;
const firstInstall=C.k700.transmission[1][2]+labor(C.k700.transmission[1][3]);
const reinstall=labor(C.k700.transmission[1][3]);assert(reinstall<firstInstall*.25);checks++;
console.log(JSON.stringify({pass:true,checks,k700:{stock400:{transmission:+stress(400,260,'transmission').toFixed(3),running:+stress(400,300,'running').toFixed(3),hydraulics:+stress(400,320,'hydraulics').toFixed(3)},reinforced400:{transmission:stress(400,420,'transmission'),running:stress(400,460,'running'),hydraulics:stress(400,480,'hydraulics')},heavy500:{transmission:stress(500,520,'transmission'),running:+stress(500,460,'running').toFixed(3),hydraulics:+stress(500,480,'hydraulics').toFixed(3)},fullReinforcementCost:upgradeCost,reinstallTransmissionLabor:reinstall,usedTransmissionResale:resale}},null,2));
