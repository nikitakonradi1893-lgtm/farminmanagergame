const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){},contains(){return false}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}},scrollIntoView(){}}}
const elems=new Map(),document={activeElement:{tagName:'BODY',dataset:{},isContentEditable:false},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){},removeItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`c-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,cancelAnimationFrame(){},scrollX:0,scrollY:0,scrollTo(){},scrollBy(){},window:null};ctx.window=ctx;
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__c54={CONFIG,INFRA_LEVELS,freshState,infraSpec,ownCleaningQuote,cleaningQuote,get state(){return state},set state(v){state=v}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__c54;
let checks=0;const ok=(x,m)=>{assert(x,m);checks++};
ok(a.CONFIG.version==='0.11.9.74','version');
a.state=a.freshState('normal');
const lot={crop:'spring_wheat',tons:100,dockagePct:4.0,quality:{score:70}};
const expected=[55,45,38,32,28],actual=[];
for(let level=1;level<=5;level++){
  a.state.infrastructure.cleanerLevel=level;
  const sp=a.infraSpec('cleaner'),q=a.ownCleaningQuote(lot);
  const cpt=sp.energyPerTon+sp.consumablesPerTon+sp.helperLaborPerTon;
  actual.push(cpt);
  ok(q.available,`cleaner level ${level} available`);
  ok(q.costPerTon===expected[level-1],`level ${level} variable cost per ton`);
  ok(q.cost===Math.round(lot.tons*q.costPerTon),`level ${level} charges variable cost`);
  ok(q.helperLaborPerTon>0,`level ${level} embeds helper labor`);
  ok(q.costPerTon<120&&q.costPerTon>0,`level ${level} below contractor but nonzero`);
  ok(q.hours>0,`level ${level} has physical processing time`);
}
for(let i=1;i<actual.length;i++)ok(actual[i]<=actual[i-1],'larger cleaner has scale economy');
// Own cleaning must not depend on a selectable employee or staff assignment.
a.state.staff={employees:[]};a.state.infrastructure.cleanerLevel=2;const qNoStaff=a.ownCleaningQuote(lot);ok(qNoStaff.available&&qNoStaff.cost===4500,'own cleaner works with no assigned employee');
ok(!('workerId' in qNoStaff)&&!('employeeId' in qNoStaff),'quote has no selectable worker field');
// Contractor comparison and revised break-even volumes using game capex/maintenance.
const rate=.115,years=10,crf=rate*Math.pow(1+rate,years)/(Math.pow(1+rate,years)-1),breakEven=[];
for(let level=1;level<=5;level++){
  const sp=a.INFRA_LEVELS.cleaner[level],fixed=sp.cost*crf+sp.maint*12,saving=120-(sp.energyPerTon+sp.consumablesPerTon+sp.helperLaborPerTon),tons=fixed/saving;breakEven.push(Math.round(tons));ok(tons>0&&Number.isFinite(tons),`level ${level} break-even finite`);
}
ok(breakEven[0]>2500,'small cleaner no longer breaks even near old zero-variable-cost threshold');
// Land NPV invariant from current game constants: purchase only slightly better than lease at 11.5% and flat terminal land value.
const pv=(x,t)=>x/Math.pow(1+rate,t),purchase=50000,lease=5000,entry=.10*purchase;
for(const horizon of [5,10,15]){let buy=purchase-pv(purchase,horizon),rent=entry+lease;for(let y=1;y<horizon;y++)rent+=pv(lease,y);const edge=rent-buy;ok(edge>2500&&edge<6000,`land NPV edge modest at ${horizon}y`);}
console.log(JSON.stringify({pass:true,checks,cleanerCostPerTon:actual,breakEvenTons:breakEven},null,2));
