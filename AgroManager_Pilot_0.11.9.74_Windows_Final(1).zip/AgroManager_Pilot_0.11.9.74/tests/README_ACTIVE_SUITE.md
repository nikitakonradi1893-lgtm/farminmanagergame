# Active test suite policy

The `tests/` folder contains tests that remain useful against the current game. Historical/superseded harnesses are not carried forward merely for archival purposes.

Release version/cache ownership belongs primarily to:
- `technical_integrity_audit.js`
- `project_continuity_rules_0_11_9_09.js`
- `fresh_game_version_policy_0_11_9_20.js`

Current high-level persistent economic/progression tests:
- `full_farm_economy_harness_0_11_9_55.js`
- `progression_bottleneck_0_11_9_55.js`
- `cleaner_variable_cost_land_roi_0_11_9_54.js`
- `root_market_capacity_0_11_9_53.js`
- harvest/service/land regressions retained where they still cover unique mechanics.

Use `tools/bump_release.py <version>` when preparing a new release.
