const fs=require('fs');
const assert=require('assert');
const ctx=fs.readFileSync('PROJECT_CONTEXT.md','utf8');
const app=fs.readFileSync('web/app.js','utf8');
const idx=fs.readFileSync('web/index.html','utf8');
let checks=0;
function ok(v,m){assert(v,m);checks++;}
ok(app.includes("version:'0.11.9.74'"),'runtime version');
ok(idx.includes('PILOT 0.11.9.74')&&idx.includes('app.js?v=011974'),'html/cache version');
ok(ctx.includes('Mandatory development continuity rules'),'continuity rules section');
ok(ctx.includes('Context is mandatory in every release'),'context persistence rule');
ok(ctx.includes('Always ship the complete current game'),'complete release rule');
ok(ctx.includes('Google Drive checkpoint every three releases'),'drive cadence rule');
ok(/Releases counted since the last mandatory Drive checkpoint: \*\*(?:[0-3]\/3[^*]*)\*\*/.test(ctx),'drive checkpoint state for current release');
ok(ctx.includes('Mandatory cross-surface impact scan before implementation'),'impact scan rule');
ok(ctx.includes('Impact consistency is a release gate'),'impact release gate');
ok(ctx.includes('Pending Drive upload: **none**'),'drive pending/completed state');
ok(fs.existsSync('AgroManager_Pilot_PROJECT_CONTEXT_0.11.9.74.md'),'versioned context duplicate');
console.log(`project continuity rules: ${checks}/${checks} PASS`);
