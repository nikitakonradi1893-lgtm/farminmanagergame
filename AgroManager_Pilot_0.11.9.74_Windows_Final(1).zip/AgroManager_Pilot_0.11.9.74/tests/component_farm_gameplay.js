const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx,{filename:'equipment.js'});
const E=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{},BY=Object.fromEntries(E.map(x=>[x.id,x]));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const k=BY.k700;k.engineVariants=V.k700;
const e400=V.k700.find(x=>x.id==='yamz7511_400'),e220=V.k700.find(x=>x.id==='yamz238nb_220');assert(e400&&e220);
const rip=E.filter(m=>m.type==='implement'&&m.category==='deepRip'&&(m.requiredHp||0)<=400).sort((a,b)=>(b.width*b.speed*(b.eff||.78))-(a.width*a.speed*(a.eff||.78)))[0];assert(rip);
function rate(im){return im.width*im.speed*(im.eff||.78)/10}
function fuelFactor(req,hp){const load=clamp(req/hp,0,1),pts=[[0,.18],[.25,.33],[.5,.55],[.75,.80],[1,1]];for(let i=1;i<pts.length;i++)if(load<=pts[i][0]){let [x0,y0]=pts[i-1],[x1,y1]=pts[i],t=(load-x0)/(x1-x0);return y0+(y1-y0)*t}return 1}
function fuelLph(e,im){const base=e.fuelLph*fuelFactor(im.requiredHp,e.hp),reserve=Math.max(0,e.hp/im.requiredHp-1);return base*(1+Math.min(.16,reserve*.09))}
function stress(hp,rated,key){const overload=Math.max(0,hp/rated-1),kk=key==='transmission'?.48:key==='running'?.30:.20;return Math.min(key==='transmission'?1.45:key==='running'?1.30:1.20,1+overload*kk)}
function run(cfg){let systems={engine:92,transmission:82,running:82,hydraulics:84},failures=0,repairCost=0,diesel=0,hoursTotal=0;const area=1000,years=5,r=rate(rip),h=area/r;for(let y=0;y<years;y++){hoursTotal+=h;diesel+=h*fuelLph(e400,rip);const base=.022*h;systems.engine-=base;systems.transmission-=base*1.35*stress(400,cfg.trans,'transmission');systems.running-=base*1.22*stress(400,cfg.running,'running');systems.hydraulics-=base*.82*stress(400,cfg.hyd,'hydraulics');for(const key of Object.keys(systems)){if(systems[key]<58){failures++;const target=key==='engine'?88:86;const deficit=target-systems[key];repairCost+=Math.max(50000,1650000*(.055+.00035*deficit)*.78*.9);systems[key]=target;}}}
return{hoursTotal,diesel,failures,repairCost,systems,r};}
const stock=run({trans:260,running:300,hyd:320}),reinforced=run({trans:420,running:460,hyd:480});
const upgradeCapex=780000+160000+690000+140000+470000+110000;
assert(stock.failures>=reinforced.failures);assert(stock.systems.transmission<reinforced.systems.transmission);assert(reinforced.repairCost<=stock.repairCost);
// Reinforcement must not be a free-money choice on only 1000 ha/year: saved repairs alone should not repay full capex in five seasons.
assert(stock.repairCost-reinforced.repairCost<upgradeCapex);
console.log(JSON.stringify({pass:true,scenario:'1000 га глубокорыхления ежегодно, 5 сезонов, К-700 400 л.с.',implement:rip.name,requiredHp:rip.requiredHp,rateHaH:+stock.r.toFixed(2),hours5y:+stock.hoursTotal.toFixed(1),diesel5y:+stock.diesel.toFixed(0),upgradeCapex,stock:{failures:stock.failures,repairCost:Math.round(stock.repairCost),endSystems:Object.fromEntries(Object.entries(stock.systems).map(([k,v])=>[k,+v.toFixed(1)]))},reinforced:{failures:reinforced.failures,repairCost:Math.round(reinforced.repairCost),endSystems:Object.fromEntries(Object.entries(reinforced.systems).map(([k,v])=>[k,+v.toFixed(1)]))},repairSavings:Math.round(stock.repairCost-reinforced.repairCost)},null,2));
