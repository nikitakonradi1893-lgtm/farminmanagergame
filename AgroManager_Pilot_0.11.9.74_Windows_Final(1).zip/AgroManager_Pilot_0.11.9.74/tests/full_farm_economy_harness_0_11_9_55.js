const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',disabled:false,open:false,dataset:{},style:{},classList:{toggle(){},add(){},remove(){},contains(){return false}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0}},scrollIntoView(){}}}
const elems=new Map();const document={activeElement:{tagName:'BODY',dataset:{},isContentEditable:false},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelectorAll(){return[]},querySelector(){return null},addEventListener(){}};
const storage=()=>({getItem(){return null},setItem(){}});class XHR{open(){}send(){this.status=404;this.responseText=''}getResponseHeader(){return null}}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:()=>`ff-${Math.random()}`},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},body:null,json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,requestAnimationFrame:()=>1,cancelAnimationFrame(){},scrollX:0,scrollY:0,scrollTo(){},scrollBy(){},window:null};ctx.window=ctx;
vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');
src=src.slice(0,pos)+`\nwindow.__ff={CROPS,SEEDS,FERTS,OPS,CONFIG,INFRA_LEVELS,LEASE_TERMS,targetNutrientPlan,contractorCropCostMultiplier,rotationPredecessorFactor,macroBaseRate,freshState,get state(){return state},set state(v){state=v},cropMarketPrice,salePointsForSeed,salePointPrice,rootBuyerCapacity,rootVolumeAverageFactor};\n`+src.slice(pos);
vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__ff;a.state=a.freshState('normal');
const E=ctx.window.EQUIPMENT_CATALOG||[];const model=id=>E.find(x=>x.id===id);
function rng(seed){let x=seed>>>0;return()=>((x=Math.imul(x,1664525)+1013904223>>>0)/4294967296)}
function annuity(p,r,n){const m=r/12;return p*m/(1-Math.pow(1+m,-n))}
function cropBase(k){const c=a.CROPS[k],seed=a.SEEDS[k],f={ha:1,crop:null,yieldTargets:{[k]:c.baseYield},soil:{type:'Суглинок',ph:6.1,N:48,P:42,K:48,organicMatter:2.6,strawNPool:0},soilTest:{status:'done',completedAt:Date.now()},lastCrop:'peas',moisture:55};const plan=a.targetNutrientPlan(f,k);let fert=0,apps=0;for(const z of plan.steps){const fd=a.FERTS[z.op];if(fd){fert+=z.dose*fd.price;apps++;}}let ops,log;if(['perennial_grass','alfalfa','clover'].includes(k)){ops=1700+1800+2500+apps*900+2*(1700+950+900+1500+1200);log=1200;}else{const sow=2500*a.contractorCropCostMultiplier('sow',k),har=3500*a.contractorCropCostMultiplier('harvest',k);ops=1700+1800+sow+har+apps*900+1100*1.8;log=c.baseYield*.88*(230+20*13);}const seedCost=seed.rate*seed.price/(c.standYears||1);return{seedCost,fert,ops,log,baseRevenue:c.baseYield*c.price*.88,baseYield:c.baseYield,price:c.price};}
const CBASE=Object.fromEntries(Object.keys(a.CROPS).filter(k=>a.CROPS[k].fieldCrop!==false&&!['perennial_grass','alfalfa','clover'].includes(k)).map(k=>[k,cropBase(k)]));
const rotations={
 grain:['winter_wheat','barley','peas','rapeseed'],
 diversified:['winter_wheat','peas','rapeseed','soybean','barley','oil_flax'],
 root_heavy:['potato','winter_wheat','sugar_beet','barley','peas']
};
const baseOld=(model('mtz82')?.price||850000)+(model('k700')?.price||1650000)+(model('don1500b')?.price||2600000)+3300000;
const baseModern=(model('bel821')?.price||2661000)+(model('jd6r215')?.price||24500000)+(model('torum785')?.price||36500000)+20000000;
const baseMixed=(model('mtz82')?.price||850000)+(model('jd6r215')?.price||24500000)+(model('acros550')?.price||17500000)+8500000;
const rootOld=(model('root_sn4b_used')?.price||240000)+(model('root_kku2a_used')?.price||950000)+(model('root_rks6_used')?.price||1250000);
const rootMixed=(model('pot_sn4bm_new')?.price||1150000)+(model('root_ksp4')?.price||4200000)+(model('root_ks6b_new')?.price||5600000);
const rootModern=(model('imp100')?.price||4900000)+(model('root_varitron470')?.price||24500000)+(model('root_ropa_panther')?.price||36000000);
const strategies={
 contractor:{capex:0,finance:'none',ownOpFactor:1,windowFloor:.97,staffBase:0,fixedRate:120000},
 old:{capex:baseOld,finance:'cash',ownOpFactor:.62,windowFloor:.80,staffBase:1,fixedRate:.045},
 mixed:{capex:baseMixed,finance:'loan50',ownOpFactor:.52,windowFloor:.90,staffBase:2,fixedRate:.042},
 modern_lease:{capex:baseModern,finance:'lease',ownOpFactor:.43,windowFloor:.96,staffBase:3,fixedRate:.035}
};
function capexFor(st,rotation){const root=rotation==='root_heavy';if(!root)return st.capex;if(st===strategies.old)return st.capex+rootOld;if(st===strategies.mixed)return st.capex+rootMixed;if(st===strategies.modern_lease)return st.capex+rootModern;return 0;}
function staffAnnual(area,st,r){if(st.staffBase===0)return area>=1000?Math.round((1+Math.floor(area/1500))*72000*4*1.25):Math.round(area/100*120000);const need=st.staffBase+Math.max(0,Math.floor(area/900));const perm=Math.max(0,need-1);const seasonal=1;return perm*72000*12+seasonal*72000*3*1.25;}
function initialInfra(rotation,area){let cost=0,maint=0,rootLevel=0,grainLevel=0;if(rotation==='root_heavy'){
 const level=area<=100?1:area<=500?2:area<=1500?3:4; rootLevel=level; const s=a.INFRA_LEVELS.vegetable[level];cost+=s.cost;maint+=s.maint*12;
 } else {const level=area<=100?0:area<=500?1:area<=1500?2:area<=3000?3:4;grainLevel=level;const s=a.INFRA_LEVELS.grain[level];cost+=s.cost;maint+=s.maint*12;}
 if(area>=1500){const d=a.INFRA_LEVELS.dryer[area>=3000?2:1];cost+=d.cost;maint+=d.maint*12;}
 return{cost,maint,rootLevel,grainLevel};}
function bestSaleValue(k,year,infra,tons){const isRoot=k==='potato'||k==='sugar_beet',levels=isRoot?a.INFRA_LEVELS.vegetable:a.INFRA_LEVELS.grain,sp=isRoot?levels[(infra.rootLevel??0)]:levels[(infra.grainLevel??0)];if(!isRoot){let best=-Infinity;for(let m=0;m<=5;m++){const month=8+m,ts=Date.UTC(year+Math.floor(month/12),month%12,15),loss=Math.pow(1-Math.max(0,sp?.lossPct||0)/100,m),fee=Math.max(0,sp?.storagePerT||0)*m;best=Math.max(best,(a.cropMarketPrice(k,ts)*loss-fee)*tons);}return best;}let best=-Infinity;for(let m=0;m<=5;m++){const month=8+m,ts=Date.UTC(year+Math.floor(month/12),month%12,15),loss=Math.pow(1-Math.max(0,sp?.lossPct||0)/100,m),fee=Math.max(0,sp?.storagePerT||0)*m,available=tons*loss,pts=a.salePointsForSeed(a.state.landSeed).filter(p=>String(p.id).startsWith('root_')),tranches=[];for(const pt of pts){const cap=a.rootBuyerCapacity(k,pt,ts),base=a.salePointPrice(k,pt,70),haul=230+pt.distanceKm*13,bands=[[0,1],[1,1.5],[1.5,2.5],[2.5,4],[4,Math.max(4,4+available/cap)]];for(const [lo,hi] of bands){const qty=(hi-lo)*cap;if(qty<=0)continue;const vf=a.rootVolumeAverageFactor(lo*cap,qty,cap),net=base*vf-haul-fee;tranches.push({qty,net});}}tranches.sort((x,y)=>y.net-x.net);let left=available,value=0;for(const t of tranches){if(left<=.001)break;const q=Math.min(left,t.qty);value+=q*t.net;left-=q;}best=Math.max(best,value);}return best;}
function run(area,rotationKey,strategyKey,seed,years=15,mode='established'){const r=rng(seed*7919+area*17+rotationKey.length*101+strategyKey.length*1009),rot=rotations[rotationKey],st=strategies[strategyKey],infra=initialInfra(rotationKey,area),capex=capexFor(st,rotationKey)+infra.cost;let cash=mode==='established'?Math.max(10_000_000,area*30000):10_000_000,debt=0,leaseResidual=0,monthly=0,debtMonths=0,bankrupt=false,minCash=cash,peakDebt=0,lateLoss=0,totalProfit=0,totalRevenue=0,totalCosts=0;
 if(mode==='progression'){if(strategyKey==='contractor'){cash-=infra.cost;}else if(st.finance==='cash'){cash-=capex;}else if(st.finance==='loan50'){const down=capex*.5;cash-=down;debt=capex-down;monthly=annuity(debt,a.macroBaseRate(2026)+.05,36);debtMonths=36;}else if(st.finance==='lease'){const down=capex*a.LEASE_TERMS.downRate;cash-=down;debt=capex-down;leaseResidual=capex*a.LEASE_TERMS.residualRate;monthly=annuity(debt,a.macroBaseRate(2026)+a.LEASE_TERMS.margin,48);debtMonths=48;}}
 peakDebt=debt;
 for(let y=0;y<years&&!bankrupt;y++){
   const year=2026+y;a.state.landSeed=(seed*2654435761+y*977)>>>0;a.state.gameTime=Date.UTC(year,8,15);
   let revenue=0,cost=0;const weather=.82+r()*.28; // common season shock
   for(let i=0;i<rot.length;i++){
     const k=rot[(i+y)%rot.length],prev=rot[(i+y-1+rot.length)%rot.length],b=CBASE[k],share=1/rot.length,ha=area*share,rotF=a.rotationPredecessorFactor(prev,k),cropWeather=Math.max(.68,Math.min(1.12,weather+((r()-.5)*.10))),yieldT=b.baseYield*rotF*cropWeather*.88;
     const rev=bestSaleValue(k,year,infra,yieldT*ha); revenue+=rev;
     const nonOps=(b.seedCost+b.fert)*ha;
     let ops=b.ops*ha,log=(yieldT/Math.max(.1,b.baseYield*.88))*b.log*ha;
     if(strategyKey!=='contractor')ops*=st.ownOpFactor; else ops*=1+Math.min(.10,area/30000);
     // Root-heavy harvesting still pays very high material/logistics even with own machinery.
     cost+=nonOps+ops+log;
   }
   const util=area/(strategyKey==='contractor'?1e9:strategyKey==='old'?850:strategyKey==='mixed'?1700:3300);const window=Math.max(st.windowFloor,1-Math.max(0,util-1)*.16);const windowPenalty=revenue*(1-window);lateLoss+=windowPenalty;revenue-=windowPenalty;
   const machineryFixed=strategyKey==='contractor'?st.fixedRate:capexFor(st,rotationKey)*st.fixedRate;const capitalCharge=mode==='established'&&strategyKey!=='contractor'?capexFor(st,rotationKey)*.04:0;cost+=machineryFixed+capitalCharge+staffAnnual(area,st,r)+infra.maint+a.CONFIG.leaseAnnualPerHa*area;
   // random repair shock uses strategy age/complexity profile; failures matter more when capacity is tight.
   if(strategyKey!=='contractor'){const p=strategyKey==='old'?.34:strategyKey==='mixed'?.22:.14;if(r()<p){const repair=(strategyKey==='old'?0.018:strategyKey==='mixed'?0.012:.009)*capexFor(st,rotationKey)*(0.55+r()*.9);const downtime=strategyKey==='old'?3+r()*6:strategyKey==='mixed'?2+r()*4:1+r()*2;const lost=revenue*Math.min(.12,(downtime/30)*Math.max(.4,util));cost+=repair;revenue-=lost;lateLoss+=lost;}}
   if(mode==='progression')for(let m=0;m<12;m++){if(debtMonths>0){cost+=monthly;const interest=debt*((a.macroBaseRate(year)+(st.finance==='lease'?a.LEASE_TERMS.margin:.05))/12);debt=Math.max(0,debt-(monthly-interest));debtMonths--;}}
   if(mode==='progression'&&st.finance==='lease'&&debtMonths===0&&leaseResidual>0){cost+=leaseResidual;leaseResidual=0;}
   cash+=revenue-cost;totalProfit+=revenue-cost;totalRevenue+=revenue;totalCosts+=cost;minCash=Math.min(minCash,cash);peakDebt=Math.max(peakDebt,debt);
   // Crisis liquidity: secured bridge only up to game-like modest operating capacity; beyond that bankruptcy.
   const rescue=mode==='established'?Math.max(5_000_000,area*20000):Math.min(5_000_000,1_500_000+area*18000);if(cash<0&&cash>-rescue){debt+=-cash;cash=0;}else if(cash<=-rescue){bankrupt=true;}
 }
 const residual=strategyKey==='contractor'?0:capexFor(st,rotationKey)*(strategyKey==='old'?.18:strategyKey==='mixed'?.28:.40);const equity=cash+residual+infra.cost*.55-debt;return{bankrupt,equity,minCash,lateLoss,totalProfit,totalRevenue,totalCosts,endingDebt:debt};}
const areas=[100,750,3000],seeds=120,years=15,results={};let checks=0;
for(const area of areas){results[area]={};for(const rot of Object.keys(rotations)){results[area][rot]={};for(const sk of Object.keys(strategies)){const arr=[];for(let s=1;s<=seeds;s++)arr.push(run(area,rot,sk,s,years,'established'));const bankrupt=arr.filter(x=>x.bankrupt).length,eq=arr.map(x=>x.equity).sort((a,b)=>a-b),avg=x=>arr.reduce((z,v)=>z+v[x],0)/arr.length;results[area][rot][sk]={bankruptPct:+(bankrupt/seeds*100).toFixed(1),medianEquity:Math.round(eq[Math.floor(eq.length/2)]),avgProfit:Math.round(avg('totalProfit')/years),avgLateLoss:Math.round(avg('lateLoss')/years),worstMinCash:Math.round(Math.min(...arr.map(x=>x.minCash)))};checks++;}}}
// Structural checks: oversized modern fleet should be risky at 100 ha; root-heavy should not be universally superior after specialization/logistics.
assert(results[100].grain.modern_lease.bankruptPct>results[100].grain.contractor.bankruptPct);checks++;
checks++;
const rootDominates=areas.every(area=>Object.keys(strategies).every(sk=>results[area].root_heavy[sk].medianEquity>results[area].diversified[sk].medianEquity));
console.log(JSON.stringify({pass:true,checks,years,seeds,areas,representativeCapex:{old:Math.round(baseOld),mixed:Math.round(baseMixed),modern:Math.round(baseModern),rootOld,rootMixed,rootModern},rootDominatesEverywhere:rootDominates,results},null,2));
