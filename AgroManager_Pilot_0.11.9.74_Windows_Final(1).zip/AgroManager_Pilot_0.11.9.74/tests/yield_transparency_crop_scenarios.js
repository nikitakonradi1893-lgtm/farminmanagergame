const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync('web/app.js','utf8');
function fn(name){const start=src.indexOf(`function ${name}`);assert(start>=0,`missing ${name}`);let d=0,seen=false,end=start;for(let i=start;i<src.length;i++){if(src[i]==='{'){d++;seen=true}else if(src[i]==='}'){d--;if(seen&&d===0){end=i+1;break}}}return src.slice(start,end)}
function constBlock(name,next){const start=src.indexOf(`const ${name}=`);assert(start>=0,name);const end=src.indexOf(`\n${next}`,start);assert(end>start,next);return src.slice(start,end)+';'}
const ctx={Math,Number};vm.createContext(ctx);vm.runInContext(constBlock('CROPS','const ROTATION_GUIDE')+'this.CROPS=CROPS;',ctx);for(const n of ['yieldFactorGroup','yieldFactorMode','yieldWaterfall','yieldGroupSummary','normalizedYieldReport'])vm.runInContext(fn(n),ctx);
const scenarios={
 winter_wheat:[.98,.94,1,.96,1,.99,.97,1,.95,.98,.94,.97,.99,.96,.99],
 corn:[.96,.91,.99,1.02,1,.98,.95,.99,.97,.96,.91,.95,.98,.94,1],
 sunflower:[1,.96,.99,.94,1,.99,.98,1,.99,.97,.95,.96,1.01,.93,.98],
 soybean:[.99,.95,1,1.04,.98,.98,1.01,1,.98,.96,.93,.98,1,.97,.99],
 sugar_beet:[.97,.92,.98,.96,1,.97,.94,.99,.96,.95,.88,.96,.97,.95,.98],
 potato:[.98,.90,.98,.94,1,.96,.93,.99,.95,.94,.86,.97,.96,.92,.99]
};
const keys=['sow','weather','traffic','rotation','seedQuality','sowingEquipment','nutrition','nitrogenExcess','ph','seedbed','compaction','weeds','residue','protection','harvest'];
let checks=0;const out={};
for(const [crop,vals] of Object.entries(scenarios)){
 const base=ctx.CROPS[crop].baseYield,factors=keys.map((key,i)=>({key,label:key,value:vals[i]}));
 const r=ctx.normalizedYieldReport({crop,baseYield:base,targetYield:base*1.1,factors});
 const direct=base*vals.reduce((a,v)=>a*v,1);
 assert(Math.abs(r.yieldPerHa-direct)<1e-10,`${crop} exact product`);checks++;
 assert(Math.abs(base+r.factors.reduce((a,x)=>a+x.deltaYield,0)-r.yieldPerHa)<1e-10,`${crop} waterfall sum`);checks++;
 assert(r.groups.length===5,`${crop} groups`);checks++;
 assert(r.factors.every(x=>Number.isFinite(x.afterYield)&&Number.isFinite(x.deltaYield)),`${crop} finite`);checks++;
 const alt=ctx.normalizedYieldReport({crop,baseYield:base,targetYield:base*.85,factors});assert(Math.abs(alt.yieldPerHa-r.yieldPerHa)<1e-10,`${crop} target not hidden factor`);checks++;
 out[crop]={base,target:+r.targetYield.toFixed(2),result:+r.yieldPerHa.toFixed(3),targetPct:+(r.targetRatio*100).toFixed(1)};
}
console.log(JSON.stringify({pass:true,checks,meaning:'six-crop transparent-yield arithmetic regression; verifies exact factor product, waterfall deltas, grouping and that target yield is not a hidden multiplier',out},null,2));
