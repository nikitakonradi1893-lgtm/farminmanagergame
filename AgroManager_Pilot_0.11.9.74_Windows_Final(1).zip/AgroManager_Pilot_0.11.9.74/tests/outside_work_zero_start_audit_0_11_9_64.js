'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
function el(){return{innerHTML:'',textContent:'',value:'',dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},addEventListener(){},querySelector(){return null},querySelectorAll(){return[]},closest(){return null},getBoundingClientRect(){return{top:0,bottom:20}},blur(){}}}
const elems=new Map(['nav','content','clock','money','toast','saveStatus','manualSaveBtn','manualLoadBtn','resetBtn','exitBtn'].map(k=>[k,el()]));const document={activeElement:{tagName:'BODY'},body:el(),getElementById(k){if(!elems.has(k))elems.set(k,el());return elems.get(k)},querySelector(){return null},querySelectorAll(){return[]},addEventListener(){}};const storage=()=>({getItem(){return null},setItem(){}});class XHR{}
const ctx={console,Math,Number,String,Boolean,Object,Array,Set,Map,Date,Intl,JSON,RegExp,Promise,Error,TypeError,parseInt,parseFloat,isFinite,document,localStorage:storage(),sessionStorage:storage(),XMLHttpRequest:XHR,crypto:{randomUUID:(()=>{let i=0;return()=>`z-${++i}`})()},fetch:async()=>({ok:true,status:200,headers:{get(){return null}},json:async()=>({})}),confirm:()=>true,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},requestAnimationFrame:()=>1,window:null};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);let src=fs.readFileSync('web/app.js','utf8'),pos=src.lastIndexOf('})();');src=src.slice(0,pos)+`\nwindow.__z={freshState,refreshOutsideWork,outsideWorkerEligible,outsideWorkRate,startOutsideWork,processOutsideWork,processStaff,setState(x){state=x},getState(){return state}};\n`+src.slice(pos);vm.runInContext(src,ctx,{timeout:30000});const a=ctx.__z;
let st=a.freshState('zero');st.landSeed=123456789;a.setState(st);const start=st.gameTime;let jobs=0,hours=0;const byYear=[];
for(let day=0;day<365*3;day++){
  const t=start+day*86400000, d=new Date(t); st.gameTime=t;
  // only weekdays: player does not grind 365 days/year
  const owner=st.staff.owner;if(d.getDay()!==0&&d.getDay()!==6 && (owner.restUntil||0)<=t){
    a.refreshOutsideWork(true);const eligible=st.outsideWork.offers.filter(o=>a.outsideWorkerEligible(owner,o)).sort((x,y)=>a.outsideWorkRate(owner,y)-a.outsideWorkRate(owner,x)||y.hours-x.hours);
    if(eligible.length){const o=eligible[0];a.startOutsideWork(o.id,'OWNER');const j=st.outsideWork.active[st.outsideWork.active.length-1];if(j){jobs++;hours+=j.hours;st.gameTime=j.end;a.processOutsideWork();}}
  }
  const next=t+86400000;a.processStaff(t,next);st.gameTime=next;
  if((day+1)%365===0){const ow=st.staff.owner;byYear.push({year:(day+1)/365,money:Math.round(st.money),skill:ow.skill,skillXp:Number((ow.skillXp||0).toFixed(1)),hours:Math.round(ow.hoursWorked||0),jobs});}
}
assert(st.money>0);assert(st.money<10_000_000,'zero-start external work should not recreate medium start capital within 3 years');const owner=st.staff.owner;assert((owner.skillXp||0)>0||owner.skill>45);assert(jobs>300);
console.log(JSON.stringify({pass:true,checks:4,threeYear:{money:Math.round(st.money),skill:owner.skill,skillXp:Number((owner.skillXp||0).toFixed(1)),hours:Math.round(owner.hoursWorked||0),jobs},byYear},null,2));
