const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);
const E=ctx.window.EQUIPMENT_CATALOG;const powered=E.filter(m=>m.type==='tractor'||m.type==='combine'||m.type==='truck'||m.selfPropelled);
const counts={tractor:powered.filter(x=>x.type==='tractor').length,combine:powered.filter(x=>x.type==='combine').length,truck:powered.filter(x=>x.type==='truck').length,selfPropelledImplement:powered.filter(x=>x.selfPropelled&&x.type==='implement').length};
assert(counts.tractor>=118&&counts.combine>=57&&counts.truck>=17&&counts.selfPropelledImplement>=18,JSON.stringify(counts));
assert.strictEqual(powered.length,counts.tractor+counts.combine+counts.truck+counts.selfPropelledImplement);
const app=fs.readFileSync('web/app.js','utf8');let checks=0;
for(const needle of [
 "function isPoweredSelfPropelled(m)",
 "if(isPoweredSelfPropelled(m)){const e=syntheticStockEngine(m);return e?[e]:[]}",
 "physicalCapable=isPoweredSelfPropelled(model)&&engineVariantsForModel(model).some(engineIsPhysical)",
 "if(asset.engineMissing&&isPoweredSelfPropelled(model))asset.systems.engine=null",
 "if(isPoweredSelfPropelled(equipmentModel(a.modelId))&&a.tireId&&assetDriveType(a)==='wheeled')keys.push('tires')",
 "if(isPoweredSelfPropelled(equipmentModel(a.modelId))&&a.trackId&&assetDriveType(a)!=='wheeled')keys.push('tracks')",
 "if(k==='engine'&&isPoweredSelfPropelled(m))",
 "if(['transmission','running','hydraulics'].includes(k)&&isPoweredSelfPropelled(m))",
 "EQUIP.filter(m=>isPoweredSelfPropelled(m)&&!m.hidden)",
 "m.selfPropelled&&m.type==='implement'"
]){assert(app.includes(needle),needle);checks++;}
const trackedNames=['Quadtrac','DeltaTrack','Challenger MT7','Challenger MT8','IDEAL 9T','Т-150 гусеничный','ДТ-75','АГРОМАШ Руслан'];
const noTire=powered.filter(m=>trackedNames.some(n=>(m.name||'').includes(n))).length;
const tireEligible=powered.length-noTire;
assert(tireEligible>=149);checks++;
// Economic sanity: bare machine + used engine + labor should not exceed ready equivalent by construction.
function barePrice(ready,engine,labor){return Math.max(50000,Math.round((ready-engine-labor*1.05)/10000)*10000)}
for(const x of [{ready:2200000,engine:420000,labor:180000},{ready:6500000,engine:900000,labor:230000},{ready:3200000,engine:520000,labor:160000}]){const bare=barePrice(x.ready,x.engine,x.labor);assert(bare+x.engine+x.labor<=x.ready+10000);checks++;}
console.log(JSON.stringify({pass:true,checks,poweredTotal:powered.length,counts,tireEligible,meaning:'двигатели, крупные узлы, критические отказы, склад/рынок запчастей и шины распространены на тракторы, комбайны, грузовики и весь текущий каталог самоходных машин-орудий'},null,2));
