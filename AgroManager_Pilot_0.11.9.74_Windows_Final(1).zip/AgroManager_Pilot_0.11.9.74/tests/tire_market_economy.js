const fs=require('fs'),vm=require('vm'),assert=require('assert');
const ctx={window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync('web/equipment.js','utf8'),ctx);const E=ctx.window.EQUIPMENT_CATALOG,V=ctx.window.TRACTOR_ENGINE_VARIANTS||{};
const k=E.find(m=>m.id==='k700');assert(k);const eng=V.k700.find(x=>x.id==='yamz7511_400');assert(eng);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const base=Math.max(120000,Math.min(1100000,Math.round((k.price||1000000)*.035/10000)*10000));
const tire={
 standard:{price:base,installH:6,soil:1,trample:1,traction:1,fuel:1,road:1},
 wide:{price:Math.round(base*1.65/10000)*10000,installH:8,soil:.78,trample:.88,traction:1.08,fuel:.99,road:.96},
 dual:{price:Math.round(base*2.05/10000)*10000,installH:10,soil:.68,trample:1.08,traction:1.15,fuel:.98,road:.88}
};
function labor(x){return Math.max(20000,Math.round(x.installH*3200/10000)*10000)}
function resale(x,cond=100,h=0){return Math.max(10000,Math.round(x.price*(.18+.0072*clamp(cond,1,100))*clamp(1-h/18000,.55,1)*.82/10000)*10000)}
for(const x of Object.values(tire)){assert(resale(x)<x.price);assert(labor(x)>0)}
// Same 1000 ha seasonal plan used by critical_tires_real_farm.js
const plan=[['disk',1000],['deepRip',300],['cultivate',1000],['sow_grain',1000],['fertilizer',1000],['sprayer',1000],['sprayer',1000]];
function best(cat){return E.filter(m=>m.type==='implement'&&(m.category===cat||(m.categories||[]).includes(cat))&&(m.requiredHp||0)<=400).sort((a,b)=>(b.width*b.speed*(b.eff||.78))-(a.width*a.speed*(a.eff||.78)))[0]}
const impl=plan.map(([cat,ha])=>({cat,ha,im:best(cat)}));assert(impl.every(x=>x.im));
function sim(t){let hours=0,diesel=0;for(const x of impl){const r=x.im.width*x.im.speed*(x.im.eff||.78)/10*clamp(1+(t.traction-1)*.45,.96,1.07),h=x.ha/r;hours+=h;diesel+=h*eng.fuelLph*.68*t.fuel;}return{hours,diesel}}
const s={};for(const [n,t] of Object.entries(tire))s[n]=sim(t);
const dieselPrice=72,laborHourValue=900; // opportunity-cost proxy, not wage accounting
for(const n of ['wide','dual']){const capex=(tire[n].price-tire.standard.price)+labor(tire[n]),annualFuel=(s.standard.diesel-s[n].diesel)*dieselPrice,annualTime=(s.standard.hours-s[n].hours)*laborHourValue,benefit=annualFuel+annualTime;s[n].capex=capex;s[n].annualBenefit=benefit;s[n].simplePaybackY=capex/Math.max(1,benefit);assert(s[n].simplePaybackY>.5&&s[n].simplePaybackY<8);}
assert(tire.dual.road<tire.wide.road);assert(tire.dual.trample>tire.wide.trample); // duals are not universal meta
console.log(JSON.stringify({pass:true,model:k.name,prices:Object.fromEntries(Object.entries(tire).map(([n,x])=>[n,{newPrice:x.price,installLabor:labor(x),immediateResale:resale(x),used70pct7kh:resale(x,70,7000)}])),season:Object.fromEntries(Object.entries(s).map(([n,x])=>[n,{hours:+x.hours.toFixed(1),dieselL:+x.diesel.toFixed(0),capex:x.capex?Math.round(x.capex):undefined,annualBenefit:x.annualBenefit?Math.round(x.annualBenefit):undefined,simplePaybackY:x.simplePaybackY?+x.simplePaybackY.toFixed(2):undefined}])),tradeoff:'широкие/спарки могут окупаться на интенсивной работе, но спарки хуже на дороге и сильнее повреждают посевы; мгновенного арбитража покупки/продажи нет'},null,2));
