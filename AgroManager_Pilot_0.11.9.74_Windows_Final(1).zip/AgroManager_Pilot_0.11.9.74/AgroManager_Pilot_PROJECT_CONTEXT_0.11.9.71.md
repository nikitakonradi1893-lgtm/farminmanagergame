# AgroManager Pilot — project context 0.11.9.71

- Version: **0.11.9.71**.
- Base: 0.11.9.70 catalog-gap-closure release.
- Scope: equipment physical-model deduplication and semantic-target cleanup only; no new equipment families added.

## Equipment catalog

The catalog now contains **868 physical records** after removing confirmed duplicate cards while preserving real market/gameplay coverage.

Key cleanup:
- duplicate БДТ-3 / КПС-4 / СЗ-3,6 cards removed;
- КПС-2,8 and GRIMME GF 400 use one physical model plus the dynamic used market;
- duplicate self-propelled КСП-4 and КС-6Б cards removed;
- stale multi-role `imp41` mapping corrected to КПС-4 `imp43`;
- 2ПТС-4/2ПТС-6 bale transport consolidated into the base trailer assets.

## Regression policy

`tests/equipment_physical_dedup_audit_0_11_9_71.js` is now a permanent gate. It checks duplicate IDs, canonical physical-name duplicates, stale multi-role targeting and role-only duplication patterns.

Zero-gap tests now recognize that eligible current models can generate used-market listings instead of requiring an explicit duplicate `(Б/У)` card.

## Checkpoint cadence

0.11.9.71 is release **3/3 after checkpoint 0.11.9.68**, so this build is the next mandatory Google Drive checkpoint.

## Mandatory development continuity rules

- Context is mandatory in every release: ship `PROJECT_CONTEXT.md` and a versioned context copy.
- Always ship the complete current game, never an isolated patch-only artifact.
- Google Drive checkpoint every three releases.
- Releases counted since the last mandatory Drive checkpoint: **3/3 — checkpoint 0.11.9.71**.
- Mandatory cross-surface impact scan before implementation: data, runtime logic, UI, tests, docs and packaging must be checked together.
- Impact consistency is a release gate: all affected surfaces must agree before a release is considered complete.
- Pending Drive upload: **none**.
