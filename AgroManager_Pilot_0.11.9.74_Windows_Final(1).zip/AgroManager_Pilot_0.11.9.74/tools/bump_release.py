#!/usr/bin/env python3
"""Synchronize AgroManager release version/cache markers across the distributable tree.
Usage: python tools/bump_release.py 0.11.9.56
"""
from pathlib import Path
import re, sys
if len(sys.argv)!=2 or not re.fullmatch(r'\d+\.\d+\.\d+\.\d+',sys.argv[1]):
    raise SystemExit('usage: bump_release.py X.Y.Z.N')
new=sys.argv[1]; root=Path(__file__).resolve().parents[1]
app=root/'web'/'app.js'; text=app.read_text();
m=re.search(r"version:'([^']+)'",text)
if not m: raise SystemExit('CONFIG.version not found')
old=m.group(1); cache=''.join(f'{int(x):02d}' if i else f'{int(x):01d}' for i,x in enumerate(new.split('.')))
# Project cache convention is 0119NN for this branch.
parts=new.split('.'); cache=f"{int(parts[0])}{int(parts[1]):02d}{int(parts[2])}{int(parts[3]):02d}"
oldparts=old.split('.'); oldcache=f"{int(oldparts[0])}{int(oldparts[1]):02d}{int(oldparts[2])}{int(oldparts[3]):02d}"
for rel in ['web','source_web_copy','tests']:
    for p in (root/rel).rglob('*'):
        if not p.is_file() or p.suffix not in {'.js','.html','.css','.md','.txt'}: continue
        s=p.read_text(errors='ignore'); n=s.replace(old,new).replace(oldcache,cache)
        if n!=s: p.write_text(n)
for name in ['app.js','equipment.js','index.html','styles.css']:
    (root/'source_web_copy'/name).write_bytes((root/'web'/name).read_bytes())
print(f'{old} -> {new}; cache {oldcache} -> {cache}')
