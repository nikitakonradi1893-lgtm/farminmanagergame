# AgroManager Pilot — project context 0.11.9.72

- Version: **0.11.9.72**.
- Base: 0.11.9.71 physical equipment deduplication checkpoint.
- Scope: used-market price parity only; no equipment catalog expansion or farm-economy rebalance.

## Used-market pricing

For models that are still sold new, a used listing must be strictly cheaper than a new machine in the **same configuration**.

The used-market generator now calculates the equivalent dealer price using the listing's engine, tires/tracks and body configuration and applies a 94% cap after legacy minimum-price logic. This fixes low-price items that could previously be pushed above new price by the 50,000 ₽ minimum floor.

Base-new comparisons remain informational only: a richer used configuration may cost more than a base new configuration, but never more than its equivalent new configuration.

## Regression policy

`tests/used_vs_new_price_parity_audit_0_11_9_72.js` is a permanent gate. It Monte-Carlo samples every model that can appear both new and used and fails on any equivalent-configuration price inversion.

The physical equipment dedup gate from 0.11.9.71 remains mandatory.

## Checkpoint cadence

0.11.9.72 is release **1/3 after checkpoint 0.11.9.71**. No Drive checkpoint is required for this release.

## Mandatory development continuity rules

- Context is mandatory in every release: ship `PROJECT_CONTEXT.md` and a versioned context copy.
- Always ship the complete current game, never an isolated patch-only artifact.
- Google Drive checkpoint every three releases.
- Releases counted since the last mandatory Drive checkpoint: **1/3 after 0.11.9.71**.
- Mandatory cross-surface impact scan before implementation: data, runtime logic, UI, tests, docs and packaging must be checked together.
- Impact consistency is a release gate: all affected surfaces must agree before a release is considered complete.
- Pending Drive upload: **none**.
