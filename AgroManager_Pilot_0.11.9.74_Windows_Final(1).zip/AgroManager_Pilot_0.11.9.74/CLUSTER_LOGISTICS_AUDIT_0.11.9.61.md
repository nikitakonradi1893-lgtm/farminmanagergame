# AgroManager Pilot 0.11.9.61 — cluster logistics comparison

## Setup
Two otherwise identical farms:
- 1000 ha each;
- 20 fields × 50 ha;
- 3 full seasons;
- identical machinery and field work rates;
- same operation set: sowing, two spraying passes, harvest;
- fields are worked cluster-by-cluster.

Farm A uses the previous movement model: each field causes a base → field → base road leg.
Farm B uses the new spatial layer: machinery remains at the completed field and moves directly to the next field inside the same cluster. The control farm occupies four compact clusters; the game-wide land system supports all eight clusters.

## Results — 3 seasons

| Metric | Farm A — old model | Farm B — clusters | Saving |
|---|---:|---:|---:|
| Relocation time | 402.60 h | 100.46 h | **302.14 h** |
| Road distance | 8,910.00 km | 2,223.36 km | **6,686.64 km** |
| Relocation diesel | 3,828.66 L | 958.03 L | **2,870.63 L** |
| Field work time | 2,567.66 h | 2,567.66 h | 0 |
| Field work diesel | 65,683.76 L | 65,683.76 L | 0 |
| Total time | 2,970.26 h | 2,668.13 h | **302.14 h** |
| Total diesel | 69,512.42 L | 66,641.79 L | **2,870.63 L** |
| Relocation fuel cost @ 70 RUB/L | 268,006 RUB | 67,062 RUB | **200,944 RUB** |

The cluster system cuts relocation time by **75.05%** and relocation fuel by **74.98%** in this deliberately compact 20-field control.

## Interpretation
The gain is not a production-speed bonus: actual sowing/spraying/harvest work is identical. It comes only from removing unnecessary returns to base between nearby fields. Therefore compact land ownership now has a physical value in time, diesel, machine hours/wear and staff loading.

Cross-cluster movement remains conservative and routes through the base until the future interactive map provides road nodes and real coordinates.
