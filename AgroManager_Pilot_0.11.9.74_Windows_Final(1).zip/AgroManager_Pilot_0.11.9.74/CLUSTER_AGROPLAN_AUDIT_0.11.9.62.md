# Cluster + Agronomist Plan Audit — 0.11.9.62

## Scope
- 8-direction cluster ring and direct transfer across neighboring sectors.
- Agronomist operation queue.
- Automatic next-field handoff when operation is valid and shift time remains.
- Pause + decision dialog when chaining cannot continue.
- Real return-to-base transit.
- Compatibility with fuel and material dispatch.

## Comparative relocation control
1000 ha, 20 fields, three seasons, identical work operations and machinery.

| Metric | Old base-return | 0.11.9.62 spatial routing | Saving |
|---|---:|---:|---:|
| Relocation time | 402.60 h | 50.77 h | 351.83 h |
| Relocation distance | 8,910 km | 1,123.56 km | 7,786.44 km |
| Relocation diesel | 3,828.66 L | 483.91 L | 3,344.75 L |
| Diesel value @ 70 RUB/L | 268,006 RUB | 33,874 RUB | 234,133 RUB |

Field-work hours are unchanged; the improvement comes only from eliminating unnecessary base returns and permitting adjacent-cluster transfers.

## Guardrails
- Same-cluster and neighboring-cluster routes may be direct.
- More distant cluster changes still route through base.
- Auto-continuation requires the next operation to be allowed and enough shift time for the transfer.
- When the guard fails, the simulation pauses instead of silently leaving machinery idle.
