# AgroManager Pilot 0.11.9.65 — First Farm UX / Economy Audit

## Scope

This release connects four previously separate concerns into one readable early-farm loop:

1. first-farm progression guidance;
2. pre-harvest season cash planning;
3. machinery-vs-contractor decision support;
4. visible used-market turnover and opportunity signals.

## First-farm progression layer

The dashboard now derives a five-stage path from live state rather than forcing a scripted quest:

`first field → season budget → active work → harvest → mechanization decision`.

Each stage links to the existing relevant page. No new hidden progression currency, subsidy or balance modifier was introduced.

## Season budget

For owned arable land the planning card calculates an early-season estimate using:

- field area and current/planned crop;
- current standard contractor quotes for representative primary operations;
- seed cost from the existing seed catalog;
- a modest material allowance;
- projected yield for an active crop, or 85% of base yield for a planned crop;
- 95% of the current base crop price;
- explicit comparison to a 300,000 RUB liquidity reserve.

The number is intentionally labeled as a forecast. It is not meant to replace the detailed technological map or finance ledger.

## Used machinery decision support

Used implements and combines now show the amount of standard contractor work the machine could potentially replace across the player's current arable area. The UI explicitly warns that this is not net savings and excludes fuel, labor, repair, downtime and residual value.

Tractors are treated differently: their listing shows how many compatible implements are already owned and how many compatible used listings exist. This avoids assigning standalone payback to a tractor without an implement.

## Living used market

The underlying market was already dynamic, with per-listing expiry and weekly replenishment. 0.11.9.65 exposes this state to the player:

- listings created in the last seven game days;
- listings expiring within three game days;
- last market replenishment;
- approximate next weekly replenishment;
- per-listing badges for new, expiring, and unusually cheap offers.

The rare-price signal requires a meaningful discount versus ready-equivalent value and a minimum estimated condition. Diagnosis remains important because the signal does not remove hidden-condition uncertainty.

## Regression result

Targeted checks passed for the new first-farm/economy layer, technical integrity, outside work, land market, progression bottlenecks and the full equipment catalog. No global crop prices, land prices, contractor base prices, outside-work income, or used-listing generation formulas were rebalanced in this release.
