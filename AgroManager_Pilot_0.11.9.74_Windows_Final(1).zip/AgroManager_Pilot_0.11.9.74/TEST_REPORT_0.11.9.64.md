# TEST REPORT — 0.11.9.64

## New outside-work system
- `outside_work_hiring_0_11_9_64.js`: **24 PASS**
- `outside_work_zero_start_audit_0_11_9_64.js`: **4 PASS**

## Staff / scheduling neighbors
- staff payroll/training: **26 PASS**
- staff strategy: **12 PASS**
- staff conflict: **14 PASS**
- staff windows: **22 PASS**
- contract staffing/rest: **12 PASS**

## Core regression gate
- technical integrity: **52 PASS**
- renderer smoke: **42 PASS**
- fresh-game policy: **13/13 PASS**
- physical fuel: **11 PASS**
- shared fuel dispatch: **14 PASS**
- agro-plan adjacent clusters: **18 PASS**
- land clusters: **14 PASS**

## Notes
- Removed obsolete `manual_ui_fixes_0_11_9_59.js`; its focus expectation was intentionally superseded by the 0.11.9.60 live-refresh fix.
- 0.11.9.64 is 2/3 after mandatory Drive checkpoint 0.11.9.62; no Drive upload required.

## Additional core checks
- cross-runtime: **82 PASS**
- zero-gap: **925 PASS / 785 models**
- equipment integrity: **12,022 PASS / 785 models**
- root market: **28 PASS**
- cleaner ROI: **46 PASS**
- service parts wait: **12 PASS**
- project continuity: **11/11 PASS**

## Native launcher
- /health = ok
- runtime: **0.11.9.64**
- /quit = bye
- EXE SHA-256: `32f47c9fd42a1574dfe5bb200e99ca7f5635d671e6ab74962b720eabb2637e1d`
- ZIP SHA-256 is reported externally after final archive creation.
