# AgroManager Pilot 0.11.9.65 — test report

## New first-farm / used-market layer

- `tests/first_farm_ux_economy_0_11_9_65.js`: **15/15 PASS**.
- 30 ha planning sample in the harness: forecast cost 710,900 RUB; forecast revenue 976,752 RUB; forecast operating margin +265,852 RUB. This is a UI planning estimate, not a replacement for the detailed progression audit.

## Adjacent regressions

- `tests/technical_integrity_audit.js`: **52/52 PASS**.
- `tests/outside_work_hiring_0_11_9_64.js`: **24/24 PASS**.
- `tests/land_meadow_market_distance_0_11_9_34.js`: **311 checks PASS**.
- `tests/progression_bottleneck_0_11_9_55.js`: **6 checks PASS**.
- `tests/equipment_full_integrity_audit_0_11_8_96.js`: **12,022 checks PASS** across 785 active physical catalog entries.
- `tests/project_continuity_rules_0_11_9_09.js`: **11/11 PASS** after the 0.11.9.65 versioned context was created.

## Build

- Windows x86-64 launcher was rebuilt from the synchronized `web/` tree.
- A second native Linux smoke build was attempted only as an auxiliary launcher check, but exceeded the execution window of this environment. Runtime JavaScript syntax and integrity tests passed; the Windows build itself completed.

## Balance scope

No global crop prices, land prices, contractor base prices, used-listing generation formulas, or outside-work pay formulas were changed in 0.11.9.65. The release adds decision support and visibility over existing mechanics.
