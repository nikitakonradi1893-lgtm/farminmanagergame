# Progression bottleneck audit — 0.11.9.55

Representative old-fleet control uses real catalog models:
- K-700 + PLN-8-40 for heavy tillage;
- MTZ-82 + SZ-5.4 for sowing;
- MTZ-82 + OP-2000-2-01 for spraying;
- DON-1500B + ZHU-7 for grain harvest;
- 2 × KamAZ-55102 for 30 km haul.

Calendar check uses diversified crop windows and conservative weather availability.

## Results
| Area | Heavy tillage missed | Sowing missed | Spraying missed | Harvest missed | Main issue |
|---:|---:|---:|---:|---:|---|
| 750 ha | 0 | 0 | 0 | 0 | none |
| 1000 ha | 0 | 0 | 0 | 0 | none |
| 1250 ha | 0 | 0 | 0 | 0 | none |
| 1500 ha | ~85 ha | 0 | 0 | 0 | heavy tillage |
| 2000 ha | ~585 ha | 0 | 0 | ~257 ha | tillage + harvest |

Calculated work rates:
- tillage ~1.75 ha/h;
- sowing ~3.37 ha/h;
- spraying ~14.04 ha/h;
- harvest ~2.40 ha/h;
- two old grain trucks at 30 km ~11.4 t/h versus ~6.0 t/h average crop flow of one DON.

## Progression implication
The first rational upgrade around 1250–1500 ha is not a full mixed fleet. It is additional heavy-tillage capacity. A second K-700 + PLN-8-40 costs about 2.40M RUB and doubles that bottleneck capacity.

Around 1800–2000 ha, harvest becomes the next major bottleneck. A second DON-1500B + ZHU-7 costs about 3.12M RUB; when combine capacity doubles, haul capacity then needs to be rechecked and potentially expanded (another pair of KamAZ-55102 is about 2.20M RUB).

This provides a natural incremental progression ladder and confirms that the previous 50M+ all-at-once mixed-fleet jump was a harness artifact, not a required game balance change.
